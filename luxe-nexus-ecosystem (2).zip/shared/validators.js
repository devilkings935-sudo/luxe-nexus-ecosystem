/**
 * LUXE NEXUS Shared Validators
 * Input validation and security rules shared across UI and Service Layer.
 */

import { sanitizeUrl, roundMoney } from './utilities.js';

export function validateEmail(email) {
  const clean = String(email ?? '').trim();
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(clean);
}

export function validatePhone(phone) {
  const clean = String(phone ?? '').replace(/[\s\-()]/g, '');
  return /^\+?[0-9]{10,15}$/.test(clean);
}

export function evaluatePasswordStrength(password) {
  const val = String(password ?? '');
  if (!val) return { score: 0, label: 'Empty', valid: false };
  let score = 0;
  if (val.length >= 6) score += 1;
  if (val.length >= 10) score += 1;
  if (/[A-Z]/.test(val) && /[a-z]/.test(val)) score += 1;
  if (/[0-9]/.test(val) && /[^A-Za-z0-9]/.test(val)) score += 1;

  const labels = ['Weak', 'Fair', 'Good', 'Strong', 'Very Strong'];
  return {
    score,
    label: labels[score] || 'Weak',
    valid: val.length >= 6,
  };
}

export function validateProductInput(product) {
  const errors = [];
  const name = String(product?.name ?? '').trim();
  const cat = String(product?.cat ?? product?.category ?? '').trim();
  const price = roundMoney(product?.price);
  const offerPrice = product?.offerPrice !== undefined && product?.offerPrice !== '' ? roundMoney(product.offerPrice) : price;
  const stock = product?.stock !== undefined && product?.stock !== '' ? Number(product.stock) : 0;

  if (!name || name.length < 2) errors.push('Product name must be at least 2 characters.');
  if (!cat) errors.push('Category is required.');
  if (!Number.isFinite(price) || price <= 0) errors.push('Regular price must be greater than zero.');
  if (offerPrice <= 0 || offerPrice > price) errors.push('Offer price must be positive and cannot exceed regular price.');
  if (!Number.isFinite(stock) || stock < 0) errors.push('Stock quantity cannot be negative.');

  const rawImages = Array.isArray(product?.images)
    ? product.images
    : String(product?.images ?? product?.image ?? '').split(/\n|,/).map((s) => s.trim()).filter(Boolean);

  const validImages = rawImages.map((u) => sanitizeUrl(u, true)).filter(Boolean);
  if (!validImages.length) {
    errors.push('At least one valid image URL (http/https or local asset) is required.');
  }

  return {
    valid: errors.length === 0,
    errors,
    cleanImages: validImages,
    price,
    offerPrice,
    stock: Math.floor(stock),
  };
}

export function validateCheckoutInput(payload, config = {}) {
  const errors = [];
  const customer = payload?.customer || {};
  const items = Array.isArray(payload?.items) ? payload.items : [];
  const checkoutCfg = config?.checkout || {};

  if (!items.length) errors.push('Your order must contain at least one product.');
  for (const item of items) {
    if (!item.productId || Number(item.qty) < 1 || roundMoney(item.unitPrice) <= 0) {
      errors.push('Invalid item quantity or price in checkout.');
      break;
    }
  }

  if (!String(customer.name ?? '').trim()) errors.push('Recipient full name is required.');
  if (!validatePhone(customer.phone)) errors.push('A valid mobile number (10–15 digits) is required.');
  if (!String(customer.district ?? '').trim()) errors.push('Delivery district is required.');
  if (!String(customer.upazila ?? '').trim()) errors.push('Upazila / area is required.');
  if (!String(customer.address ?? '').trim() || String(customer.address).trim().length < 5) {
    errors.push('Full delivery address is required.');
  }

  const area = payload?.area === 'outside' ? 'outside' : 'dhaka';
  const payment = String(payload?.payment || 'COD');
  if (payment === 'COD' && checkoutCfg.cod === false) errors.push('Cash on Delivery is currently disabled.');
  if (payment === 'bKash' && !checkoutCfg.bkash) errors.push('bKash payment is not enabled yet.');
  if (payment === 'Nagad' && !checkoutCfg.nagad) errors.push('Nagad payment is not enabled yet.');

  return {
    valid: errors.length === 0,
    errors,
    area,
    payment,
  };
}

export function validateAffiliateApplication(payload, eligibilityRules = {}) {
  const errors = [];
  const minAge = Number(eligibilityRules.minApplicantAge ?? 18);
  const requireSocial = eligibilityRules.requireSocialOrWebsite !== false;

  if (!String(payload?.name ?? '').trim() || String(payload?.name ?? '').trim().length < 2) {
    errors.push('Full name is required.');
  }
  if (!String(payload?.userId ?? '').trim()) errors.push('Valid user account is required.');
  if (!validatePhone(payload?.phone)) errors.push('Valid phone number is required.');
  if (!validateEmail(payload?.email)) errors.push('Valid email address is required.');

  if (payload?.age !== undefined && payload?.age !== null && payload?.age !== '') {
    const parsedAge = Number(payload.age);
    if (!Number.isFinite(parsedAge) || parsedAge < minAge) {
      errors.push(`Applicants must be at least ${minAge} years old.`);
    }
  }

  const rawSocial = String(payload?.socialLink ?? '').trim();
  const cleanSocial = rawSocial ? sanitizeUrl(rawSocial, false) : '';
  if (requireSocial && !cleanSocial) {
    errors.push('A valid Social Media profile or Website URL (https://...) is required.');
  } else if (rawSocial && !cleanSocial) {
    errors.push('Social Media / Website URL must begin with http:// or https://.');
  }

  const followers = Number(payload?.followerCount ?? 0);
  if (!Number.isFinite(followers) || followers < 0) {
    errors.push('Enter a valid follower / audience count (0 or higher).');
  }

  if (!String(payload?.promotionMedium ?? '').trim()) {
    errors.push('Please select your primary promotion medium.');
  }

  if (String(payload?.marketingPlan ?? '').trim().length < 10) {
    errors.push('Please provide a short marketing plan (at least 10 characters).');
  }

  if (!payload?.termsAccepted) errors.push('You must accept all 10 Affiliate Program Rules & Terms.');
  return { valid: errors.length === 0, errors, cleanSocial, followerCount: Math.floor(Math.max(0, followers)) };
}

export function validateWithdrawalRequest(payload, availableBalance, minWithdrawal = 500) {
  const errors = [];
  const amount = roundMoney(payload?.amount);
  const avail = roundMoney(availableBalance);
  const min = roundMoney(minWithdrawal);
  const method = String(payload?.method ?? '').trim();
  const holder = String(payload?.accountHolder ?? '').trim();
  const accountNumber = String(payload?.accountNumber ?? '').trim();

  if (!['bKash', 'Nagad', 'Bank'].includes(method)) errors.push('Select a valid payout method (bKash, Nagad, or Bank).');
  if (!holder) errors.push('Account holder name is required.');
  if (!accountNumber || accountNumber.length < 6) errors.push('Valid account number is required.');
  if (!Number.isFinite(amount) || amount <= 0) errors.push('Enter a valid withdrawal amount.');
  if (amount < min) errors.push(`Minimum withdrawal amount is ${min}.`);
  if (amount > avail) errors.push('Requested amount exceeds available balance.');

  return { valid: errors.length === 0, errors, amount };
}
