/**
 * LUXE NEXUS Shared UI Components
 * Reusable modals, toast, confirmation dialogs, SVG charts, QR renderer,
 * notification center drawer, update/announcement dialogs, and progressive custom luxury dropdowns.
 */

import { escapeHtml, escapeAttr, generateQrMatrix, formatDateTime, sanitizeUrl } from './utilities.js';
import {
  getNotificationsForScope,
  markNotificationRead,
  markAllNotificationsRead,
  deleteNotification,
} from '../services/notification-service.js';

let toastTimer = null;

export function showToast(message, type = 'info') {
  if (typeof document === 'undefined') return;
  let el = document.getElementById('ln-global-toast');
  if (!el) {
    el = document.createElement('div');
    el.id = 'ln-global-toast';
    el.className = 'ln-toast';
    el.setAttribute('role', 'status');
    el.setAttribute('aria-live', 'polite');
    document.body.appendChild(el);
  }
  el.className = `ln-toast ${type === 'error' ? 'error' : type === 'success' ? 'success' : ''}`;
  el.textContent = String(message || '');
  el.style.display = 'block';
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    el.style.display = 'none';
  }, 2600);
}

export function openConfirmDialog({ title, message, subtitle = 'Please Confirm', confirmLabel = 'Confirm', danger = false }) {
  return new Promise((resolve) => {
    let backdrop = document.getElementById('ln-confirm-modal');
    if (!backdrop) {
      backdrop = document.createElement('div');
      backdrop.id = 'ln-confirm-modal';
      backdrop.className = 'ln-modal-backdrop';
      document.body.appendChild(backdrop);
    }
    backdrop.innerHTML = `
      <div class="ln-modal" role="dialog" aria-modal="true" aria-labelledby="lnConfirmTitle">
        <div style="font-size:11px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:${danger ? 'var(--error)' : 'var(--gold)'};margin-bottom:6px;">${escapeHtml(subtitle)}</div>
        <h3 id="lnConfirmTitle" style="font-family:var(--font-serif);font-size:20px;margin-bottom:8px;">${escapeHtml(title)}</h3>
        <p style="color:var(--text-muted);font-size:13px;margin-bottom:20px;line-height:1.6;">${escapeHtml(message)}</p>
        <div class="ln-modal-actions">
          <button type="button" class="ln-btn ln-btn-outline" id="lnConfirmCancel">Cancel</button>
          <button type="button" class="ln-btn ${danger ? 'ln-btn-danger' : 'ln-btn-gold'}" id="lnConfirmOk">${escapeHtml(confirmLabel)}</button>
        </div>
      </div>
    `;
    backdrop.classList.add('open');

    const cleanup = (val) => {
      document.removeEventListener('keydown', onKey);
      backdrop.classList.remove('open');
      resolve(val);
    };
    const onKey = (ev) => {
      if (ev.key === 'Escape') cleanup(false);
    };
    document.addEventListener('keydown', onKey);
    backdrop.onclick = (ev) => {
      if (ev.target === backdrop) cleanup(false);
    };
    backdrop.querySelector('#lnConfirmCancel').onclick = () => cleanup(false);
    backdrop.querySelector('#lnConfirmOk').onclick = () => cleanup(true);
  });
}

export function openInputDialog({
  title,
  message = '',
  subtitle = 'Admin Input',
  label = 'Details',
  placeholder = '',
  defaultValue = '',
  required = true,
  confirmLabel = 'Submit',
  danger = false,
}) {
  return new Promise((resolve) => {
    let backdrop = document.getElementById('ln-input-modal');
    if (!backdrop) {
      backdrop = document.createElement('div');
      backdrop.id = 'ln-input-modal';
      backdrop.className = 'ln-modal-backdrop';
      document.body.appendChild(backdrop);
    }
    backdrop.innerHTML = `
      <div class="ln-modal" role="dialog" aria-modal="true" aria-labelledby="lnInputModalTitle">
        <div style="font-size:11px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:${danger ? 'var(--error)' : 'var(--gold)'};margin-bottom:6px;">${escapeHtml(subtitle)}</div>
        <h3 id="lnInputModalTitle" style="font-family:var(--font-serif);font-size:20px;margin-bottom:6px;">${escapeHtml(title)}</h3>
        ${message ? `<p style="color:var(--text-muted);font-size:13px;margin-bottom:14px;line-height:1.55;">${escapeHtml(message)}</p>` : ''}
        <div class="ln-field" style="margin-bottom:16px;">
          <label for="lnInputModalField">${escapeHtml(label)}</label>
          <input id="lnInputModalField" class="ln-input" value="${escapeAttr(defaultValue)}" placeholder="${escapeAttr(placeholder)}" />
        </div>
        <div id="lnInputModalErr" style="display:none;color:var(--error);font-size:12px;margin:-8px 0 12px;"></div>
        <div class="ln-modal-actions">
          <button type="button" class="ln-btn ln-btn-outline" id="lnInputCancel">Cancel</button>
          <button type="button" class="ln-btn ${danger ? 'ln-btn-danger' : 'ln-btn-gold'}" id="lnInputOk">${escapeHtml(confirmLabel)}</button>
        </div>
      </div>
    `;
    backdrop.classList.add('open');

    const inp = backdrop.querySelector('#lnInputModalField');
    const errEl = backdrop.querySelector('#lnInputModalErr');
    setTimeout(() => inp?.focus(), 20);

    const cleanup = (val) => {
      document.removeEventListener('keydown', onKey);
      backdrop.classList.remove('open');
      resolve(val);
    };
    const submit = () => {
      const val = String(inp?.value || '').trim();
      if (required && !val) {
        errEl.style.display = 'block';
        errEl.textContent = `${label} is required.`;
        inp?.focus();
        return;
      }
      cleanup(val);
    };
    const onKey = (ev) => {
      if (ev.key === 'Escape') cleanup(null);
      if (ev.key === 'Enter') {
        ev.preventDefault();
        submit();
      }
    };
    document.addEventListener('keydown', onKey);
    backdrop.onclick = (ev) => {
      if (ev.target === backdrop) cleanup(null);
    };
    backdrop.querySelector('#lnInputCancel').onclick = () => cleanup(null);
    backdrop.querySelector('#lnInputOk').onclick = submit;
  });
}

export function renderQrSvg(payload, sizePx = 148) {
  const matrix = generateQrMatrix(payload);
  const n = matrix.length;
  const cells = [];
  for (let r = 0; r < n; r += 1) {
    for (let c = 0; c < n; c += 1) {
      if (matrix[r][c]) {
        cells.push(`<rect x="${c}" y="${r}" width="1" height="1" fill="#141418"/>`);
      }
    }
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="-1 -1 ${n + 2} ${n + 2}" width="${sizePx}" height="${sizePx}" role="img" aria-label="QR Code for ${escapeAttr(payload)}" style="background:#FFFFFF;border-radius:12px;border:1.5px solid var(--gold);display:block;">${cells.join('')}</svg>`;
}

export function renderBarChartSvg(items, height = 160) {
  if (!items || !items.length) {
    return `<div class="ln-empty" style="padding:22px">No chart data available yet.</div>`;
  }
  const maxVal = Math.max(1, ...items.map((i) => Number(i.value || 0)));
  const width = 460;
  const padBottom = 26;
  const plotH = height - padBottom - 16;
  const barW = Math.min(44, Math.floor((width - 24) / items.length) - 10);
  const step = (width - 20) / items.length;

  const bars = items
    .map((item, idx) => {
      const val = Number(item.value || 0);
      const bh = Math.max(4, Math.round((val / maxVal) * plotH));
      const x = Math.round(14 + idx * step + (step - barW) / 2);
      const y = 12 + (plotH - bh);
      return `
        <g>
          <rect x="${x}" y="${y}" width="${barW}" height="${bh}" rx="4" fill="${item.color || 'var(--gold)'}"></rect>
          <text x="${x + barW / 2}" y="${height - 8}" text-anchor="middle" font-size="10" fill="var(--text-muted)">${escapeHtml(String(item.label).slice(0, 12))}</text>
        </g>
      `;
    })
    .join('');

  return `<svg viewBox="0 0 ${width} ${height}" width="100%" height="${height}" role="img" aria-label="Analytics Chart">${bars}</svg>`;
}

export function renderNotificationModal({ audience, userId, onUpdated }) {
  let backdrop = document.getElementById('ln-notif-modal');
  if (!backdrop) {
    backdrop = document.createElement('div');
    backdrop.id = 'ln-notif-modal';
    backdrop.className = 'ln-modal-backdrop';
    document.body.appendChild(backdrop);
  }

  const closeModal = () => {
    backdrop.classList.remove('open');
    if (onUpdated) onUpdated();
  };

  backdrop.onclick = (ev) => {
    if (ev.target === backdrop) closeModal();
  };

  const draw = () => {
    const items = getNotificationsForScope(audience, userId);
    const rows = items.length
      ? items
          .map(
            (n) => `
          <div style="padding:12px 0;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;gap:12px;opacity:${n.read ? '0.68' : '1'}">
            <div style="min-width:0;flex:1;">
              <div style="font-size:11px;color:var(--gold);font-weight:700;">${escapeHtml(n.category)} · ${formatDateTime(n.createdAt)}</div>
              <div style="font-weight:700;font-size:13px;margin:2px 0;">${escapeHtml(n.title)}</div>
              <div style="font-size:12px;color:var(--text-muted);">${escapeHtml(n.message)}</div>
            </div>
            <div style="display:flex;flex-direction:column;gap:6px;flex-shrink:0;">
              ${!n.read ? `<button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-read-ntf="${escapeAttr(n.id)}">Read</button>` : ''}
              <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-del-ntf="${escapeAttr(n.id)}" aria-label="Delete notification">×</button>
            </div>
          </div>
        `
          )
          .join('')
      : `<div class="ln-empty"><h4>All caught up</h4><p style="font-size:12px">No notifications in your feed.</p></div>`;

    backdrop.innerHTML = `
      <div class="ln-modal" role="dialog" aria-modal="true" aria-label="Notification Center">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid var(--border);">
          <div>
            <div style="font-size:10px;font-weight:700;letter-spacing:0.12em;color:var(--gold);text-transform:uppercase;">CONCIERGE ALERTS</div>
            <h3 style="font-family:var(--font-serif);font-size:19px;">Notification Center</h3>
          </div>
          <div style="display:flex;gap:8px;">
            <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="lnMarkAllRead">Mark All Read</button>
            <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="lnCloseNotif" aria-label="Close notifications">✕</button>
          </div>
        </div>
        <div style="max-height:60vh;overflow-y:auto;">${rows}</div>
      </div>
    `;
    backdrop.classList.add('open');

    backdrop.querySelector('#lnCloseNotif').onclick = closeModal;
    backdrop.querySelector('#lnMarkAllRead').onclick = () => {
      markAllNotificationsRead(audience, userId);
      draw();
      if (onUpdated) onUpdated();
    };
    backdrop.querySelectorAll('[data-read-ntf]').forEach((btn) => {
      btn.onclick = () => {
        markNotificationRead(btn.dataset.readNtf);
        draw();
        if (onUpdated) onUpdated();
      };
    });
    backdrop.querySelectorAll('[data-del-ntf]').forEach((btn) => {
      btn.onclick = () => {
        deleteNotification(btn.dataset.delNtf);
        draw();
        if (onUpdated) onUpdated();
      };
    });
  };
  draw();
}

export function renderUpdateModal({ updateStatus, onUpdateNow, onSkip, onLater }) {
  let backdrop = document.getElementById('ln-update-modal');
  if (!backdrop) {
    backdrop = document.createElement('div');
    backdrop.id = 'ln-update-modal';
    backdrop.className = 'ln-modal-backdrop';
    document.body.appendChild(backdrop);
  }
  const rel = updateStatus.release;
  const listHtml = (rel.whatsNew || []).map((line) => `<li style="margin:4px 0;">${escapeHtml(line)}</li>`).join('');

  backdrop.innerHTML = `
    <div class="ln-modal" role="dialog" aria-modal="true" aria-label="App Update Available">
      <div style="font-size:11px;font-weight:700;color:var(--gold);letter-spacing:0.08em;text-transform:uppercase;">${updateStatus.mandatory ? 'Mandatory Update Required' : 'Update Available'}</div>
      <h3 style="font-family:var(--font-serif);font-size:21px;margin:6px 0 4px;">LUXE NEXUS v${escapeHtml(rel.version)}</h3>
      <div style="font-size:12px;color:var(--text-muted);margin-bottom:12px;">Current: v${escapeHtml(updateStatus.currentVersion)} · Released ${escapeHtml(rel.releaseDate)}</div>
      <p style="font-size:13px;margin-bottom:10px;">${escapeHtml(rel.releaseNotes)}</p>
      ${listHtml ? `<ul style="padding-left:18px;font-size:13px;color:var(--text-muted);margin-bottom:16px;">${listHtml}</ul>` : ''}
      <div class="ln-modal-actions">
        ${
          !updateStatus.mandatory
            ? `<button type="button" class="ln-btn ln-btn-outline" id="lnUpdateSkip">Skip</button>
               <button type="button" class="ln-btn ln-btn-outline" id="lnUpdateLater">Later</button>`
            : ''
        }
        <button type="button" class="ln-btn ln-btn-gold" id="lnUpdateNow">Update Now</button>
      </div>
    </div>
  `;
  backdrop.classList.add('open');

  backdrop.querySelector('#lnUpdateNow').onclick = async () => {
    await onUpdateNow(rel);
    backdrop.classList.remove('open');
  };
  const skipBtn = backdrop.querySelector('#lnUpdateSkip');
  if (skipBtn) {
    skipBtn.onclick = () => {
      onSkip(rel.version);
      backdrop.classList.remove('open');
    };
  }
  const laterBtn = backdrop.querySelector('#lnUpdateLater');
  if (laterBtn) {
    laterBtn.onclick = () => {
      onLater();
      backdrop.classList.remove('open');
    };
  }
}

export function renderAnnouncementModal(announcement, onAction) {
  if (!announcement) return;
  let backdrop = document.getElementById('ln-announce-modal');
  if (!backdrop) {
    backdrop = document.createElement('div');
    backdrop.id = 'ln-announce-modal';
    backdrop.className = 'ln-modal-backdrop';
    document.body.appendChild(backdrop);
  }
  const imgUrl = sanitizeUrl(announcement.image || '', true);
  backdrop.innerHTML = `
    <div class="ln-modal" role="dialog" aria-modal="true" aria-label="Announcement">
      ${imgUrl ? `<img src="${escapeAttr(imgUrl)}" alt="${escapeAttr(announcement.title)}" style="width:100%;height:170px;object-fit:cover;border-radius:10px;margin-bottom:12px;border:1px solid var(--border);">` : ''}
      <div style="font-size:11px;font-weight:700;color:var(--gold);letter-spacing:0.1em;text-transform:uppercase;">${escapeHtml(announcement.type || 'Notice')}</div>
      <h3 style="font-family:var(--font-serif);font-size:20px;margin:4px 0 8px;">${escapeHtml(announcement.title)}</h3>
      <p style="font-size:13px;color:var(--text-muted);margin-bottom:18px;">${escapeHtml(announcement.description)}</p>
      <div class="ln-modal-actions">
        ${announcement.dismissible && !announcement.mandatory ? `<button type="button" class="ln-btn ln-btn-outline" id="lnAnnDismiss">Dismiss</button>` : ''}
        <button type="button" class="ln-btn ln-btn-gold" id="lnAnnAction">${escapeHtml(announcement.buttonText || 'Continue')}</button>
      </div>
    </div>
  `;
  backdrop.classList.add('open');
  const dismiss = backdrop.querySelector('#lnAnnDismiss');
  if (dismiss) dismiss.onclick = () => backdrop.classList.remove('open');
  backdrop.querySelector('#lnAnnAction').onclick = () => {
    backdrop.classList.remove('open');
    if (onAction) onAction(announcement.buttonAction);
  };
}

/**
 * Progressive Custom Luxury Dropdown System
 * Replaces ugly Android/OS native <select> popups with sleek dark-theme floating dropdowns
 * while keeping the underlying <select class="ln-select"> values & change events 100% compatible.
 */
let activeDropdownCloseFn = null;

export function closeLuxuryDropdown() {
  if (activeDropdownCloseFn) {
    activeDropdownCloseFn();
    activeDropdownCloseFn = null;
  }
}

function syncLuxuryTrigger(select, trigger) {
  if (!select || !trigger) return;
  const opt = select.options[select.selectedIndex] || select.options[0];
  const nextText = opt ? opt.textContent : 'Select...';
  const labelEl = trigger.querySelector('.ln-cselect-label');
  if (labelEl && labelEl.textContent !== nextText) {
    labelEl.textContent = nextText;
  }
  const nextDisabled = Boolean(select.disabled);
  if (trigger.disabled !== nextDisabled) {
    trigger.disabled = nextDisabled;
  }
}

function openLuxuryDropdownMenu(select, trigger) {
  closeLuxuryDropdown();
  if (select.disabled) return;

  const backdrop = document.createElement('div');
  backdrop.className = 'ln-cselect-portal-backdrop';

  const menu = document.createElement('div');
  menu.className = 'ln-cselect-menu';
  menu.setAttribute('role', 'listbox');

  const rect = trigger.getBoundingClientRect();
  const margin = 12;
  const menuMinW = Math.max(rect.width, 190);
  const maxMenuW = Math.min(window.innerWidth - margin * 2, Math.max(menuMinW, 280));
  let left = rect.left;
  if (left + maxMenuW > window.innerWidth - margin) {
    left = Math.max(margin, window.innerWidth - maxMenuW - margin);
  }
  const spaceBelow = window.innerHeight - rect.bottom - margin;
  const spaceAbove = rect.top - margin;
  const openAbove = spaceBelow < 210 && spaceAbove > spaceBelow;

  menu.style.width = `${Math.round(rect.width)}px`;
  menu.style.minWidth = `${Math.round(Math.min(maxMenuW, Math.max(rect.width, 190)))}px`;
  menu.style.maxWidth = `${Math.round(window.innerWidth - margin * 2)}px`;
  menu.style.left = `${Math.round(left)}px`;
  if (openAbove) {
    menu.style.bottom = `${Math.round(window.innerHeight - rect.top + 6)}px`;
    menu.style.maxHeight = `${Math.min(280, Math.max(120, spaceAbove - 10))}px`;
  } else {
    menu.style.top = `${Math.round(rect.bottom + 6)}px`;
    menu.style.maxHeight = `${Math.min(280, Math.max(120, spaceBelow - 10))}px`;
  }

  const options = Array.from(select.options);
  options.forEach((opt, idx) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `ln-cselect-opt${opt.value === select.value ? ' selected' : ''}`;
    btn.setAttribute('role', 'option');
    btn.setAttribute('aria-selected', opt.value === select.value ? 'true' : 'false');
    btn.disabled = Boolean(opt.disabled);
    btn.innerHTML = `
      <span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(opt.textContent)}</span>
      ${opt.value === select.value ? '<span class="ln-cselect-check">✓</span>' : ''}
    `;
    btn.onclick = (ev) => {
      ev.stopPropagation();
      const changed = select.value !== opt.value || select.selectedIndex !== idx;
      select.value = opt.value;
      syncLuxuryTrigger(select, trigger);
      closeLuxuryDropdown();
      if (changed) {
        select.dispatchEvent(new Event('change', { bubbles: true }));
      }
      trigger.focus();
    };
    menu.appendChild(btn);
  });

  trigger.setAttribute('aria-expanded', 'true');
  document.body.appendChild(backdrop);
  document.body.appendChild(menu);

  const selectedBtn = menu.querySelector('.ln-cselect-opt.selected');
  if (selectedBtn && typeof selectedBtn.scrollIntoView === 'function') {
    selectedBtn.scrollIntoView({ block: 'nearest' });
  }

  const cleanup = () => {
    document.removeEventListener('keydown', onKeyDown);
    window.removeEventListener('resize', cleanup);
    backdrop.remove();
    menu.remove();
    trigger.setAttribute('aria-expanded', 'false');
    if (activeDropdownCloseFn === cleanup) activeDropdownCloseFn = null;
  };

  const onKeyDown = (ev) => {
    if (ev.key === 'Escape') {
      ev.preventDefault();
      cleanup();
      trigger.focus();
    }
  };

  backdrop.onclick = cleanup;
  document.addEventListener('keydown', onKeyDown);
  window.addEventListener('resize', cleanup);
  activeDropdownCloseFn = cleanup;
}

let isUpgradingSelects = false;

export function upgradeLuxurySelects(root = document) {
  if (typeof document === 'undefined' || !root?.querySelectorAll || isUpgradingSelects) return;
  isUpgradingSelects = true;
  try {
    const selects = root.querySelectorAll('select.ln-select:not([data-native-ignore])');
    selects.forEach((select) => {
      if (select.dataset.lnEnhanced === '1') {
        const wrap = select.closest('.ln-cselect');
        const trig = wrap?.querySelector('.ln-cselect-trigger');
        if (trig) syncLuxuryTrigger(select, trig);
        return;
      }
      select.dataset.lnEnhanced = '1';

      const wrap = document.createElement('div');
      wrap.className = 'ln-cselect';
      if (select.style.width) wrap.style.width = select.style.width;
      if (select.style.minWidth) wrap.style.minWidth = select.style.minWidth;

      const trigger = document.createElement('button');
      trigger.type = 'button';
      trigger.className = 'ln-cselect-trigger';
      trigger.setAttribute('aria-haspopup', 'listbox');
      trigger.setAttribute('aria-expanded', 'false');
      if (select.getAttribute('aria-label')) {
        trigger.setAttribute('aria-label', select.getAttribute('aria-label'));
      }
      trigger.innerHTML = `<span class="ln-cselect-label"></span><span class="ln-cselect-chevron" aria-hidden="true">▾</span>`;

      select.parentNode.insertBefore(wrap, select);
      wrap.appendChild(select);
      wrap.appendChild(trigger);

      select.classList.add('ln-select-native-hidden');
      select.setAttribute('tabindex', '-1');
      select.setAttribute('aria-hidden', 'true');

      syncLuxuryTrigger(select, trigger);

      trigger.onclick = (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        if (trigger.getAttribute('aria-expanded') === 'true') {
          closeLuxuryDropdown();
        } else {
          openLuxuryDropdownMenu(select, trigger);
        }
      };

      select.addEventListener('change', () => syncLuxuryTrigger(select, trigger));

      const optObserver = new MutationObserver(() => syncLuxuryTrigger(select, trigger));
      optObserver.observe(select, { childList: true, attributes: true, attributeFilter: ['disabled'] });
    });
  } finally {
    isUpgradingSelects = false;
  }
}

let selectObserverInitialized = false;
export function initLuxurySelectObserver() {
  if (typeof document === 'undefined' || selectObserverInitialized) return;
  selectObserverInitialized = true;
  upgradeLuxurySelects(document);
  let queued = false;
  const obs = new MutationObserver((mutations) => {
    if (isUpgradingSelects || queued) return;
    const hasSelectMutation = mutations.some((m) =>
      Array.from(m.addedNodes).some(
        (n) => n.nodeType === 1 && (n.matches?.('select.ln-select') || n.querySelector?.('select.ln-select:not([data-ln-enhanced="1"])'))
      )
    );
    if (!hasSelectMutation) return;
    queued = true;
    queueMicrotask(() => {
      queued = false;
      upgradeLuxurySelects(document);
    });
  });
  obs.observe(document.body, { childList: true, subtree: true });
}
