/**
 * LUXE NEXUS Shared Utilities
 * Pure, deterministic helpers usable in both browser modules and Node.js unit tests.
 */

export function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (ch) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  }[ch]));
}

export function escapeAttr(value) {
  return escapeHtml(value ?? '').replace(/`/g, '&#96;');
}

export function sanitizeUrl(url, allowDataImage = false) {
  const raw = String(url ?? '').trim();
  if (!raw) return '';
  if (raw.startsWith('/') && !raw.startsWith('//')) {
    return raw;
  }
  if (allowDataImage && /^data:image\/(png|jpeg|jpg|webp|gif);base64,[a-z0-9+/=]+$/i.test(raw)) {
    return raw;
  }
  try {
    const parsed = new URL(raw);
    if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
      return parsed.href;
    }
    return '';
  } catch {
    return '';
  }
}

export function roundMoney(amount) {
  const num = Number(amount);
  if (!Number.isFinite(num)) return 0;
  return Math.round((num + Number.EPSILON) * 100) / 100;
}

export const CURRENCY_META = {
  BDT: { symbol: '৳', code: 'BDT', locale: 'en-IN', decimals: 0 },
  USD: { symbol: '$', code: 'USD', locale: 'en-US', decimals: 2 },
  EUR: { symbol: '€', code: 'EUR', locale: 'en-IE', decimals: 2 },
  GBP: { symbol: '£', code: 'GBP', locale: 'en-GB', decimals: 2 },
};

export function convertMoney(amountBdt, currencyCode = 'BDT', exchangeRates = {}) {
  const base = roundMoney(amountBdt);
  if (currencyCode === 'BDT') return base;
  const rate = Number(exchangeRates[currencyCode]);
  if (!Number.isFinite(rate) || rate <= 0) return base;
  return roundMoney(base * rate);
}

export function formatMoney(amountBdt, currencyCode = 'BDT', exchangeRates = {}) {
  const meta = CURRENCY_META[currencyCode] || CURRENCY_META.BDT;
  const converted = convertMoney(amountBdt, meta.code, exchangeRates);
  const formatted = converted.toLocaleString(meta.locale, {
    minimumFractionDigits: meta.decimals,
    maximumFractionDigits: meta.decimals,
  });
  return `${meta.symbol}${formatted}`;
}

export function generateId(prefix = 'LN') {
  const ts = Date.now().toString(36).toUpperCase();
  const rand = Math.random().toString(36).slice(2, 7).toUpperCase();
  return `${prefix}-${ts}-${rand}`;
}

export function slugify(text) {
  return String(text ?? '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

export function compareSemver(a, b) {
  const pa = String(a ?? '0.0.0').replace(/^v/i, '').split('.').map((n) => parseInt(n, 10) || 0);
  const pb = String(b ?? '0.0.0').replace(/^v/i, '').split('.').map((n) => parseInt(n, 10) || 0);
  const len = Math.max(pa.length, pb.length, 3);
  for (let i = 0; i < len; i += 1) {
    const va = pa[i] || 0;
    const vb = pb[i] || 0;
    if (va > vb) return 1;
    if (va < vb) return -1;
  }
  return 0;
}

export function isVersionSupported(currentVersion, minSupportedVersion) {
  if (!minSupportedVersion) return true;
  return compareSemver(currentVersion, minSupportedVersion) >= 0;
}

export async function sha256Hex(input) {
  const text = String(input ?? '');
  if (typeof globalThis !== 'undefined' && globalThis.crypto && globalThis.crypto.subtle) {
    const data = new TextEncoder().encode(text);
    const digest = await globalThis.crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(digest))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }
  // Fallback deterministic FNV-1a 64-bit hex for environments without subtle crypto
  let h1 = 0x811c9dc5;
  let h2 = 0x811c9dc5;
  for (let i = 0; i < text.length; i += 1) {
    const c = text.charCodeAt(i);
    h1 ^= c;
    h1 = Math.imul(h1, 0x01000193);
    h2 ^= c ^ (i & 0xff);
    h2 = Math.imul(h2, 0x01000193);
  }
  return `${(h1 >>> 0).toString(16).padStart(8, '0')}${(h2 >>> 0).toString(16).padStart(8, '0')}`;
}

export function toCsv(headers, rows) {
  const escCell = (cell) => {
    const str = String(cell ?? '');
    if (/[",\n\r]/.test(str)) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };
  const lines = [headers.map(escCell).join(',')];
  for (const row of rows) {
    lines.push(row.map(escCell).join(','));
  }
  return lines.join('\n');
}

export function formatDate(isoOrMs) {
  if (!isoOrMs) return '—';
  const d = new Date(isoOrMs);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

export function formatDateTime(isoOrMs) {
  if (!isoOrMs) return '—';
  const d = new Date(isoOrMs);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function isWithinSchedule(startDate, endDate, nowMs = Date.now()) {
  if (startDate) {
    const s = new Date(startDate).getTime();
    if (Number.isFinite(s) && nowMs < s) return false;
  }
  if (endDate) {
    const e = new Date(endDate).getTime();
    if (Number.isFinite(e) && nowMs > e) return false;
  }
  return true;
}

/**
 * Generates a deterministic 21x21 QR-like finder-patterned matrix for offline QR previewing.
 * Encodes a payload hash into data modules while preserving standard 3-corner finder patterns.
 */
export function generateQrMatrix(payload) {
  const size = 21;
  const grid = Array.from({ length: size }, () => Array(size).fill(0));
  const placeFinder = (r0, c0) => {
    for (let r = 0; r < 7; r += 1) {
      for (let c = 0; c < 7; c += 1) {
        const border = r === 0 || r === 6 || c === 0 || c === 6;
        const center = r >= 2 && r <= 4 && c >= 2 && c <= 4;
        grid[r0 + r][c0 + c] = border || center ? 1 : 0;
      }
    }
  };
  placeFinder(0, 0);
  placeFinder(0, size - 7);
  placeFinder(size - 7, 0);

  const str = String(payload || 'LUXE-NEXUS');
  let hash = 2166136261;
  for (let i = 0; i < str.length; i += 1) {
    hash ^= str.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  for (let r = 0; r < size; r += 1) {
    for (let c = 0; c < size; c += 1) {
      const inTopLeft = r < 8 && c < 8;
      const inTopRight = r < 8 && c >= size - 8;
      const inBottomLeft = r >= size - 8 && c < 8;
      if (inTopLeft || inTopRight || inBottomLeft) continue;
      if (r === 6 || c === 6) {
        grid[r][c] = (r + c) % 2 === 0 ? 1 : 0;
        continue;
      }
      const idx = (r * size + c) % str.length;
      const charBit = (str.charCodeAt(idx) >> ((r + c) % 7)) & 1;
      hash ^= r * 31 + c * 17 + str.charCodeAt(idx);
      hash = Math.imul(hash, 16777619);
      grid[r][c] = ((hash >>> ((r + c) % 16)) & 1) ^ charBit;
    }
  }
  return grid;
}

export function getDisplayUserName(user) {
  if (!user || typeof user !== 'object') return 'Luxe Nexus';
  const candidates = [user.username, user.displayName, user.name];
  for (const raw of candidates) {
    const val = String(raw ?? '').trim();
    if (!val) continue;
    const lower = val.toLowerCase();
    if (['undefined', 'null', 'user', 'users', 'user software', 'guest'].includes(lower)) continue;
    return val;
  }
  return 'Luxe Nexus';
}

/**
 * Builds a clean, validated canonical share URL for a product.
 * @param {{ origin?: string, productId: string, affiliateCode?: string | null }} params
 * @returns {string}
 */
export function buildProductShareUrl({ origin = '', productId, affiliateCode = '' }) {
  const baseOrigin = String(origin || '').replace(/\/+$/, '');
  const qp = new URLSearchParams();
  if (productId) qp.set('product', String(productId).trim());
  if (affiliateCode) qp.set('ref', String(affiliateCode).trim());
  const query = qp.toString();
  return `${baseOrigin}/${query ? `?${query}` : ''}`;
}

/**
 * Generates sanitized sharing metadata and social target links for a product.
 * @param {{ url: string, title?: string, priceText?: string }} params
 */
export function buildProductShareTargets({ url, title = 'LUXE NEXUS', priceText = '' }) {
  const safeUrl = String(url || '').trim();
  const cleanTitle = String(title || 'LUXE NEXUS').trim();
  const shareText = priceText ? `${cleanTitle} (${priceText}) — LUXE NEXUS` : `${cleanTitle} — LUXE NEXUS`;
  const encodedUrl = encodeURIComponent(safeUrl);
  const encodedText = encodeURIComponent(`${shareText} ${safeUrl}`.trim());
  const encodedSummary = encodeURIComponent(shareText);
  return {
    url: safeUrl,
    title: cleanTitle,
    text: shareText,
    whatsapp: `https://wa.me/?text=${encodedText}`,
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
    twitter: `https://twitter.com/intent/tweet?text=${encodedSummary}&url=${encodedUrl}`,
    telegram: `https://t.me/share/url?url=${encodedUrl}&text=${encodedSummary}`,
  };
}

