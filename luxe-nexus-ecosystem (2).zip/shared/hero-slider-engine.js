/**
 * LUXE NEXUS Shared Hero Banner / Slider DOM Engine
 * Used by both User App storefront and Admin App Live Preview.
 */

import { escapeHtml, escapeAttr } from './utilities.js';
import {
  computeHeroLayoutStyles,
  normalizeHeroSliderConfig,
  resolveHeroSlideImage,
} from '../services/hero-banner-service.js';

export function mountHeroSlider(container, options = {}) {
  if (!container) return { destroy() {}, goTo() {}, next() {}, prev() {} };

  const slides = Array.isArray(options.slides) ? options.slides : [];
  const heroCfg = normalizeHeroSliderConfig(options.heroSlider || {});
  const viewportWidth = Number(options.viewportWidth || (typeof window !== 'undefined' ? window.innerWidth : 1280));
  const headingTag = options.headingTag === 'h2' ? 'h2' : 'h1';
  const onSlideLink = typeof options.onSlideLink === 'function' ? options.onSlideLink : () => {};
  const onSlideChange = typeof options.onSlideChange === 'function' ? options.onSlideChange : () => {};

  if (!slides.length) {
    container.innerHTML = '';
    return { destroy() {}, goTo() {}, next() {}, prev() {} };
  }

  let activeIdx = Math.max(0, Math.min(Number(options.initialIdx || 0), slides.length - 1));
  let timer = null;
  let hovered = false;
  let pausedByInteraction = false;
  let destroyed = false;

  const styles = computeHeroLayoutStyles(heroCfg, viewportWidth);
  const sideGap = styles.isMobile ? Math.min(heroCfg.bannerSpacing, 16) : Math.min(heroCfg.bannerSpacing, 32);
  const maxWidthRule =
    styles.isMobile
      ? `calc(100% - ${sideGap * 2}px)`
      : heroCfg.desktopSizePreset === 'wide'
      ? '100%'
      : `min(${styles.maxWidthCss}, calc(100% - ${sideGap * 2}px))`;
  const stageStyle = [
    `height:${styles.heightCss}`,
    `min-height:${styles.minHeightCss}`,
    `max-height:${styles.maxHeightCss}`,
    styles.aspectRatio !== 'auto' ? `aspect-ratio:${styles.aspectRatio}` : '',
    `max-width:${maxWidthRule}`,
    `border-radius:${styles.borderRadiusCss}`,
    `margin:${heroCfg.bannerSpacing}px auto`,
    `--hero-dur:${styles.durationMs}ms`,
    `--hero-ease:${styles.easing}`,
    `--hero-zoom-scale:${styles.zoomScale}`,
    `--hero-fit:${styles.objectFit}`,
    `--hero-pos:${styles.objectPosition}`,
  ]
    .filter(Boolean)
    .join(';');

  const slidesHtml = slides
    .map((s, i) => {
      const imgUrl = resolveHeroSlideImage(s, viewportWidth);
      const isAct = i === activeIdx;
      const subtitle = s.subtitle || s.eyebrow || '';
      const btnHtml = s.button
        ? `<div style="margin-top:14px;"><button type="button" class="ln-btn ln-btn-gold" data-hero-link="${escapeAttr(s.link || 'category:all')}">${escapeHtml(s.button)}</button></div>`
        : '';
      return `
        <div class="ln-hero-slide ${isAct ? 'is-active' : ''}" data-slide-idx="${i}" aria-hidden="${isAct ? 'false' : 'true'}">
          ${imgUrl ? `<img class="ln-hero-img" src="${escapeAttr(imgUrl)}" alt="${escapeAttr(s.title || 'LUXE NEXUS Banner')}" referrerpolicy="no-referrer" />` : ''}
          <div class="ln-hero-scrim" aria-hidden="true"></div>
          <div class="ln-hero-content">
            ${subtitle ? `<div class="u-hero-eyebrow">${escapeHtml(subtitle)}</div>` : ''}
            <${headingTag}>${escapeHtml(s.title || '')}</${headingTag}>
            ${s.desc ? `<p>${escapeHtml(s.desc)}</p>` : ''}
            ${btnHtml}
          </div>
        </div>
      `;
    })
    .join('');

  const arrowsHtml =
    heroCfg.showArrows && slides.length > 1
      ? `
      <button type="button" class="ln-hero-arrow prev" data-hero-prev aria-label="Previous slide">‹</button>
      <button type="button" class="ln-hero-arrow next" data-hero-next aria-label="Next slide">›</button>
    `
      : '';

  const dotsHtml =
    heroCfg.showDots && slides.length > 1
      ? `<div class="ln-hero-dots" role="tablist" aria-label="Banner Slides">${slides
          .map(
            (_, i) =>
              `<button type="button" role="tab" aria-selected="${i === activeIdx ? 'true' : 'false'}" aria-label="Slide ${i + 1}" class="${i === activeIdx ? 'active' : ''}" data-hero-dot="${i}"></button>`
          )
          .join('')}</div>`
      : '';

  container.innerHTML = `
    <section class="ln-hero-stage" id="${escapeAttr(options.stageId || 'uHeroStage')}" style="${escapeAttr(stageStyle)}" data-anim-mode="${escapeAttr(heroCfg.animationType)}">
      <div class="ln-hero-track" data-anim="${escapeAttr(heroCfg.animationType)}">
        ${slidesHtml}
      </div>
      ${arrowsHtml}
      ${dotsHtml}
    </section>
  `;

  const stage = container.querySelector('.ln-hero-stage');
  const track = container.querySelector('.ln-hero-track');
  const slideEls = Array.from(container.querySelectorAll('.ln-hero-slide'));
  const dotEls = Array.from(container.querySelectorAll('[data-hero-dot]'));
  const prevBtn = container.querySelector('[data-hero-prev]');
  const nextBtn = container.querySelector('[data-hero-next]');

  // Hide broken external images gracefully without showing a broken icon
  container.querySelectorAll('.ln-hero-img').forEach((img) => {
    img.addEventListener('error', () => {
      img.style.display = 'none';
    });
  });

  const applySlideState = () => {
    if (destroyed) return;
    if (heroCfg.animationType === 'slide-horizontal') {
      track.style.transform = `translateX(-${activeIdx * 100}%)`;
    } else if (heroCfg.animationType === 'slide-vertical') {
      track.style.transform = `translateY(-${activeIdx * 100}%)`;
    } else {
      track.style.transform = '';
    }

    slideEls.forEach((el, idx) => {
      const act = idx === activeIdx;
      el.classList.toggle('is-active', act);
      el.setAttribute('aria-hidden', act ? 'false' : 'true');
    });

    dotEls.forEach((d, idx) => {
      const act = idx === activeIdx;
      d.classList.toggle('active', act);
      d.setAttribute('aria-selected', act ? 'true' : 'false');
    });

    if (prevBtn) prevBtn.disabled = !heroCfg.loop && activeIdx <= 0;
    if (nextBtn) nextBtn.disabled = !heroCfg.loop && activeIdx >= slides.length - 1;
  };

  const stopTimer = () => {
    if (timer) {
      clearInterval(timer);
      timer = null;
    }
  };

  const startTimer = () => {
    stopTimer();
    if (destroyed || !heroCfg.autoSlide || slides.length <= 1) return;
    if ((heroCfg.pauseOnHover && hovered) || (heroCfg.pauseOnInteraction && pausedByInteraction)) return;
    timer = setInterval(() => {
      if (destroyed) return;
      if ((heroCfg.pauseOnHover && hovered) || (heroCfg.pauseOnInteraction && pausedByInteraction)) return;
      if (!heroCfg.loop && activeIdx >= slides.length - 1) {
        stopTimer();
        return;
      }
      goTo(activeIdx + 1, { fromAuto: true });
    }, heroCfg.autoSlideIntervalSec * 1000);
  };

  const goTo = (rawIdx, { fromAuto = false } = {}) => {
    if (destroyed || !slides.length) return;
    let target = Number(rawIdx);
    if (heroCfg.loop) {
      target = ((target % slides.length) + slides.length) % slides.length;
    } else {
      target = Math.max(0, Math.min(target, slides.length - 1));
    }
    if (target === activeIdx && !fromAuto) return;
    activeIdx = target;
    applySlideState();
    onSlideChange(activeIdx);
    if (!fromAuto && heroCfg.pauseOnInteraction) {
      pausedByInteraction = true;
      stopTimer();
    }
  };

  if (prevBtn) prevBtn.onclick = () => goTo(activeIdx - 1, { fromAuto: false });
  if (nextBtn) nextBtn.onclick = () => goTo(activeIdx + 1, { fromAuto: false });
  dotEls.forEach((dot) => {
    dot.onclick = () => goTo(Number(dot.dataset.heroDot), { fromAuto: false });
  });
  container.querySelectorAll('[data-hero-link]').forEach((btn) => {
    btn.onclick = () => onSlideLink(btn.dataset.heroLink || 'category:all');
  });

  const onEnter = () => {
    hovered = true;
    if (heroCfg.pauseOnHover) stopTimer();
  };
  const onLeave = () => {
    hovered = false;
    if (heroCfg.pauseOnHover) startTimer();
  };
  if (stage) {
    stage.addEventListener('mouseenter', onEnter);
    stage.addEventListener('mouseleave', onLeave);
  }

  applySlideState();
  startTimer();

  return {
    goTo: (i) => goTo(i, { fromAuto: false }),
    next: () => goTo(activeIdx + 1, { fromAuto: false }),
    prev: () => goTo(activeIdx - 1, { fromAuto: false }),
    getActiveIndex: () => activeIdx,
    destroy() {
      destroyed = true;
      stopTimer();
      if (stage) {
        stage.removeEventListener('mouseenter', onEnter);
        stage.removeEventListener('mouseleave', onLeave);
      }
    },
  };
}
