/**
 * LUXE NEXUS Role-Based Access Control (RBAC) & Permissions
 */

export const ROLES = {
  SUPER_ADMIN: 'super_admin',
  ADMIN: 'admin',
  OPERATIONS_MANAGER: 'operations_manager',
  PRODUCT_MANAGER: 'product_manager',
  ORDER_MANAGER: 'order_manager',
  FINANCE_MANAGER: 'finance_manager',
  AFFILIATE_MANAGER: 'affiliate_manager',
  CUSTOMER_SUPPORT: 'customer_support',
  SELLER: 'seller',
  AFFILIATE: 'affiliate',
  CUSTOMER: 'customer',
};

export const ROLE_LABELS = {
  super_admin: 'Super Admin',
  admin: 'Admin',
  operations_manager: 'Operations Manager',
  product_manager: 'Product Manager',
  order_manager: 'Order Manager',
  finance_manager: 'Finance Manager',
  affiliate_manager: 'Affiliate Manager',
  customer_support: 'Customer Support',
  seller: 'Seller',
  affiliate: 'Affiliate',
  customer: 'Customer',
};

export const PERMISSIONS = [
  'view',
  'create',
  'edit',
  'delete',
  'approve',
  'reject',
  'export',
  'manage_settings',
  'manage_users',
  'manage_orders',
  'manage_payments',
];

export const DEFAULT_ROLE_MATRIX = {
  super_admin: [...PERMISSIONS],
  admin: [
    'view',
    'create',
    'edit',
    'delete',
    'approve',
    'reject',
    'export',
    'manage_settings',
    'manage_users',
    'manage_orders',
    'manage_payments',
  ],
  operations_manager: ['view', 'create', 'edit', 'approve', 'reject', 'export', 'manage_orders'],
  product_manager: ['view', 'create', 'edit', 'delete', 'approve', 'reject', 'export'],
  order_manager: ['view', 'edit', 'approve', 'reject', 'export', 'manage_orders'],
  finance_manager: ['view', 'approve', 'reject', 'export', 'manage_payments'],
  affiliate_manager: ['view', 'create', 'edit', 'approve', 'reject', 'export'],
  customer_support: ['view', 'edit', 'manage_orders'],
  seller: ['view', 'create', 'edit', 'delete', 'export'],
  affiliate: ['view', 'create', 'export'],
  customer: ['view', 'create'],
};

export const ADMIN_ROLES = new Set([
  ROLES.SUPER_ADMIN,
  ROLES.ADMIN,
  ROLES.OPERATIONS_MANAGER,
  ROLES.PRODUCT_MANAGER,
  ROLES.ORDER_MANAGER,
  ROLES.FINANCE_MANAGER,
  ROLES.AFFILIATE_MANAGER,
  ROLES.CUSTOMER_SUPPORT,
]);

export function hasPermission(role, permission, customMatrix = null) {
  if (!role || !permission) return false;
  if (role === ROLES.SUPER_ADMIN) return true; // Super Admin protection invariant
  const matrix = customMatrix || DEFAULT_ROLE_MATRIX;
  const list = matrix[role] || DEFAULT_ROLE_MATRIX[role] || [];
  return list.includes(permission);
}

export function isAdminRole(role) {
  return ADMIN_ROLES.has(role);
}

export function canModifyRoleMatrix(actorRole, targetRole) {
  if (actorRole !== ROLES.SUPER_ADMIN) return false;
  if (targetRole === ROLES.SUPER_ADMIN) return false; // Super Admin permissions are immutable
  return true;
}

export function canAccessFeature(featureFlag, role = ROLES.CUSTOMER) {
  if (!featureFlag) return true;
  if (featureFlag.enabled === false) return false;
  if (Array.isArray(featureFlag.allowedRoles) && featureFlag.allowedRoles.length > 0) {
    if (role === ROLES.SUPER_ADMIN) return true;
    return featureFlag.allowedRoles.includes(role);
  }
  return true;
}
