/**
 * LUXE NEXUS User App Controller
 * Pure Vanilla ES Module driving Storefront, Product Details, Cart, Unified Checkout,
 * 10-Stage Orders, Advanced 7-Day Affiliate Portal, International Settings, & Update Delivery.
 */

import { appServices } from '../adapters/backend-adapter.js';
import {
  ensureEcosystemSeeded,
  getPlatformConfig,
  getActiveHomepageSections,
  getActiveNavigation,
  getFeatureStatus,
  getActiveAnnouncements,
  getUserInternationalPrefs,
  setUserInternationalPrefs,
  applyDesignTokensToDocument,
  t,
} from '../services/settings-service.js';
import {
  signupAccount,
  loginAccount,
  getActiveUser,
  logoutAccount,
  resetPassword,
  updateAccountProfile,
  verifyAccountContact,
} from '../services/auth-service.js';
import {
  listPublishedProducts,
  listCategories,
  listProductReviews,
  submitProductReview,
  listProductQuestions,
  submitProductQuestion,
} from '../services/product-service.js';
import {
  getCart,
  getCartCount,
  addToCart,
  updateCartItemQty,
  removeFromCart,
  calculateOrderTotals,
  createValidatedOrder,
  listOrdersForUser,
  updateOrderDeliveryDetails,
  updateOrderStatus,
} from '../services/order-service.js';
import {
  AFFILIATE_PROGRAM_RULES,
  getAffiliateByUserId,
  applyForAffiliate,
  createAffiliateLink,
  listAffiliateLinks,
  setAffiliateLinkState,
  trackReferralClick,
  getAffiliateDashboardMetrics,
  requestAffiliateWithdrawal,
  getAffiliateLeaderboard,
  updateAffiliateProfile,
  evaluateLinkStatus,
  evaluateAffiliateEligibility,
  evaluateAffiliateLevel,
  getAffiliateLevels,
} from '../services/affiliate-service.js';
import { getAvailablePaymentMethods } from '../services/payment-service.js';
import { getUnreadCount, getNotificationsForScope } from '../services/notification-service.js';
import { checkUpdateStatus, applyAppUpdate, skipAppUpdate } from '../services/update-service.js';
import {
  escapeHtml,
  escapeAttr,
  sanitizeUrl,
  formatMoney,
  formatDateTime,
  roundMoney,
  getDisplayUserName,
  buildProductShareUrl,
  buildProductShareTargets,
} from '../shared/utilities.js';
import { evaluatePasswordStrength } from '../shared/validators.js';
import { OFFICIAL_LOGO_URL } from '../shared/configuration.js';
import {
  showToast,
  renderQrSvg,
  renderNotificationModal,
  renderUpdateModal,
  renderAnnouncementModal,
  openConfirmDialog,
  initLuxurySelectObserver,
} from '../shared/shared-components.js';
import { getActiveHeroSlides, normalizeHeroSlide } from '../services/hero-banner-service.js';
import { mountHeroSlider } from '../shared/hero-slider-engine.js';
import {
  buildProductColorOptions,
  buildProductSizeOptions,
  resolveVariantStock,
  clampVariantQty,
  resolveDefaultVariantSelection,
  validateBuyNowSelection,
} from '../services/variant-service.js';

const state = {
  bannerIdx: 0,
  heroController: null,
  lastIsMobile: typeof window !== 'undefined' ? window.innerWidth < 760 : false,
  orderTimer: null,
  currentPage: null,
  activeProductId: null,
  activeImageIdx: 0,
  activePdpTab: 'description',
  selectedSize: '',
  selectedColor: '',
  variantQty: 1,
  variantPopupProductId: null,
  pendingBuyNowCheckout: false,
  selectedArea: localStorage.getItem('ln_user_area') || 'dhaka',
  couponCode: '',
  checkoutMode: 'cart', // 'cart' | 'buy_now'
  buyNowItem: null,
  idempotencyKey: '',
  authMode: 'login',
  affiliateTab: 'dashboard',
  leaderboardPeriod: 'monthly',
  compareIds: JSON.parse(localStorage.getItem('ln_compare_ids') || '[]'),
  wishlist: JSON.parse(localStorage.getItem('ln_wishlist_ids') || '[]'),
  filters: {
    search: '',
    category: 'All',
    brand: 'All',
    minPrice: '',
    maxPrice: '',
    sort: 'featured',
    inStockOnly: false,
  },
};

const $ = (id) => document.getElementById(id);

function money(amountBdt) {
  const cfg = getPlatformConfig();
  const prefs = getUserInternationalPrefs();
  return formatMoney(amountBdt, prefs.currency, cfg.international.exchangeRates);
}

function lang() {
  return getUserInternationalPrefs().language || 'en';
}

function getVisitorId() {
  let vid = localStorage.getItem('ln_visitor_id');
  if (!vid) {
    vid = `VIS-${Math.random().toString(36).slice(2, 10)}`;
    localStorage.setItem('ln_visitor_id', vid);
  }
  return vid;
}

function captureIncomingReferral() {
  const params = new URLSearchParams(window.location.search);
  const code = params.get('ref') || params.get('aff');
  if (code) {
    const user = getActiveUser('user');
    const res = trackReferralClick({
      code,
      visitorId: getVisitorId(),
      source: params.get('src') || 'referral_link',
      buyerUserId: user?.uid || null,
    });
    if (res.attributed) {
      showToast('Referral link verified and active for this session.', 'success');
    }
  }
  const targetProd = params.get('product');
  const targetCat = params.get('cat');
  if (targetProd) {
    setTimeout(() => openProductDetails(targetProd), 80);
  } else if (targetCat) {
    state.filters.category = targetCat;
  }
}

function updateBadges() {
  const cartBadge = $('headerCartBadge');
  if (cartBadge) cartBadge.textContent = String(getCartCount());
  const user = getActiveUser('user');
  const unread = getUnreadCount('user', user?.uid || '');
  const notifBadge = $('uNotifBadge');
  if (notifBadge) {
    notifBadge.textContent = String(unread);
    notifBadge.style.display = unread > 0 ? 'grid' : 'none';
  }
}

function renderBrandAndNav() {
  const cfg = getPlatformConfig();
  applyDesignTokensToDocument(cfg);
  const logoSrc = sanitizeUrl(cfg.logo, true) || OFFICIAL_LOGO_URL;
  if ($('uBrandLogoImg')) $('uBrandLogoImg').src = logoSrc;
  if ($('uDrawerLogoImg')) $('uDrawerLogoImg').src = logoSrc;
  $('uBrandName').textContent = cfg.brand || 'LUXE NEXUS';
  $('uAnnounceBar').textContent = cfg.announce || '';
  $('uAnnounceBar').style.display = cfg.announce ? 'block' : 'none';
  $('uSearchInput').placeholder = cfg.pages?.searchText || 'Search curated products...';

  const user = getActiveUser('user');
  const displayName = getDisplayUserName(user);
  if ($('headerUserLabel')) $('headerUserLabel').textContent = displayName;
  if ($('uDrawerUserLabel')) $('uDrawerUserLabel').textContent = displayName;

  // Header Nav (replace generic User / Users / User Software / Storefront labels with dynamic user/guest name)
  const genericUserLabels = new Set(['storefront', 'user', 'users', 'user software']);
  const headerLinks = getActiveNavigation('headerNav', user?.role || 'customer');
  $('uHeaderNav').innerHTML = headerLinks
    .map((n) => {
      const lbl = genericUserLabels.has(String(n.label || '').trim().toLowerCase()) ? displayName : n.label;
      return `<button type="button" data-nav-target="${escapeAttr(n.id)}">${escapeHtml(lbl)}</button>`;
    })
    .join('');

  // Bottom 5 Nav
  const bottomLinks = getActiveNavigation('bottomNav', user?.role || 'customer');
  $('uBottomNav').innerHTML = bottomLinks
    .map(
      (n) => `
      <button type="button" class="u-nav-btn ${(!state.currentPage && n.id === 'home') || state.currentPage === n.id ? 'active' : ''}" data-nav-target="${escapeAttr(n.id)}">
        <span class="u-nav-icon" aria-hidden="true">${escapeHtml(n.icon || '•')}</span>
        <span class="u-nav-label">${escapeHtml(t(n.id, lang()) !== n.id ? t(n.id, lang()) : n.label)}</span>
      </button>`
    )
    .join('');

  // Drawer Links (includes Share LUXE NEXUS inside the main menu alongside Concierge Support)
  const drawerLinks = getActiveNavigation('discoverMenu', user?.role || 'customer');
  $('uDrawerLinks').innerHTML =
    drawerLinks
      .map(
        (n) => `<button type="button" class="u-drawer-link" data-nav-target="${escapeAttr(n.id)}"><span>${escapeHtml(n.icon || '•')}</span>${escapeHtml(n.label)}</button>`
      )
      .join('') +
    `<button type="button" class="u-drawer-link" id="btnDrawerShare"><span>↗</span>Share LUXE NEXUS</button>`;

  const shareBtn = $('btnDrawerShare');
  if (shareBtn) {
    shareBtn.onclick = async () => {
      toggleDrawer(false);
      const link = getPlatformConfig().appShareLink || window.location.href;
      await navigator.clipboard?.writeText(link).catch(() => {});
      showToast('Store link copied to clipboard', 'success');
    };
  }

  $('btnDrawerAccount').textContent = user ? `${displayName} · My Account` : `${displayName} · Sign In`;

  document.querySelectorAll('[data-nav-target]').forEach((btn) => {
    btn.onclick = () => {
      toggleDrawer(false);
      navigateTo(btn.dataset.navTarget);
    };
  });
}

function populateFilterOptions() {
  const cats = listCategories();
  const prods = listPublishedProducts();
  const brands = [...new Set(prods.map((p) => p.brand).filter(Boolean))];
  $('fCategory').innerHTML = `<option value="All">All Categories</option>${cats
    .map((c) => `<option value="${escapeAttr(c.name)}" ${state.filters.category === c.name ? 'selected' : ''}>${escapeHtml(c.name)}</option>`)
    .join('')}`;
  $('fBrand').innerHTML = `<option value="All">All Brands</option>${brands
    .map((b) => `<option value="${escapeAttr(b)}" ${state.filters.brand === b ? 'selected' : ''}>${escapeHtml(b)}</option>`)
    .join('')}`;
}

function renderProductCards(list, { gridClass = 'u-grid' } = {}) {
  if (!list.length) {
    return `<div class="ln-empty" style="margin:0 0 24px;"><h4>No products match your criteria</h4><p style="font-size:12px;">Try selecting another category or clearing filters.</p></div>`;
  }
  return `<div class="${escapeAttr(gridClass)}">${list
    .map((p) => {
      const price = Number(p.offerPrice || p.price);
      const old = Number(p.price);
      const discPct = old > price ? Number(p.discountPercent || Math.round(((old - price) / old) * 100)) : 0;
      const img = sanitizeUrl(p.image || (p.images && p.images[0]), true);
      return `
      <article class="u-prod-card">
        <div class="u-prod-img-wrap" data-open-prod="${escapeAttr(p.id)}" style="cursor:pointer;">
          ${img ? `<img src="${escapeAttr(img)}" alt="${escapeAttr(p.name)}" referrerpolicy="no-referrer" />` : `<div class="ln-img-fallback" style="height:100%">${escapeHtml(p.name)}</div>`}
        </div>
        <div class="u-prod-body">
          <div class="u-prod-meta">${escapeHtml(p.brand || p.cat)} · ★ ${escapeHtml(p.rating || '4.8')}</div>
          <div class="u-prod-name">${escapeHtml(p.name)}</div>
          <div class="u-price-row" style="flex-wrap:wrap;">
            <span class="u-price">${money(price)}</span>
            ${old > price ? `<span class="u-old-price">${money(old)}</span>` : ''}
            ${discPct > 0 ? `<span class="u-disc-badge">${discPct}% OFF</span>` : ''}
          </div>
          <div class="u-prod-actions">
            <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-open-prod="${escapeAttr(p.id)}">${escapeHtml(t('seeMore', lang()))}</button>
          </div>
        </div>
      </article>`;
    })
    .join('')}</div>`;
}

function renderHomeSections() {
  const cfg = getPlatformConfig();
  const host = $('uHomeSections');

  if (cfg.platformFlags?.maintenanceMode) {
    host.innerHTML = `<div class="ln-card" style="margin:24px 16px;text-align:center;padding:40px 20px;"><h2>Scheduled Maintenance</h2><p style="color:var(--text-muted);margin-top:8px;">${escapeHtml(cfg.platformFlags.maintenanceMessage)}</p></div>`;
    return;
  }

  const hasActiveSearch =
    state.filters.search ||
    state.filters.category !== 'All' ||
    state.filters.brand !== 'All' ||
    state.filters.minPrice !== '' ||
    state.filters.maxPrice !== '' ||
    state.filters.inStockOnly;

  if (hasActiveSearch) {
    const filtered = listPublishedProducts(state.filters);
    host.innerHTML = `
      <div class="u-sec-head">
        <div><h2>Discovery Results (${filtered.length})</h2><small>Filtered catalog matches</small></div>
        <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="btnClearFilters">Clear Filters</button>
      </div>
      ${renderProductCards(filtered)}
    `;
    bindProductCardHandlers(host);
    const clearBtn = $('btnClearFilters');
    if (clearBtn) {
      clearBtn.onclick = () => {
        state.filters = { search: '', category: 'All', brand: 'All', minPrice: '', maxPrice: '', sort: 'featured', inStockOnly: false };
        $('uSearchInput').value = '';
        $('fMinPrice').value = '';
        $('fMaxPrice').value = '';
        $('fInStock').checked = false;
        populateFilterOptions();
        renderHomeSections();
      };
    }
    return;
  }

  if (state.heroController) {
    state.heroController.destroy();
    state.heroController = null;
  }

  const sections = getActiveHomepageSections();
  const cats = listCategories();
  const allProds = listPublishedProducts();

  const configuredSlides = Array.isArray(cfg.bannerSlides) ? cfg.bannerSlides : [];
  const activeHeroSlides = configuredSlides.length
    ? getActiveHeroSlides(cfg)
    : [
        normalizeHeroSlide(
          {
            eyebrow: cfg.eyebrow,
            subtitle: cfg.eyebrow,
            title: cfg.heroTitle,
            desc: cfg.heroDesc,
            image: cfg.heroImage,
            button: cfg.heroButton,
            link: cfg.heroLink,
          },
          0
        ),
      ];

  const html = sections
    .map((sec) => {
      if (sec.type === 'hero') {
        if (!activeHeroSlides.length) return '';
        return '<div id="uHeroBannerSlot"></div>';
      }
      if (sec.type === 'categories') {
        return `
          <section class="u-cat-section" aria-label="${escapeAttr(sec.title)}">
            <div class="u-sec-head u-cat-head">
              <div><h2>${escapeHtml(sec.title)}</h2><small>${escapeHtml(sec.subtitle)}</small></div>
              <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-nav-target="categories">See All</button>
            </div>
            <div class="u-cat-row u-cat-hex-grid">
              ${cats
                .map((c, idx) => {
                  const im = sanitizeUrl(c.image, true);
                  return `
                    <button type="button" class="u-cat-hex-btn" data-pick-cat="${escapeAttr(c.name)}" style="--hex-idx:${idx};">
                      <span class="u-cat-hex-wrap" aria-hidden="true">
                        <span class="u-cat-hex-frame">
                          <span class="u-cat-hex-core">
                            ${im ? `<img src="${escapeAttr(im)}" alt="" referrerpolicy="no-referrer" />` : `<span class="u-cat-hex-emoji">${escapeHtml(c.icon || '🛍️')}</span>`}
                          </span>
                        </span>
                      </span>
                      <span class="u-cat-hex-label">${escapeHtml(c.name)}</span>
                    </button>`;
                })
                .join('')}
            </div>
          </section>`;
      }
      if (sec.type === 'promo') {
        if (!getFeatureStatus('promotions').enabled) return '';
        return `
          <section style="padding:0 16px;margin:14px 0;">
            <div class="ln-card" style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:14px;background:var(--surface);">
              <div>
                <div style="font-size:11px;font-weight:700;color:var(--gold);text-transform:uppercase;">${escapeHtml(sec.title)}</div>
                <h3 style="font-size:16px;margin:2px 0;">${escapeHtml(cfg.promoTitle || sec.title)}</h3>
                <p style="font-size:13px;color:var(--text-muted);">${escapeHtml(cfg.promoDesc || sec.subtitle)}</p>
              </div>
              <div style="display:flex;gap:8px;flex-wrap:wrap;">
                <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-nav-target="affiliate">Partner Affiliate Program</button>
              </div>
            </div>
          </section>`;
      }
      if (['featured', 'trending', 'newArrivals', 'bestSellers', 'recommended'].includes(sec.type)) {
        const subset = sec.type === 'recommended' ? allProds.slice(0, 4) : listPublishedProducts({ sectionType: sec.type });
        if (!subset.length) return '';
        return `
          <section>
            <div class="u-sec-head">
              <div><h2>${escapeHtml(sec.title)}</h2><small>${escapeHtml(sec.subtitle)}</small></div>
              <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-nav-target="categories">View All</button>
            </div>
            ${renderProductCards(subset)}
          </section>`;
      }
      if (sec.type === 'brands') {
        const brands = [...new Set(allProds.map((p) => p.brand).filter(Boolean))];
        return `
          <section style="padding:0 16px;margin:18px 0;">
            <div class="u-sec-head" style="padding:0;margin:0 0 10px;">
              <div><h2>${escapeHtml(sec.title)}</h2><small>${escapeHtml(sec.subtitle)}</small></div>
            </div>
            <div style="display:flex;flex-wrap:wrap;gap:8px;">
              ${brands.map((b) => `<button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-pick-brand="${escapeAttr(b)}">${escapeHtml(b)}</button>`).join('')}
            </div>
          </section>`;
      }
      if (sec.type === 'custom') {
        return `
          <section style="padding:0 16px;margin:18px 0;">
            <div class="ln-card">
              <h3 style="font-size:16px;margin-bottom:4px;">${escapeHtml(sec.title)}</h3>
              <p style="font-size:13px;color:var(--text-muted);">${escapeHtml(sec.customContent || sec.subtitle)}</p>
            </div>
          </section>`;
      }
      return '';
    })
    .join('');

  host.innerHTML = html + `
    <footer style="margin:28px 16px 10px;padding:20px 0;border-top:1px solid var(--border);font-size:12px;color:var(--text-muted);display:flex;flex-wrap:wrap;justify-content:space-between;gap:12px;">
      <div style="max-width:48ch;">
        <strong style="color:var(--text);">${escapeHtml(cfg.brand)}</strong> · ${escapeHtml(cfg.pages?.footer || '')}
      </div>
      <div style="display:flex;gap:14px;flex-wrap:wrap;">
        <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-nav-target="support">Support</button>
        <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-nav-target="intl">Region &amp; Currency</button>
      </div>
    </footer>
  `;

  bindProductCardHandlers(host);
  const heroSlot = $('uHeroBannerSlot');
  if (heroSlot && activeHeroSlides.length) {
    state.heroController = mountHeroSlider(heroSlot, {
      slides: activeHeroSlides,
      heroSlider: cfg.heroSlider,
      viewportWidth: typeof window !== 'undefined' ? window.innerWidth : 1280,
      initialIdx: state.bannerIdx,
      stageId: 'uHeroStage',
      onSlideChange: (idx) => {
        state.bannerIdx = idx;
      },
      onSlideLink: (rawLink) => {
        const link = String(rawLink || 'category:all').trim();
        if (link.startsWith('category:')) {
          const cat = link.slice(9);
          if (!cat || cat.toLowerCase() === 'all') navigateTo('categories');
          else {
            state.filters.category = cat;
            populateFilterOptions();
            renderHomeSections();
          }
        } else if (link.startsWith('page:')) {
          navigateTo(link.slice(5));
        } else if (link.startsWith('product:')) {
          openProductDetails(link.slice(8));
        } else if (/^https?:\/\//i.test(link) || link.startsWith('/')) {
          const safe = sanitizeUrl(link);
          if (safe) window.location.assign(safe);
        } else {
          navigateTo('categories');
        }
      },
    });
  }
  host.querySelectorAll('[data-pick-cat]').forEach((btn) => {
    btn.onclick = () => {
      state.filters.category = btn.dataset.pickCat;
      populateFilterOptions();
      renderHomeSections();
    };
  });
  host.querySelectorAll('[data-pick-brand]').forEach((btn) => {
    btn.onclick = () => {
      state.filters.brand = btn.dataset.pickBrand;
      populateFilterOptions();
      renderHomeSections();
    };
  });
  host.querySelectorAll('[data-nav-target]').forEach((btn) => {
    btn.onclick = () => navigateTo(btn.dataset.navTarget);
  });
}

function bindProductCardHandlers(container) {
  container.querySelectorAll('[data-open-prod]').forEach((el) => {
    el.onclick = () => openProductDetails(el.dataset.openProd);
  });
  container.querySelectorAll('[data-quick-cart]').forEach((btn) => {
    btn.onclick = () => {
      try {
        const prod = appServices.products.getById(btn.dataset.quickCart);
        addToCart(prod, { qty: 1 });
        updateBadges();
        showToast(`${prod.name} added to cart`, 'success');
      } catch (err) {
        showToast(err.message, 'error');
      }
    };
  });
  container.querySelectorAll('[data-quick-buy]').forEach((btn) => {
    btn.onclick = () => startBuyNow(btn.dataset.quickBuy);
  });
}

function openOverlay(title, pageKey) {
  state.currentPage = pageKey;
  $('uPageTitle').textContent = title;
  $('uPageBody').classList.toggle('u-page-body-split', pageKey === 'categories');
  $('uOverlay').classList.toggle('u-overlay-has-pdp-bar', pageKey === 'pdp');
  const stickyBar = $('uPdpStickyBar');
  if (stickyBar && pageKey !== 'pdp') {
    stickyBar.innerHTML = '';
    stickyBar.classList.remove('show');
  }
  $('uOverlay').classList.add('show');
  $('uOverlay').scrollTop = 0;
  renderBrandAndNav();
}

function closeOverlay() {
  closeVariantPopup();
  closeProductShareModal();
  state.currentPage = null;
  if (state.orderTimer) clearInterval(state.orderTimer);
  $('uPageBody').classList.remove('u-page-body-split');
  $('uOverlay').classList.remove('u-overlay-has-pdp-bar');
  const stickyBar = $('uPdpStickyBar');
  if (stickyBar) {
    stickyBar.innerHTML = '';
    stickyBar.classList.remove('show');
  }
  $('uOverlay').classList.remove('show');
  renderBrandAndNav();
}

function navigateTo(pageKey) {
  if (pageKey === 'home') {
    closeOverlay();
    window.scrollTo({ top: 0, behavior: 'smooth' });
    return;
  }
  if (pageKey === 'categories') return openCategoriesPage();
  if (pageKey === 'cart') return openCartPage();
  if (pageKey === 'orders') return openOrdersPage();
  if (pageKey === 'affiliate') return openAffiliatePage();
  if (pageKey === 'account') return openAccountPage();
  if (pageKey === 'wishlist') return openWishlistPage();
  if (pageKey === 'compare') return openComparePage();
  if (pageKey === 'support') return openSupportPage();
  if (pageKey === 'intl' || pageKey === 'addresses' || pageKey === 'payments') return openAccountSettingsPage(pageKey);
}

function openCategoriesPage(initialCategory = 'All') {
  openOverlay('Categories & Collections', 'categories');
  const cats = listCategories();
  let activeCat = initialCategory || 'All';

  const sidebarItems = [
    { name: 'All', label: 'All', icon: '✦', image: OFFICIAL_LOGO_URL },
    ...cats.map((c) => ({ name: c.name, label: c.name, icon: c.icon || '🛍️', image: c.image })),
  ];

  $('uPageBody').innerHTML = `
    <div class="u-cat-split">
      <aside class="u-cat-sidebar" id="uCatSidebar" aria-label="Product Categories">
        ${sidebarItems
          .map((item) => {
            const thumb = sanitizeUrl(item.image, true);
            const active = activeCat === item.name;
            return `
            <button type="button" class="u-cat-side-btn ${active ? 'active' : ''}" data-cat-tab="${escapeAttr(item.name)}" aria-pressed="${active ? 'true' : 'false'}">
              ${thumb ? `<img class="u-cat-side-thumb" src="${escapeAttr(thumb)}" alt="" referrerpolicy="no-referrer" />` : `<span class="u-cat-side-thumb" aria-hidden="true">${escapeHtml(item.icon)}</span>`}
              <span>${escapeHtml(item.label)}</span>
            </button>`;
          })
          .join('')}
      </aside>
      <section class="u-cat-products-pane" id="uCatProductsPane" aria-label="Category Products"></section>
    </div>
  `;

  const renderRightProducts = () => {
    const prods = listPublishedProducts({ category: activeCat });
    const pane = $('uCatProductsPane');
    if (!pane) return;
    pane.innerHTML = `
      <div class="u-cat-pane-head">
        <h3>${escapeHtml(activeCat === 'All' ? 'All Collections' : activeCat)}</h3>
        <span class="ln-status ln-status-info tabular">${prods.length} ${prods.length === 1 ? 'Item' : 'Items'}</span>
      </div>
      ${renderProductCards(prods, { gridClass: 'u-cat-prod-grid' })}
    `;
    pane.scrollTop = 0;
    bindProductCardHandlers(pane);
  };

  $('uCatSidebar').querySelectorAll('[data-cat-tab]').forEach((b) => {
    b.onclick = () => {
      activeCat = b.dataset.catTab;
      $('uCatSidebar').querySelectorAll('[data-cat-tab]').forEach((btn) => {
        const isActive = btn === b;
        btn.classList.toggle('active', isActive);
        btn.setAttribute('aria-pressed', isActive ? 'true' : 'false');
      });
      renderRightProducts();
    };
  });

  renderRightProducts();
}

function closeProductShareModal() {
  const modal = document.getElementById('uPdpShareModal');
  if (modal) modal.classList.remove('open');
}

function openProductShareModal(product, imageUrl, price, approvedAffiliate = null) {
  if (!product) return;
  let backdrop = document.getElementById('uPdpShareModal');
  if (!backdrop) {
    backdrop = document.createElement('div');
    backdrop.id = 'uPdpShareModal';
    backdrop.className = 'ln-modal-backdrop';
    document.body.appendChild(backdrop);
  }

  let activeUrl = buildProductShareUrl({
    origin: window.location.origin,
    productId: product.id,
  });
  let targets = buildProductShareTargets({
    url: activeUrl,
    title: product.name,
    priceText: money(price),
  });
  const thumb = sanitizeUrl(imageUrl || product.image || '', true);

  const renderModal = () => {
    targets = buildProductShareTargets({
      url: activeUrl,
      title: product.name,
      priceText: money(price),
    });
    const canNativeShare = typeof navigator !== 'undefined' && typeof navigator.share === 'function';
    backdrop.innerHTML = `
      <div class="ln-modal" role="dialog" aria-modal="true" aria-labelledby="uShareModalTitle" style="max-width:440px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;padding-bottom:10px;border-bottom:1px solid var(--border);">
          <div>
            <div style="font-size:10px;font-weight:700;letter-spacing:0.12em;color:var(--gold);text-transform:uppercase;">LUXE NEXUS SHARE</div>
            <h3 id="uShareModalTitle" style="font-family:var(--font-serif);font-size:19px;">Share Product</h3>
          </div>
          <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="btnCloseShareModal" aria-label="Close share dialog">✕</button>
        </div>

        <div style="display:flex;gap:12px;align-items:center;padding:10px;border:1px solid var(--border);border-radius:12px;background:var(--surface-2);margin-bottom:14px;">
          ${
            thumb
              ? `<img src="${escapeAttr(thumb)}" alt="${escapeAttr(product.name)}" referrerpolicy="no-referrer" style="width:56px;height:56px;border-radius:10px;object-fit:cover;flex-shrink:0;" />`
              : `<div class="ln-img-fallback" style="width:56px;height:56px;border-radius:10px;flex-shrink:0;">LN</div>`
          }
          <div style="min-width:0;flex:1;">
            <div style="font-weight:700;font-size:13.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(product.name)}</div>
            <div class="tabular" style="font-size:13px;font-weight:700;color:var(--gold);margin-top:2px;">${money(price)}</div>
          </div>
        </div>

        <div class="ln-field" style="margin-bottom:12px;">
          <label for="uShareProductUrl">Shareable Product Link</label>
          <div style="display:flex;gap:8px;align-items:stretch;">
            <input id="uShareProductUrl" class="ln-input" readonly value="${escapeAttr(targets.url)}" style="font-size:12px;font-family:var(--font-mono);" />
            <button type="button" class="ln-btn ln-btn-gold ln-btn-sm" id="btnCopyShareUrl" style="flex-shrink:0;">Copy Link</button>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-bottom:14px;">
          <a class="ln-btn ln-btn-outline ln-btn-sm" target="_blank" rel="noopener noreferrer" href="${escapeAttr(targets.whatsapp)}">WhatsApp</a>
          <a class="ln-btn ln-btn-outline ln-btn-sm" target="_blank" rel="noopener noreferrer" href="${escapeAttr(targets.facebook)}">Facebook</a>
          <a class="ln-btn ln-btn-outline ln-btn-sm" target="_blank" rel="noopener noreferrer" href="${escapeAttr(targets.twitter)}">X / Twitter</a>
          <a class="ln-btn ln-btn-outline ln-btn-sm" target="_blank" rel="noopener noreferrer" href="${escapeAttr(targets.telegram)}">Telegram</a>
        </div>

        ${
          canNativeShare
            ? `<button type="button" class="ln-btn" id="btnNativeShare" style="width:100%;margin-bottom:12px;">↗ Share via Device</button>`
            : ''
        }

        ${
          approvedAffiliate
            ? `<button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="btnShareAffUrl" style="width:100%;margin-bottom:12px;">◈ Switch to My 7-Day Affiliate Link</button>`
            : ''
        }

        <div style="display:flex;align-items:center;gap:14px;padding-top:12px;border-top:1px solid var(--border);">
          <div style="flex-shrink:0;">${renderQrSvg(targets.url, 96)}</div>
          <div style="font-size:12px;color:var(--text-muted);line-height:1.5;">
            <strong style="color:var(--text);display:block;margin-bottom:2px;">Scan QR Code</strong>
            Share directly in person or let friends scan to open this item immediately.
          </div>
        </div>
      </div>
    `;

    backdrop.querySelector('#btnCloseShareModal').onclick = closeProductShareModal;
    backdrop.querySelector('#uShareProductUrl').onclick = (ev) => ev.target.select();
    backdrop.querySelector('#btnCopyShareUrl').onclick = async (ev) => {
      const btn = ev.currentTarget;
      await navigator.clipboard?.writeText(targets.url).catch(() => {});
      btn.textContent = '✓ Copied';
      showToast('Product link copied to clipboard', 'success');
      setTimeout(() => {
        if (btn.isConnected) btn.textContent = 'Copy Link';
      }, 1800);
    };

    const nativeBtn = backdrop.querySelector('#btnNativeShare');
    if (nativeBtn) {
      nativeBtn.onclick = async () => {
        try {
          await navigator.share({ title: targets.title, text: targets.text, url: targets.url });
        } catch (err) {
          if (err && err.name !== 'AbortError') {
            await navigator.clipboard?.writeText(targets.url).catch(() => {});
            showToast('Product link copied to clipboard', 'success');
          }
        }
      };
    }

    const affShareBtn = backdrop.querySelector('#btnShareAffUrl');
    if (affShareBtn && approvedAffiliate) {
      affShareBtn.onclick = async () => {
        try {
          const link = createAffiliateLink({
            affiliateId: approvedAffiliate.id,
            type: 'product',
            targetId: product.id,
            targetName: product.name,
            label: `${product.name} Share`,
          });
          activeUrl = `${window.location.origin}/${link.urlQuery}`;
          await navigator.clipboard?.writeText(activeUrl).catch(() => {});
          showToast(`Affiliate link generated & copied (${link.code})`, 'success');
          renderModal();
        } catch (err) {
          showToast(err.message, 'error');
        }
      };
    }
  };

  renderModal();
  backdrop.classList.add('open');

  const onKey = (ev) => {
    if (ev.key === 'Escape') {
      document.removeEventListener('keydown', onKey);
      closeProductShareModal();
    }
  };
  document.addEventListener('keydown', onKey);
  backdrop.onclick = (ev) => {
    if (ev.target === backdrop) closeProductShareModal();
  };
}

function openProductDetails(productId) {
  const p = appServices.products.getById(productId);
  if (!p) return;
  const defaults = resolveDefaultVariantSelection(p);
  state.activeProductId = p.id;
  state.activeImageIdx = 0;
  state.activePdpTab = 'description';
  state.selectedSize = defaults.size;
  state.selectedColor = defaults.color;
  state.variantQty = Math.max(1, defaults.qty || 1);

  openOverlay(p.name, 'pdp');
  renderProductDetailsBody();
}

function renderProductDetailsBody() {
  const p = appServices.products.getById(state.activeProductId);
  if (!p) return;
  const imgs = (p.images && p.images.length ? p.images : [p.image]).map((u) => sanitizeUrl(u, true)).filter(Boolean);
  const activeImg = imgs[state.activeImageIdx] || imgs[0] || '';
  const price = Number(p.offerPrice || p.price);
  const old = Number(p.price);
  const inStock = Number(p.stock || 0) > 0;
  const reviewsFlag = getFeatureStatus('productReviews');
  const qaFlag = getFeatureStatus('productQuestions');
  const compareFlag = getFeatureStatus('productComparison');
  const wishFlag = getFeatureStatus('wishlist');
  const cartFlag = getFeatureStatus('cart');
  const buyFlag = getFeatureStatus('buyNow');

  const user = getActiveUser('user');
  const aff = user ? getAffiliateByUserId(user.uid) : null;
  const isApprovedAff = aff && aff.status === 'approved';
  const isSaved = state.wishlist.includes(p.id);
  const isCompared = state.compareIds.includes(p.id);

  let tabContent = '';
  if (state.activePdpTab === 'description') {
    const highlights = String(p.highlights || '').split('\n').filter(Boolean);
    tabContent = `
      <p style="line-height:1.7;">${escapeHtml(p.desc || 'No description provided.')}</p>
      ${highlights.length ? `<ul style="margin:12px 0 0 18px;color:var(--text-muted);">${highlights.map((h) => `<li>${escapeHtml(h)}</li>`).join('')}</ul>` : ''}
      ${p.included ? `<div style="margin-top:14px;"><strong>In the Box:</strong><p style="color:var(--text-muted);white-space:pre-line;">${escapeHtml(p.included)}</p></div>` : ''}
      ${p.video ? `<div style="margin-top:12px;"><a href="${escapeAttr(sanitizeUrl(p.video))}" target="_blank" rel="noopener noreferrer" class="ln-btn ln-btn-outline ln-btn-sm">▶ Watch Product Video</a></div>` : ''}
    `;
  } else if (state.activePdpTab === 'specs') {
    const specRows = String(p.specs || '').split('\n').map((line) => line.split(':')).filter((pair) => pair.length >= 2);
    tabContent = `
      <table class="ln-table">
        <tr><td>Brand</td><td><strong>${escapeHtml(p.brand || 'LUXE NEXUS')}</strong></td></tr>
        <tr><td>Category</td><td>${escapeHtml(p.cat)} ${p.subcat ? `· ${escapeHtml(p.subcat)}` : ''}</td></tr>
        <tr><td>Material</td><td>${escapeHtml(p.material || '—')}</td></tr>
        <tr><td>Warranty</td><td>${escapeHtml(p.warranty || 'Standard')}</td></tr>
        <tr><td>Delivery</td><td>${escapeHtml(p.delivery || '2–4 business days')}</td></tr>
        <tr><td>Returns</td><td>${escapeHtml(p.return || '7-day policy')}</td></tr>
        ${specRows.map(([k, ...v]) => `<tr><td>${escapeHtml(k.trim())}</td><td>${escapeHtml(v.join(':').trim())}</td></tr>`).join('')}
      </table>
    `;
  } else if (state.activePdpTab === 'reviews') {
    const reviews = listProductReviews(p.id);
    tabContent = reviewsFlag.enabled
      ? `
      <div style="margin-bottom:14px;">
        ${reviews.length ? reviews.map((r) => `<div style="padding:10px 0;border-bottom:1px solid var(--border);"><strong>${escapeHtml(r.name)}</strong> · <span style="color:var(--gold);">${'★'.repeat(r.rating)}</span><p style="font-size:13px;margin-top:4px;">${escapeHtml(r.text)}</p></div>`).join('') : '<p style="color:var(--text-muted);">No reviews yet. Be the first to review.</p>'}
      </div>
      <div class="ln-field"><label>Rating</label><select id="pdpRevRate" class="ln-select"><option value="5">5 Stars — Excellent</option><option value="4">4 Stars — Good</option><option value="3">3 Stars — Average</option><option value="2">2 Stars — Fair</option><option value="1">1 Star — Poor</option></select></div>
      <div class="ln-field"><label>Your Review</label><textarea id="pdpRevText" class="ln-textarea" placeholder="Share your experience..."></textarea></div>
      <button type="button" class="ln-btn" id="btnSubmitReview">Submit Review</button>
    `
      : `<p style="color:var(--text-muted);">${escapeHtml(reviewsFlag.maintenanceMessage)}</p>`;
  } else if (state.activePdpTab === 'qa') {
    const questions = listProductQuestions(p.id);
    tabContent = qaFlag.enabled
      ? `
      <div style="margin-bottom:14px;">
        ${questions.length ? questions.map((q) => `<div style="padding:10px 0;border-bottom:1px solid var(--border);"><strong>Q: ${escapeHtml(q.question)}</strong><div style="font-size:11px;color:var(--text-muted);">Asked by ${escapeHtml(q.name)}</div>${q.answer ? `<div style="margin-top:4px;color:var(--gold);">A: ${escapeHtml(q.answer)}</div>` : ''}</div>`).join('') : '<p style="color:var(--text-muted);">No questions asked yet.</p>'}
      </div>
      <div class="ln-field"><label>Ask Seller a Question</label><input id="pdpQaInput" class="ln-input" placeholder="Ask about sizing, fabric, or warranty..." /></div>
      <button type="button" class="ln-btn" id="btnSubmitQa">Post Question</button>
    `
      : `<p style="color:var(--text-muted);">${escapeHtml(qaFlag.maintenanceMessage)}</p>`;
  }

  const related = listPublishedProducts({ category: p.cat }).filter((x) => x.id !== p.id).slice(0, 4);

  $('uPageBody').innerHTML = `
    <div class="u-pdp-layout">
      <div>
        <div class="ln-card" style="padding:10px;position:relative;">
          ${activeImg ? `<img id="pdpMainImg" src="${escapeAttr(activeImg)}" alt="${escapeAttr(p.name)}" referrerpolicy="no-referrer" style="width:100%;aspect-ratio:4/3;object-fit:cover;border-radius:10px;cursor:zoom-in;" />` : `<div class="ln-img-fallback" style="height:260px;">${escapeHtml(p.name)}</div>`}
          ${
            imgs.length > 1
              ? `<div style="display:flex;justify-content:space-between;align-items:center;margin-top:10px;">
                  <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="btnPrevImg">‹ Prev</button>
                  <span style="font-size:12px;color:var(--text-muted);">${state.activeImageIdx + 1} / ${imgs.length}</span>
                  <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="btnNextImg">Next ›</button>
                </div>`
              : ''
          }
        </div>
      </div>

      <div class="ln-card u-pdp-info-card">
        <div style="font-size:12px;color:var(--text-muted);">${escapeHtml(p.brand || 'LUXE NEXUS')} · Sold by ${escapeHtml(p.sellerName || 'Verified Seller')}</div>
        <h1 style="font-size:21px;font-weight:800;margin:6px 0;">${escapeHtml(p.name)}</h1>
        <div style="display:flex;align-items:baseline;gap:10px;margin:8px 0;">
          <span class="tabular" style="font-size:24px;font-weight:800;color:var(--gold);">${money(price)}</span>
          ${old > price ? `<span class="tabular" style="font-size:14px;color:var(--text-muted);text-decoration:line-through;">${money(old)}</span>` : ''}
          ${p.discountPercent ? `<span style="font-size:12px;font-weight:700;color:var(--success);">${p.discountPercent}% OFF</span>` : ''}
        </div>
        <div style="font-size:12px;margin-bottom:14px;">
          <span class="ln-status ${inStock ? 'ln-status-success' : 'ln-status-error'}">${inStock ? `In Stock (${p.stock} available)` : 'Out of Stock'}</span>
          <span> · ★ ${escapeHtml(p.rating || '4.8')}</span>
        </div>

        <div class="u-pdp-meta-actions">
          ${wishFlag.enabled ? `<button type="button" class="ln-btn ln-btn-outline ln-btn-sm u-pdp-mini-btn" id="btnPdpWishlist">${isSaved ? '♥ Saved in Wishlist' : '♡ Save to Wishlist'}</button>` : ''}
          ${compareFlag.enabled ? `<button type="button" class="ln-btn ln-btn-outline ln-btn-sm u-pdp-mini-btn" id="btnPdpCompare">${isCompared ? '✓ In Compare' : '⇄ Compare'}</button>` : ''}
          ${isApprovedAff ? `<button type="button" class="ln-btn ln-btn-outline ln-btn-sm u-pdp-mini-btn" id="btnPdpAffLink">◈ Copy Affiliate Link</button>` : ''}
        </div>
      </div>
    </div>

    <div class="ln-card" style="margin:0 16px 18px;">
      <div class="u-pdp-tabs" role="tablist" aria-label="Product details tabs">
        <button type="button" role="tab" aria-selected="${state.activePdpTab === 'description' ? 'true' : 'false'}" class="ln-btn ln-btn-sm u-pdp-tab-btn ${state.activePdpTab === 'description' ? '' : 'ln-btn-outline'}" data-pdp-tab="description">Description</button>
        <button type="button" role="tab" aria-selected="${state.activePdpTab === 'specs' ? 'true' : 'false'}" class="ln-btn ln-btn-sm u-pdp-tab-btn ${state.activePdpTab === 'specs' ? '' : 'ln-btn-outline'}" data-pdp-tab="specs">Specifications</button>
        <button type="button" role="tab" aria-selected="${state.activePdpTab === 'reviews' ? 'true' : 'false'}" class="ln-btn ln-btn-sm u-pdp-tab-btn ${state.activePdpTab === 'reviews' ? '' : 'ln-btn-outline'}" data-pdp-tab="reviews">Reviews</button>
        <button type="button" role="tab" aria-selected="${state.activePdpTab === 'qa' ? 'true' : 'false'}" class="ln-btn ln-btn-sm u-pdp-tab-btn ${state.activePdpTab === 'qa' ? '' : 'ln-btn-outline'}" data-pdp-tab="qa">Questions</button>
      </div>
      <div>${tabContent}</div>
    </div>

    ${related.length ? `<div style="margin:0 16px 8px;"><h3 style="font-size:16px;margin-bottom:10px;">Related Products</h3></div>${renderProductCards(related)}` : ''}
  `;

  const body = $('uPageBody');
  bindProductCardHandlers(body);
  const mainImg = $('pdpMainImg');
  if (mainImg) {
    mainImg.onclick = () => {
      const zoomed = mainImg.style.transform === 'scale(1.35)';
      mainImg.style.transform = zoomed ? 'scale(1)' : 'scale(1.35)';
      mainImg.style.transition = 'transform 0.2s ease';
    };
  }
  const prev = $('btnPrevImg');
  const next = $('btnNextImg');
  if (prev) prev.onclick = () => { state.activeImageIdx = (state.activeImageIdx - 1 + imgs.length) % imgs.length; renderProductDetailsBody(); };
  if (next) next.onclick = () => { state.activeImageIdx = (state.activeImageIdx + 1) % imgs.length; renderProductDetailsBody(); };

  body.querySelectorAll('[data-pdp-tab]').forEach((b) => {
    b.onclick = () => { state.activePdpTab = b.dataset.pdpTab; renderProductDetailsBody(); };
  });

  const stickyBar = $('uPdpStickyBar');
  const hasAnyStickyBtn = cartFlag.enabled || buyFlag.enabled;
  const stickyCount = (cartFlag.enabled ? 1 : 0) + (buyFlag.enabled ? 1 : 0);
  if (stickyBar) {
    if (state.currentPage === 'pdp') {
      stickyBar.innerHTML = `
        <div class="u-pdp-sticky-bar-inner">
          <div class="u-pdp-sticky-utils" role="group" aria-label="Product quick navigation and sharing">
            <button type="button" class="u-pdp-util-btn" id="btnPdpHome" aria-label="Go to Home Page" title="Home">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <path d="M3 10.5 12 3l9 7.5"></path>
                <path d="M5 9.5V20a1 1 0 0 0 1 1h4v-5.5a2 2 0 0 1 4 0V21h4a1 1 0 0 0 1-1V9.5"></path>
              </svg>
              <span>Home</span>
            </button>
            <button type="button" class="u-pdp-util-btn" id="btnPdpShare" aria-label="Share Product" title="Share">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <circle cx="18" cy="5" r="3"></circle>
                <circle cx="6" cy="12" r="3"></circle>
                <circle cx="18" cy="19" r="3"></circle>
                <path d="M8.59 13.51 15.42 17.49"></path>
                <path d="M15.41 6.51 8.59 10.49"></path>
              </svg>
              <span>Share</span>
            </button>
          </div>
          ${
            hasAnyStickyBtn
              ? `<div class="u-pdp-sticky-actions ${stickyCount === 1 ? 'single' : ''}">
                  ${cartFlag.enabled ? `<button type="button" class="ln-btn ln-btn-outline" id="btnPdpAddCart" ${!inStock ? 'disabled' : ''}><span class="u-pdp-cta-label">${escapeHtml(t('addToCart', lang()))}</span></button>` : ''}
                  ${buyFlag.enabled ? `<button type="button" class="ln-btn ln-btn-gold" id="btnPdpBuyNow" ${!inStock ? 'disabled' : ''}><span class="u-pdp-cta-label">${escapeHtml(t('buyNow', lang()))}</span></button>` : ''}
                </div>`
              : ''
          }
        </div>
      `;
      stickyBar.classList.add('show');
    } else {
      stickyBar.innerHTML = '';
      stickyBar.classList.remove('show');
    }
    $('uOverlay')?.classList.toggle('u-overlay-has-pdp-bar', state.currentPage === 'pdp');
  }

  const homeBtn = $('btnPdpHome');
  if (homeBtn) homeBtn.onclick = () => navigateTo('home');

  const shareBarBtn = $('btnPdpShare');
  if (shareBarBtn) shareBarBtn.onclick = () => openProductShareModal(p, activeImg, price, isApprovedAff ? aff : null);

  const addBtn = $('btnPdpAddCart');
  if (addBtn) {
    addBtn.onclick = () => {
      try {
        const defaults = resolveDefaultVariantSelection(p);
        const chosenColor = state.selectedColor || defaults.color;
        const chosenSize = state.selectedSize || defaults.size;
        addToCart(p, { qty: 1, size: chosenSize, color: chosenColor, image: activeImg });
        updateBadges();
        showToast('Added to shopping cart', 'success');
      } catch (err) {
        showToast(err.message, 'error');
      }
    };
  }
  const buyBtn = $('btnPdpBuyNow');
  if (buyBtn) buyBtn.onclick = () => startBuyNow(p.id);

  const wishBtn = $('btnPdpWishlist');
  if (wishBtn) {
    wishBtn.onclick = () => {
      if (state.wishlist.includes(p.id)) state.wishlist = state.wishlist.filter((x) => x !== p.id);
      else state.wishlist.push(p.id);
      localStorage.setItem('ln_wishlist_ids', JSON.stringify(state.wishlist));
      showToast('Wishlist updated', 'success');
      renderProductDetailsBody();
    };
  }
  const cmpBtn = $('btnPdpCompare');
  if (cmpBtn) {
    cmpBtn.onclick = () => {
      if (state.compareIds.includes(p.id)) state.compareIds = state.compareIds.filter((x) => x !== p.id);
      else state.compareIds = [...state.compareIds.slice(-3), p.id];
      localStorage.setItem('ln_compare_ids', JSON.stringify(state.compareIds));
      showToast('Comparison list updated', 'success');
      renderProductDetailsBody();
    };
  }
  const affBtn = $('btnPdpAffLink');
  if (affBtn && isApprovedAff) {
    affBtn.onclick = async () => {
      try {
        const link = createAffiliateLink({
          affiliateId: aff.id,
          type: 'product',
          targetId: p.id,
          targetName: p.name,
          label: `${p.name} Share`,
        });
        const fullUrl = `${window.location.origin}/${link.urlQuery}`;
        await navigator.clipboard?.writeText(fullUrl).catch(() => {});
        showToast(`7-day Affiliate Link copied (${link.code})`, 'success');
      } catch (err) {
        showToast(err.message, 'error');
      }
    };
  }
  const revBtn = $('btnSubmitReview');
  if (revBtn) {
    revBtn.onclick = () => {
      try {
        submitProductReview(p.id, { rating: $('pdpRevRate').value, text: $('pdpRevText').value }, getActiveUser('user'));
        showToast('Review posted', 'success');
        renderProductDetailsBody();
      } catch (err) {
        showToast(err.message, 'error');
        if (err.message.toLowerCase().includes('sign in')) openAccountPage();
      }
    };
  }
  const qaBtn = $('btnSubmitQa');
  if (qaBtn) {
    qaBtn.onclick = () => {
      try {
        submitProductQuestion(p.id, $('pdpQaInput').value, getActiveUser('user'));
        showToast('Question submitted', 'success');
        renderProductDetailsBody();
      } catch (err) {
        showToast(err.message, 'error');
      }
    };
  }
}

function openCartPage() {
  const cartFlag = getFeatureStatus('cart');
  openOverlay('Shopping Cart', 'cart');
  if (!cartFlag.enabled) {
    $('uPageBody').innerHTML = `<div class="ln-empty"><h4>Cart Unavailable</h4><p>${escapeHtml(cartFlag.maintenanceMessage)}</p></div>`;
    return;
  }
  const draw = () => {
    const cart = getCart();
    if (!cart.length) {
      $('uPageBody').innerHTML = `
        <div class="ln-empty">
          <h4>Your cart is empty</h4>
          <p style="font-size:13px;margin-bottom:14px;">Explore curated collections and add items to begin.</p>
          <button type="button" class="ln-btn" id="btnCartExplore">Browse Collection</button>
        </div>
      `;
      $('btnCartExplore').onclick = closeOverlay;
      return;
    }
    const cfg = getPlatformConfig();
    const totals = calculateOrderTotals({ items: cart, area: state.selectedArea, couponCode: state.couponCode, payment: 'COD' });
    $('uPageBody').innerHTML = `
      <div class="ln-card" style="margin-bottom:14px;">
        ${cart
          .map(
            (item) => `
          <div style="display:flex;gap:12px;align-items:center;padding:10px 0;border-bottom:1px solid var(--border);">
            <img src="${escapeAttr(sanitizeUrl(item.image, true))}" alt="${escapeAttr(item.name)}" referrerpolicy="no-referrer" style="width:64px;height:64px;object-fit:cover;border-radius:8px;background:var(--surface-2);" />
            <div style="flex:1;min-width:0;">
              <div style="font-weight:700;font-size:14px;">${escapeHtml(item.name)}</div>
              <div style="font-size:12px;color:var(--text-muted);">${[item.size, item.color].filter(Boolean).join(' · ') || 'Standard'} · ${money(item.unitPrice)}</div>
              <div style="display:flex;align-items:center;gap:8px;margin-top:8px;">
                <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-qty-dec="${escapeAttr(item.variantKey)}" aria-label="Decrease quantity">−</button>
                <strong class="tabular" style="min-width:22px;text-align:center;">${item.qty}</strong>
                <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-qty-inc="${escapeAttr(item.variantKey)}" aria-label="Increase quantity">+</button>
                <button type="button" class="ln-btn ln-btn-danger ln-btn-sm" data-qty-rem="${escapeAttr(item.variantKey)}" style="margin-left:auto;">Remove</button>
              </div>
            </div>
          </div>`
          )
          .join('')}
      </div>

      <div class="ln-card" style="margin-bottom:14px;">
        <div class="ln-field" style="display:flex;gap:8px;align-items:flex-end;margin-bottom:0;">
          <div style="flex:1;"><label for="cartCouponInput">Coupon Code (Try LUXE100)</label><input id="cartCouponInput" class="ln-input" value="${escapeAttr(state.couponCode)}" placeholder="Enter coupon code" /></div>
          <button type="button" class="ln-btn ln-btn-outline" id="btnApplyCoupon">Apply</button>
        </div>
        ${totals.couponMessage ? `<div style="font-size:12px;margin-top:6px;color:var(--gold);">${escapeHtml(totals.couponMessage)}</div>` : ''}
      </div>

      <div class="ln-card" style="margin-bottom:14px;">
        <div style="font-size:12px;font-weight:700;color:var(--gold);letter-spacing:0.06em;text-transform:uppercase;margin-bottom:8px;">Delivery Region</div>
        <div class="ln-seg-grid">
          <button type="button" class="ln-seg-card ${state.selectedArea === 'dhaka' ? 'active' : ''}" data-pick-area="dhaka">
            <div><strong>Inside Dhaka</strong><small>Express city delivery</small></div>
            <strong class="tabular ln-seg-accent">${money(cfg.checkout?.dhakaFee || 60)}</strong>
          </button>
          <button type="button" class="ln-seg-card ${state.selectedArea === 'outside' ? 'active' : ''}" data-pick-area="outside">
            <div><strong>Outside Dhaka</strong><small>Nationwide courier</small></div>
            <strong class="tabular ln-seg-accent">${money(cfg.checkout?.outFee || 120)}</strong>
          </button>
        </div>
      </div>

      <div class="ln-card">
        <div style="display:flex;justify-content:space-between;padding:5px 0;"><span>Subtotal</span><strong class="tabular">${money(totals.subtotal)}</strong></div>
        ${totals.discount > 0 ? `<div style="display:flex;justify-content:space-between;padding:5px 0;color:var(--success);"><span>Discount</span><strong class="tabular">−${money(totals.discount)}</strong></div>` : ''}
        <div style="display:flex;justify-content:space-between;padding:5px 0;">
          <span>Delivery (${state.selectedArea === 'dhaka' ? 'Inside Dhaka' : 'Outside Dhaka'})</span>
          <strong class="tabular">${money(totals.deliveryCharge)}</strong>
        </div>
        <div style="display:flex;justify-content:space-between;padding:10px 0 0;border-top:1px solid var(--border);margin-top:8px;font-size:16px;">
          <strong>Grand Total</strong><strong class="tabular" style="color:var(--gold);">${money(totals.grandTotal)}</strong>
        </div>
        <button type="button" class="ln-btn ln-btn-gold" id="btnCartCheckout" style="width:100%;margin-top:14px;">Proceed to Checkout</button>
      </div>
    `;

    $('uPageBody').querySelectorAll('[data-qty-dec]').forEach((b) => {
      b.onclick = () => { updateCartItemQty(b.dataset.qtyDec, -1); updateBadges(); draw(); };
    });
    $('uPageBody').querySelectorAll('[data-qty-inc]').forEach((b) => {
      b.onclick = () => { updateCartItemQty(b.dataset.qtyInc, 1); updateBadges(); draw(); };
    });
    $('uPageBody').querySelectorAll('[data-qty-rem]').forEach((b) => {
      b.onclick = () => { removeFromCart(b.dataset.qtyRem); updateBadges(); draw(); };
    });
    $('btnApplyCoupon').onclick = () => {
      state.couponCode = $('cartCouponInput').value.trim();
      draw();
    };
    $('uPageBody').querySelectorAll('[data-pick-area]').forEach((b) => {
      b.onclick = () => {
        state.selectedArea = b.dataset.pickArea;
        localStorage.setItem('ln_user_area', state.selectedArea);
        draw();
      };
    });
    $('btnCartCheckout').onclick = () => {
      const user = getActiveUser('user');
      if (cfg.checkout?.loginRequired && !user) {
        showToast('Please sign in to proceed with checkout.', 'error');
        openAccountPage();
        return;
      }
      state.checkoutMode = 'cart';
      state.idempotencyKey = `IDEM-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      openCheckoutPage();
    };
  };
  draw();
}

function closeVariantPopup() {
  const modal = $('uVariantModal');
  state.variantPopupProductId = null;
  if (!modal) return;
  modal.classList.remove('show');
  modal.innerHTML = '';
}

function openVariantPopup(productId) {
  const p = appServices.products.getById(productId);
  if (!p) {
    showToast('Product not found.', 'error');
    return;
  }
  const modal = $('uVariantModal');
  if (!modal) return;

  const defaults = resolveDefaultVariantSelection(p);
  const colorOptsInitial = buildProductColorOptions(p);
  if (!colorOptsInitial.some((c) => c.name === state.selectedColor && c.available)) {
    state.selectedColor = defaults.color;
  }
  const sizeOptsInitial = buildProductSizeOptions(p, state.selectedColor);
  if (!sizeOptsInitial.some((s) => s.name === state.selectedSize && s.available)) {
    state.selectedSize = sizeOptsInitial.find((s) => s.available)?.name || defaults.size;
  }
  const initialStock = resolveVariantStock(p, { color: state.selectedColor, size: state.selectedSize });
  state.variantQty = initialStock > 0 ? clampVariantQty(1, initialStock) : 0;
  state.variantPopupProductId = p.id;

  let buyInFlight = false;
  let errorMsg = '';

  const renderPopup = () => {
    const prod = appServices.products.getById(productId);
    if (!prod) return closeVariantPopup();

    const colorOpts = buildProductColorOptions(prod);
    const sizeOpts = buildProductSizeOptions(prod, state.selectedColor);
    const activeColorObj = colorOpts.find((c) => c.name === state.selectedColor) || colorOpts[0] || null;
    const availableStock = resolveVariantStock(prod, { color: state.selectedColor, size: state.selectedSize });
    const displayQty = availableStock > 0 ? clampVariantQty(state.variantQty, availableStock) : 0;
    state.variantQty = displayQty;

    const unitPrice = roundMoney(prod.offerPrice || prod.price);
    const oldPrice = roundMoney(prod.price);
    const discountPct =
      oldPrice > unitPrice ? Number(prod.discountPercent || Math.round(((oldPrice - unitPrice) / oldPrice) * 100)) : 0;
    const totalPrice = roundMoney(unitPrice * Math.max(1, displayQty));
    const headerImg =
      activeColorObj?.image ||
      sanitizeUrl(prod.image || (prod.images && prod.images[0]) || '', true);
    const selectedLabel = [state.selectedColor, state.selectedSize].filter(Boolean).join(' · ');

    modal.innerHTML = `
      <div class="u-var-dialog">
        <div class="u-var-head">
          ${headerImg ? `<img id="varProdImg" class="u-var-thumb" src="${escapeAttr(headerImg)}" alt="${escapeAttr(prod.name)}" referrerpolicy="no-referrer" />` : `<div class="u-var-thumb ln-img-fallback">${escapeHtml(prod.name)}</div>`}
          <div class="u-var-head-info">
            <div id="varProdTitle" class="u-var-title">${escapeHtml(prod.name)}</div>
            <div class="u-var-price-row">
              <span id="varUnitPrice" class="u-var-price">${money(unitPrice)}</span>
              ${oldPrice > unitPrice ? `<span id="varOldPrice" class="u-var-old-price">${money(oldPrice)}</span>` : ''}
              ${discountPct ? `<span id="varDiscountBadge" style="font-size:11.5px;font-weight:700;color:var(--success);">${discountPct}% OFF</span>` : ''}
            </div>
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;font-size:12px;">
              <span id="varStockBadge" class="ln-status ${availableStock > 0 ? 'ln-status-success' : 'ln-status-error'}">${availableStock > 0 ? `In Stock (${availableStock} available)` : 'Out of Stock'}</span>
              ${selectedLabel ? `<span id="varSelectedSummary" style="color:var(--text-muted);">${escapeHtml(selectedLabel)}</span>` : ''}
            </div>
          </div>
          <button type="button" class="u-var-close" id="btnVarClose" aria-label="Close variant selection">✕</button>
        </div>

        <div class="u-var-scroll">
          ${
            colorOpts.length
              ? `<div>
                  <div class="u-var-sec-head">
                    <strong>Color Family</strong>
                    <span id="varSelectedColorLbl">${escapeHtml(state.selectedColor || 'Select Color')}</span>
                  </div>
                  <div class="u-var-color-grid">
                    ${colorOpts
                      .map((c) => {
                        const isActive = c.name === state.selectedColor;
                        return `
                          <button type="button" class="u-var-color-card ${isActive ? 'active' : ''}" data-var-color="${escapeAttr(c.name)}" aria-pressed="${isActive ? 'true' : 'false'}" ${!c.available ? 'disabled' : ''}>
                            ${c.image ? `<img class="u-var-color-img" src="${escapeAttr(c.image)}" alt="" referrerpolicy="no-referrer" />` : ''}
                            <span class="u-var-color-name">${escapeHtml(c.name)}${!c.available ? ' (Out)' : ''}</span>
                          </button>
                        `;
                      })
                      .join('')}
                  </div>
                </div>`
              : ''
          }

          ${
            sizeOpts.length
              ? `<div>
                  <div class="u-var-sec-head">
                    <strong>Size</strong>
                    <span id="varSelectedSizeLbl">${escapeHtml(state.selectedSize || 'Select Size')}</span>
                  </div>
                  <div class="u-var-size-row">
                    ${sizeOpts
                      .map((s) => {
                        const isActive = s.name === state.selectedSize;
                        return `<button type="button" class="u-var-size-btn ${isActive ? 'active' : ''}" data-var-size="${escapeAttr(s.name)}" aria-pressed="${isActive ? 'true' : 'false'}" ${!s.available ? 'disabled' : ''}>${escapeHtml(s.name)}</button>`;
                      })
                      .join('')}
                  </div>
                </div>`
              : ''
          }

          <div>
            <div class="u-var-qty-box">
              <div>
                <div style="font-size:13px;font-weight:700;">Quantity</div>
                <div style="font-size:11.5px;color:var(--text-muted);">${availableStock > 0 ? `Max ${availableStock} available` : 'Currently unavailable'}</div>
              </div>
              <div class="u-var-stepper">
                <button type="button" class="u-var-step-btn" id="btnVarQtyDec" aria-label="Decrease quantity" ${displayQty <= 1 || availableStock <= 0 ? 'disabled' : ''}>−</button>
                <span id="varQtyVal" class="u-var-qty-val">${displayQty}</span>
                <button type="button" class="u-var-step-btn" id="btnVarQtyInc" aria-label="Increase quantity" ${displayQty >= availableStock || availableStock <= 0 ? 'disabled' : ''}>+</button>
              </div>
            </div>
          </div>

          <div class="u-var-total-row">
            <span style="font-size:12.5px;color:var(--text-muted);">Total (${Math.max(1, displayQty)} × ${money(unitPrice)})</span>
            <strong id="varTotalPrice" class="tabular" style="font-size:17px;color:var(--gold);">${money(totalPrice)}</strong>
          </div>

          ${errorMsg ? `<div id="uVarError" class="u-var-error" role="alert">${escapeHtml(errorMsg)}</div>` : ''}
        </div>

        <div class="u-var-foot">
          <button type="button" class="ln-btn ln-btn-gold u-var-buy-btn" id="btnVariantConfirmBuy" ${availableStock <= 0 || buyInFlight ? 'disabled' : ''}>
            ${availableStock > 0 ? `${escapeHtml(t('buyNow', lang()))} — ${money(totalPrice)}` : 'Out of Stock'}
          </button>
        </div>
      </div>
    `;

    $('btnVarClose').onclick = closeVariantPopup;
    modal.onclick = (e) => {
      if (e.target === modal) closeVariantPopup();
    };

    modal.querySelectorAll('[data-var-color]').forEach((btn) => {
      btn.onclick = () => {
        errorMsg = '';
        state.selectedColor = btn.dataset.varColor;
        const nextSizes = buildProductSizeOptions(prod, state.selectedColor);
        if (nextSizes.length && !nextSizes.some((s) => s.name === state.selectedSize && s.available)) {
          state.selectedSize = nextSizes.find((s) => s.available)?.name || '';
        }
        const nextStock = resolveVariantStock(prod, { color: state.selectedColor, size: state.selectedSize });
        state.variantQty = nextStock > 0 ? clampVariantQty(state.variantQty || 1, nextStock) : 0;
        renderPopup();
      };
    });

    modal.querySelectorAll('[data-var-size]').forEach((btn) => {
      btn.onclick = () => {
        errorMsg = '';
        state.selectedSize = btn.dataset.varSize;
        const nextStock = resolveVariantStock(prod, { color: state.selectedColor, size: state.selectedSize });
        state.variantQty = nextStock > 0 ? clampVariantQty(state.variantQty || 1, nextStock) : 0;
        renderPopup();
      };
    });

    $('btnVarQtyDec').onclick = () => {
      if (state.variantQty <= 1) return;
      errorMsg = '';
      state.variantQty = clampVariantQty(state.variantQty - 1, availableStock);
      renderPopup();
    };

    $('btnVarQtyInc').onclick = () => {
      if (state.variantQty >= availableStock) return;
      errorMsg = '';
      state.variantQty = clampVariantQty(state.variantQty + 1, availableStock);
      renderPopup();
    };

    $('btnVariantConfirmBuy').onclick = () => {
      if (buyInFlight) return;
      const res = validateBuyNowSelection(prod, {
        color: state.selectedColor,
        size: state.selectedSize,
        qty: state.variantQty,
      });
      if (!res.valid) {
        errorMsg = res.error;
        showToast(res.error, 'error');
        renderPopup();
        return;
      }

      const norm = res.normalized;
      state.checkoutMode = 'buy_now';
      state.buyNowItem = {
        productId: norm.productId,
        name: norm.name,
        category: norm.category,
        image: norm.image,
        unitPrice: norm.unitPrice,
        regularPrice: norm.regularPrice,
        qty: norm.qty,
        size: norm.size,
        color: norm.color,
      };
      state.idempotencyKey = `IDEM-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;

      const cfg = getPlatformConfig();
      const user = getActiveUser('user');
      if (cfg.checkout?.loginRequired && !user) {
        state.pendingBuyNowCheckout = true;
        showToast('Please sign in to complete your Buy Now checkout.', 'error');
        closeVariantPopup();
        openAccountPage();
        return;
      }

      buyInFlight = true;
      closeVariantPopup();
      openCheckoutPage();
    };
  };

  modal.classList.add('show');
  renderPopup();
}

function startBuyNow(productId) {
  const buyFlag = getFeatureStatus('buyNow');
  if (!buyFlag.enabled) {
    showToast(buyFlag.maintenanceMessage, 'error');
    return;
  }
  const p = appServices.products.getById(productId);
  if (!p) {
    showToast('Product not found.', 'error');
    return;
  }
  if (p.active === false || p.approved === false || Number(p.stock || 0) <= 0) {
    showToast('This product is currently out of stock.', 'error');
    return;
  }
  openVariantPopup(p.id);
}

function openCheckoutPage() {
  openOverlay('Checkout & Confirmation', 'checkout');
  const user = getActiveUser('user');
  const cfg = getPlatformConfig();
  const items = state.checkoutMode === 'buy_now' && state.buyNowItem ? [state.buyNowItem] : getCart();
  const methods = getAvailablePaymentMethods();
  let selectedPayment = methods.find((m) => m.enabled)?.id || 'COD';

  const draw = () => {
    const totals = calculateOrderTotals({
      items,
      area: state.selectedArea,
      couponCode: state.couponCode,
      payment: selectedPayment,
    });
    const savedAddr = user?.addresses?.[0] || {};
    $('uPageBody').innerHTML = `
      <div class="ln-card" style="margin-bottom:14px;">
        <div style="font-size:12px;font-weight:700;color:var(--gold);letter-spacing:0.06em;text-transform:uppercase;margin-bottom:8px;">Delivery Region</div>
        <div class="ln-seg-grid">
          <button type="button" class="ln-seg-card ${state.selectedArea === 'dhaka' ? 'active' : ''}" data-chk-area="dhaka">
            <div><strong>Inside Dhaka</strong><small>Delivery charge</small></div>
            <strong class="tabular ln-seg-accent">${money(cfg.checkout?.dhakaFee || 60)}</strong>
          </button>
          <button type="button" class="ln-seg-card ${state.selectedArea === 'outside' ? 'active' : ''}" data-chk-area="outside">
            <div><strong>Outside Dhaka</strong><small>Delivery charge</small></div>
            <strong class="tabular ln-seg-accent">${money(cfg.checkout?.outFee || 120)}</strong>
          </button>
        </div>
      </div>

      <div class="ln-card" style="margin-bottom:14px;">
        <h3 style="font-size:16px;margin-bottom:12px;">Shipping Details</h3>
        <div class="ln-field"><label for="chkName">Recipient Full Name *</label><input id="chkName" class="ln-input" value="${escapeAttr(savedAddr.name || user?.name || '')}" /></div>
        <div class="ln-field"><label for="chkPhone">Mobile Number *</label><input id="chkPhone" class="ln-input" value="${escapeAttr(savedAddr.phone || user?.phone || '')}" placeholder="01XXXXXXXXX" /></div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
          <div class="ln-field"><label for="chkDistrict">District *</label><input id="chkDistrict" class="ln-input" value="${escapeAttr(savedAddr.district || 'Dhaka')}" /></div>
          <div class="ln-field"><label for="chkUpazila">Upazila / Area *</label><input id="chkUpazila" class="ln-input" value="${escapeAttr(savedAddr.upazila || '')}" placeholder="e.g. Banani" /></div>
        </div>
        <div class="ln-field"><label for="chkAddress">Full Address *</label><textarea id="chkAddress" class="ln-textarea" placeholder="House, road, block, landmark">${escapeHtml(savedAddr.address || '')}</textarea></div>
      </div>

      <div class="ln-card" style="margin-bottom:14px;">
        <h3 style="font-size:16px;margin-bottom:10px;">Payment Method</h3>
        <div style="display:grid;gap:8px;">
          ${methods
            .map(
              (m) => `
            <label class="ln-seg-card ${selectedPayment === m.id ? 'active' : ''}" style="opacity:${m.enabled ? '1' : '0.45'};cursor:${m.enabled ? 'pointer' : 'not-allowed'};">
              <div style="display:flex;align-items:center;gap:10px;">
                <input type="radio" name="chkPayment" value="${escapeAttr(m.id)}" ${selectedPayment === m.id ? 'checked' : ''} ${m.enabled ? '' : 'disabled'} />
                <span style="font-weight:600;">${escapeHtml(m.name)}</span>
              </div>
              <span style="font-size:11px;color:var(--text-muted);">${m.enabled ? (m.feePercent ? `+${m.feePercent}% fee` : 'No fee') : 'Disabled in Admin'}</span>
            </label>`
            )
            .join('')}
        </div>
      </div>

      <div class="ln-card">
        <h3 style="font-size:16px;margin-bottom:10px;">Order Summary (${items.length} ${items.length === 1 ? 'item' : 'items'})</h3>
        ${items
          .map((i) => {
            const thumbUrl = sanitizeUrl(i.image || appServices.products.getById(i.productId)?.image || '', true);
            const metaParts = [
              i.color ? `Color: ${i.color}` : '',
              i.size ? `Size: ${i.size}` : '',
              `Qty: ${i.qty}`,
            ].filter(Boolean);
            return `
              <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid rgba(201,164,92,0.12);">
                ${thumbUrl ? `<img src="${escapeAttr(thumbUrl)}" alt="${escapeAttr(i.name)}" referrerpolicy="no-referrer" style="width:46px;height:46px;border-radius:8px;object-fit:cover;border:1px solid var(--border);flex-shrink:0;" />` : ''}
                <div style="flex:1;min-width:0;">
                  <div style="font-size:13px;font-weight:700;line-height:1.3;">${escapeHtml(i.name)}</div>
                  <div style="font-size:11.5px;color:var(--text-muted);margin-top:2px;">${escapeHtml(metaParts.join(' · '))} · ${money(i.unitPrice)} each</div>
                </div>
                <strong class="tabular" style="font-size:13.5px;white-space:nowrap;">${money(i.unitPrice * i.qty)}</strong>
              </div>
            `;
          })
          .join('')}
        <div style="display:flex;justify-content:space-between;font-size:13px;padding:4px 0;margin-top:6px;"><span>Subtotal</span><strong class="tabular">${money(totals.subtotal)}</strong></div>
        ${totals.discount > 0 ? `<div style="display:flex;justify-content:space-between;font-size:13px;padding:4px 0;color:var(--success);"><span>Discount</span><strong class="tabular">−${money(totals.discount)}</strong></div>` : ''}
        <div style="display:flex;justify-content:space-between;font-size:13px;padding:4px 0;"><span>Delivery</span><strong class="tabular">${money(totals.deliveryCharge)}</strong></div>
        ${totals.paymentFee > 0 ? `<div style="display:flex;justify-content:space-between;font-size:13px;padding:4px 0;"><span>Payment Fee</span><strong class="tabular">${money(totals.paymentFee)}</strong></div>` : ''}
        <div style="display:flex;justify-content:space-between;font-size:16px;padding:8px 0 0;border-top:1px solid var(--border);margin-top:6px;"><strong>Grand Total</strong><strong class="tabular" style="color:var(--gold);">${money(totals.grandTotal)}</strong></div>
        <button type="button" class="ln-btn ln-btn-gold" id="btnPlaceOrderNow" style="width:100%;margin-top:14px;">${escapeHtml(cfg.checkout?.checkoutBtn || 'Confirm Order')}</button>
      </div>
    `;

    $('uPageBody').querySelectorAll('[data-chk-area]').forEach((b) => {
      b.onclick = () => {
        state.selectedArea = b.dataset.chkArea;
        localStorage.setItem('ln_user_area', state.selectedArea);
        draw();
      };
    });
    $('uPageBody').querySelectorAll('input[name="chkPayment"]').forEach((r) => {
      r.onchange = () => { selectedPayment = r.value; draw(); };
    });
    $('btnPlaceOrderNow').onclick = () => {
      try {
        const order = createValidatedOrder({
          items,
          customer: {
            name: $('chkName').value,
            phone: $('chkPhone').value,
            district: $('chkDistrict').value,
            upazila: $('chkUpazila').value,
            address: $('chkAddress').value,
          },
          area: state.selectedArea,
          payment: selectedPayment,
          couponCode: state.couponCode,
          source: state.checkoutMode,
          user: getActiveUser('user'),
          idempotencyKey: state.idempotencyKey,
        });
        updateBadges();
        $('uPageTitle').textContent = 'Order Confirmed';
        $('uPageBody').innerHTML = `
          <div class="ln-card" style="text-align:center;padding:34px 20px;">
            <div style="font-size:44px;color:var(--success);margin-bottom:8px;">✓</div>
            <h2 style="font-size:22px;margin-bottom:6px;">Order #${escapeHtml(order.id)} Confirmed</h2>
            <p style="color:var(--text-muted);font-size:13px;margin-bottom:14px;">Total: <strong class="tabular">${money(order.total)}</strong> · Status: ${escapeHtml(order.status)}</p>
            <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
              <button type="button" class="ln-btn" id="btnViewConfirmedOrders">Track My Orders</button>
              <button type="button" class="ln-btn ln-btn-outline" id="btnContinueShop">Continue Shopping</button>
            </div>
          </div>
        `;
        $('btnViewConfirmedOrders').onclick = () => openOrdersPage();
        $('btnContinueShop').onclick = () => closeOverlay();
      } catch (err) {
        showToast(err.message, 'error');
      }
    };
  };
  draw();
}

function openAreaModal(onDone) {
  const cfg = getPlatformConfig();
  $('lblAreaDhakaFee').textContent = money(cfg.checkout?.dhakaFee || 60);
  $('lblAreaOutsideFee').textContent = money(cfg.checkout?.outFee || 120);
  $('uAreaModal').classList.add('open');
  $('btnAreaDhaka').onclick = () => {
    state.selectedArea = 'dhaka';
    localStorage.setItem('ln_user_area', 'dhaka');
    $('uAreaModal').classList.remove('open');
    if (onDone) onDone();
  };
  $('btnAreaOutside').onclick = () => {
    state.selectedArea = 'outside';
    localStorage.setItem('ln_user_area', 'outside');
    $('uAreaModal').classList.remove('open');
    if (onDone) onDone();
  };
  $('btnAreaCancel').onclick = () => $('uAreaModal').classList.remove('open');
}

function openOrdersPage() {
  openOverlay('My Orders & Tracking', 'orders');
  if (state.orderTimer) clearInterval(state.orderTimer);
  const user = getActiveUser('user');
  if (!user) {
    $('uPageBody').innerHTML = `<div class="ln-empty"><h4>Sign in to view your orders</h4><p style="font-size:13px;margin-bottom:12px;">Track delivery progress and manage order details.</p><button type="button" class="ln-btn" id="btnOrdersLogin">Sign In</button></div>`;
    $('btnOrdersLogin').onclick = openAccountPage;
    return;
  }

  const draw = () => {
    const orders = listOrdersForUser(user);
    if (!orders.length) {
      $('uPageBody').innerHTML = `<div class="ln-empty"><h4>No orders placed yet</h4><p style="font-size:13px;margin-bottom:12px;">Your order history and live tracking timeline will appear here.</p><button type="button" class="ln-btn" id="btnOrdersShop">Start Shopping</button></div>`;
      $('btnOrdersShop').onclick = closeOverlay;
      return;
    }

    $('uPageBody').innerHTML = orders
      .map((o) => {
        const remaining = Math.max(0, 300000 - (Date.now() - Number(o.createdAtMs || 0)));
        const canEdit = remaining > 0 && o.status === 'Placed';
        const historyHtml = (o.statusHistory || [])
          .map((h) => `<div style="font-size:12px;padding:3px 0;"><strong>${escapeHtml(h.status)}</strong> · <span style="color:var(--text-muted);">${formatDateTime(h.timestamp)}</span></div>`)
          .join('');
        return `
        <div class="ln-card" style="margin-bottom:14px;">
          <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border);padding-bottom:10px;margin-bottom:10px;">
            <div>
              <strong class="mono">#${escapeHtml(o.id)}</strong>
              <div style="font-size:11px;color:var(--text-muted);">${formatDateTime(o.createdAt)}</div>
            </div>
            <span class="ln-status ${o.status === 'Delivered' ? 'ln-status-success' : o.status === 'Cancelled' ? 'ln-status-error' : 'ln-status-info'}">${escapeHtml(o.status)}</span>
          </div>

          <div style="display:grid;gap:6px;margin-bottom:10px;">
            ${(o.items || []).map((i) => `<div style="display:flex;justify-content:space-between;font-size:13px;"><span>${escapeHtml(i.name)} × ${i.qty}</span><strong class="tabular">${money(i.lineTotal)}</strong></div>`).join('')}
          </div>
          <div style="font-size:13px;border-top:1px solid var(--border);padding-top:8px;">
            <div>Total Paid: <strong class="tabular" style="color:var(--gold);">${money(o.total)}</strong> (${escapeHtml(o.payment)})</div>
            <div style="color:var(--text-muted);font-size:12px;margin-top:4px;">Delivery: ${escapeHtml(o.customer?.name)}, ${escapeHtml(o.customer?.phone)} · ${escapeHtml(o.customer?.address)}, ${escapeHtml(o.customer?.upazila)}, ${escapeHtml(o.customer?.district)}</div>
          </div>

          <details style="margin-top:10px;font-size:12px;">
            <summary style="cursor:pointer;font-weight:600;color:var(--gold);">Order Status History (${(o.statusHistory || []).length})</summary>
            <div style="padding:8px 0 0 8px;border-left:1px solid var(--border);margin-top:6px;">${historyHtml}</div>
          </details>

          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;">
            ${
              canEdit
                ? `<button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-edit-order="${escapeAttr(o.id)}">✎ Edit Delivery (<span data-order-timer="${escapeAttr(o.id)}">${Math.ceil(remaining / 1000)}s</span>)</button>`
                : ''
            }
            ${
              ['Placed', 'Confirmed'].includes(o.status)
                ? `<button type="button" class="ln-btn ln-btn-danger ln-btn-sm" data-cancel-order="${escapeAttr(o.id)}">Cancel Order</button>`
                : ''
            }
            ${
              o.status === 'Delivered'
                ? `<button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-return-order="${escapeAttr(o.id)}">Request Return</button>`
                : ''
            }
          </div>
        </div>`;
      })
      .join('');

    $('uPageBody').querySelectorAll('[data-edit-order]').forEach((btn) => {
      btn.onclick = () => {
        const order = listOrdersForUser(user).find((x) => x.id === btn.dataset.editOrder);
        if (!order) return;
        let modal = document.getElementById('ln-edit-deliv-modal');
        if (!modal) {
          modal = document.createElement('div');
          modal.id = 'ln-edit-deliv-modal';
          modal.className = 'ln-modal-backdrop';
          document.body.appendChild(modal);
        }
        modal.innerHTML = `
          <div class="ln-modal" role="dialog" aria-modal="true" aria-label="Edit Delivery Details">
            <div style="font-size:11px;font-weight:700;letter-spacing:0.12em;color:var(--gold);text-transform:uppercase;">ORDER #${escapeHtml(order.id)}</div>
            <h3 style="font-family:var(--font-serif);font-size:20px;margin:4px 0 14px;">Edit Delivery Details</h3>
            <div class="ln-field"><label>Recipient Name *</label><input id="edDelName" class="ln-input" value="${escapeAttr(order.customer?.name || '')}" /></div>
            <div class="ln-field"><label>Phone Number *</label><input id="edDelPhone" class="ln-input" value="${escapeAttr(order.customer?.phone || '')}" /></div>
            <div class="ln-field"><label>Full Address *</label><textarea id="edDelAddr" class="ln-textarea">${escapeHtml(order.customer?.address || '')}</textarea></div>
            <div class="ln-modal-actions">
              <button type="button" class="ln-btn ln-btn-outline" id="edDelCancel">Cancel</button>
              <button type="button" class="ln-btn ln-btn-gold" id="edDelSave">Save Changes</button>
            </div>
          </div>
        `;
        modal.classList.add('open');
        modal.querySelector('#edDelCancel').onclick = () => modal.classList.remove('open');
        modal.querySelector('#edDelSave').onclick = () => {
          try {
            updateOrderDeliveryDetails(
              order.id,
              {
                ...order.customer,
                name: modal.querySelector('#edDelName').value.trim(),
                phone: modal.querySelector('#edDelPhone').value.trim(),
                address: modal.querySelector('#edDelAddr').value.trim(),
              },
              user
            );
            modal.classList.remove('open');
            showToast('Delivery details updated', 'success');
            draw();
          } catch (err) {
            showToast(err.message, 'error');
          }
        };
      };
    });
    $('uPageBody').querySelectorAll('[data-cancel-order]').forEach((btn) => {
      btn.onclick = async () => {
        const ok = await openConfirmDialog({ title: 'Cancel Order', message: 'Are you sure you want to cancel this order?', confirmLabel: 'Yes, Cancel', danger: true });
        if (!ok) return;
        try {
          updateOrderStatus(btn.dataset.cancelOrder, 'Cancelled', user, 'Cancelled by customer');
          showToast('Order cancelled', 'success');
          draw();
        } catch (err) {
          showToast(err.message, 'error');
        }
      };
    });
    $('uPageBody').querySelectorAll('[data-return-order]').forEach((btn) => {
      btn.onclick = () => {
        try {
          updateOrderStatus(btn.dataset.returnOrder, 'Return Requested', user, 'Customer requested return');
          showToast('Return request submitted', 'success');
          draw();
        } catch (err) {
          showToast(err.message, 'error');
        }
      };
    });

    if (state.orderTimer) clearInterval(state.orderTimer);
    state.orderTimer = setInterval(() => {
      document.querySelectorAll('[data-order-timer]').forEach((el) => {
        const oid = el.dataset.orderTimer;
        const ord = listOrdersForUser(user).find((x) => x.id === oid);
        if (!ord) return;
        const left = Math.max(0, 300000 - (Date.now() - Number(ord.createdAtMs || 0)));
        if (left <= 0) draw();
        else {
          const m = Math.floor(left / 60000);
          const s = Math.floor((left % 60000) / 1000);
          el.textContent = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
        }
      });
    }, 1000);
  };
  draw();
}

function openAffiliatePage() {
  const flag = getFeatureStatus('affiliateProgram');
  openOverlay('Affiliate Partner Program', 'affiliate');
  if (!flag.enabled) {
    $('uPageBody').innerHTML = `<div class="ln-empty"><h4>Affiliate Program Paused</h4><p>${escapeHtml(flag.maintenanceMessage)}</p></div>`;
    return;
  }

  const signedInUser = getActiveUser('user');
  if (!signedInUser) {
    $('uPageBody').innerHTML = `
      <div class="ln-card" style="text-align:center;padding:30px 18px;">
        <h2 style="font-size:20px;margin-bottom:8px;">LUXE NEXUS Affiliate Program</h2>
        <p style="font-size:13px;color:var(--text-muted);max-width:44ch;margin:0 auto 16px;">Earn verified commissions by sharing curated 7-day product and collection referral links.</p>
        <button type="button" class="ln-btn ln-btn-gold" id="btnAffSignIn">Sign In to Join or Open Dashboard</button>
      </div>
    `;
    $('btnAffSignIn').onclick = openAccountPage;
    return;
  }

  const PROMOTION_MEDIUMS = ['Facebook', 'YouTube', 'Instagram', 'TikTok', 'Blog / Website', 'WhatsApp / Community', 'Other'];

  const draw = () => {
    const user = getActiveUser('user') || signedInUser;
    const cfg = getPlatformConfig();
    const aff = getAffiliateByUserId(user.uid);
    const rulesListHtml = AFFILIATE_PROGRAM_RULES.map(
      (r) => `
      <div style="padding:8px 10px;border-bottom:1px solid var(--border);font-size:12px;">
        <div style="font-weight:700;color:var(--text);">${r.id}. ${escapeHtml(r.title)}</div>
        <div style="color:var(--text-muted);margin-top:2px;">${escapeHtml(r.description)}</div>
      </div>`
    ).join('');

    if (aff?.status === 'banned') {
      $('uPageBody').innerHTML = `
        <div class="ln-card" style="text-align:center;padding:34px 20px;border-color:var(--error);">
          <div style="font-size:12px;font-weight:700;color:var(--error);text-transform:uppercase;">Affiliate Status: BANNED</div>
          <h2 style="font-size:21px;margin:8px 0;">Affiliate Account Permanently Banned</h2>
          <p style="font-size:13px;color:var(--text-muted);max-width:48ch;margin:0 auto;">
            ${escapeHtml(aff.rejectionReason || 'Access to the Affiliate Program was permanently revoked due to a rule violation.')}
          </p>
        </div>
      `;
      return;
    }

    if (!aff || aff.status === 'rejected') {
      const initElig = evaluateAffiliateEligibility(user, aff, cfg);
      const renderChecklist = (elig) =>
        elig.checks
          .map(
            (c) => `
          <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;padding:7px 10px;border-radius:10px;border:1px solid ${c.passed ? 'rgba(67,181,129,0.35)' : 'rgba(229,83,75,0.35)'};background:${c.passed ? 'rgba(67,181,129,0.08)' : 'rgba(229,83,75,0.06)'};font-size:12px;">
            <div>
              <strong style="color:${c.passed ? 'var(--success)' : 'var(--error)'};">${c.passed ? '✓' : '✕'} ${escapeHtml(c.label)}</strong>
              <div style="color:var(--text-muted);font-size:11px;">${escapeHtml(c.detail)}</div>
            </div>
            <span style="font-size:10px;font-weight:700;text-transform:uppercase;color:${c.passed ? 'var(--success)' : 'var(--error)'};">${c.passed ? 'Ready' : 'Locked'}</span>
          </div>`
          )
          .join('');

      $('uPageBody').innerHTML = `
        <div class="ln-card" style="max-width:680px;margin:0 auto;">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;margin-bottom:12px;">
            <div>
              <div style="font-size:11px;font-weight:700;letter-spacing:0.1em;color:var(--gold);text-transform:uppercase;">PARTNER APPLICATION &amp; ELIGIBILITY GATE</div>
              <h2 style="font-size:21px;margin-top:2px;">Join the Affiliate Program</h2>
            </div>
            <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="btnGoVerifyProfile">Complete &amp; Verify Profile ›</button>
          </div>
          <p style="font-size:13px;color:var(--text-muted);margin-bottom:14px;">
            Accounts must be at least ${initElig.minAccountAgeHours}h (${Math.round(initElig.minAccountAgeHours / 24)} days) old, aged ${initElig.minApplicantAge}+, with verified email &amp; mobile, a complete profile, and an active social or website link. Dashboard &amp; referral tools unlock only after Admin approval.
          </p>

          ${
            aff?.status === 'rejected'
              ? `<div class="ln-card" style="border-color:var(--error);margin-bottom:14px;font-size:13px;background:rgba(229,83,75,0.08);">
                  <strong>Previous application declined:</strong> ${escapeHtml(aff.rejectionReason || 'Policy review')}
                  ${initElig.cooldownBlocked ? `<div style="margin-top:4px;color:var(--error);font-weight:700;">Cooldown active: ${initElig.cooldownRemainingHours}h remaining before reapplication.</div>` : ''}
                </div>`
              : ''
          }

          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:8px;margin-bottom:16px;" id="affEligibilityList">
            ${renderChecklist(initElig)}
          </div>

          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px;">
            <div class="ln-field"><label>Full Name *</label><input id="affAppName" class="ln-input" value="${escapeAttr(user.name)}" /></div>
            <div class="ln-field"><label>User ID</label><input class="ln-input mono" value="${escapeAttr(user.uid)}" readonly /></div>
            <div class="ln-field"><label>Phone Number *</label><input id="affAppPhone" class="ln-input" value="${escapeAttr(user.phone || '')}" placeholder="01XXXXXXXXX" /></div>
            <div class="ln-field"><label>Email Address *</label><input id="affAppEmail" class="ln-input" value="${escapeAttr(user.email)}" readonly /></div>
            <div class="ln-field"><label>Age (Years, Min ${initElig.minApplicantAge}) *</label><input id="affAppAge" type="number" min="10" max="120" class="ln-input" value="${escapeAttr(initElig.age ?? '')}" placeholder="e.g. 22" /></div>
            <div class="ln-field">
              <label>Promotion Medium *</label>
              <select id="affAppMedium" class="ln-select">
                <option value="">Select primary channel...</option>
                ${PROMOTION_MEDIUMS.map((m) => `<option value="${escapeAttr(m)}">${escapeHtml(m)}</option>`).join('')}
              </select>
            </div>
            <div class="ln-field"><label>Social Media / Website Link *</label><input id="affAppSocial" class="ln-input" value="${escapeAttr(user.socialUrl || '')}" placeholder="https://facebook.com/yourpage or https://..." /></div>
            <div class="ln-field"><label>Follower / Audience Count *</label><input id="affAppFollowers" type="number" min="0" class="ln-input" value="0" placeholder="e.g. 5000" /></div>
          </div>
          <div class="ln-field">
            <label>Marketing Plan *</label>
            <textarea id="affAppPlan" class="ln-textarea" placeholder="Describe how you plan to promote LUXE NEXUS products (channels, content style, audience focus)..."></textarea>
          </div>

          <div class="ln-card" style="padding:10px 12px;margin-bottom:12px;background:var(--surface-alt);">
            <div style="font-size:12px;font-weight:700;color:var(--gold);margin-bottom:6px;text-transform:uppercase;">10 Affiliate Program Rules (Mandatory)</div>
            <div style="max-height:190px;overflow-y:auto;">${rulesListHtml}</div>
          </div>

          <label style="display:flex;align-items:center;gap:8px;font-size:12px;margin:10px 0 12px;cursor:pointer;">
            <input type="checkbox" id="affAppTerms" /> I agree to all 10 Affiliate Program Rules, 7-day link attribution, and Admin verification policies.
          </label>
          <div id="affSubmitLockHint" style="font-size:12px;color:${initElig.eligible ? 'var(--success)' : 'var(--error)'};margin-bottom:10px;font-weight:600;">
            ${initElig.eligible ? '✓ All eligibility requirements satisfied — ready to submit.' : `Locked: ${escapeHtml(initElig.blockingReason)}`}
          </div>
          <button type="button" class="ln-btn ln-btn-gold" id="btnSubmitAffApp" style="width:100%;" ${initElig.eligible ? '' : 'disabled'}>Submit Affiliate Application</button>
        </div>
      `;

      const refreshEligUi = () => {
        const liveElig = evaluateAffiliateEligibility(user, aff, cfg, null, {
          name: $('affAppName')?.value,
          phone: $('affAppPhone')?.value,
          age: $('affAppAge')?.value,
          socialLink: $('affAppSocial')?.value,
        });
        const listEl = $('affEligibilityList');
        if (listEl) listEl.innerHTML = renderChecklist(liveElig);
        const btn = $('btnSubmitAffApp');
        if (btn) btn.disabled = !liveElig.eligible;
        const hint = $('affSubmitLockHint');
        if (hint) {
          hint.style.color = liveElig.eligible ? 'var(--success)' : 'var(--error)';
          hint.textContent = liveElig.eligible
            ? '✓ All eligibility requirements satisfied — ready to submit.'
            : `Locked: ${liveElig.blockingReason}`;
        }
      };

      ['affAppName', 'affAppPhone', 'affAppAge', 'affAppSocial'].forEach((id) => {
        $(id)?.addEventListener('input', refreshEligUi);
      });

      $('btnGoVerifyProfile').onclick = openAccountPage;
      $('btnSubmitAffApp').onclick = () => {
        try {
          applyForAffiliate({
            name: $('affAppName').value,
            userId: user.uid,
            phone: $('affAppPhone').value,
            email: $('affAppEmail').value,
            age: $('affAppAge').value,
            socialLink: $('affAppSocial').value,
            followerCount: $('affAppFollowers').value,
            promotionMedium: $('affAppMedium').value,
            marketingPlan: $('affAppPlan').value,
            termsAccepted: $('affAppTerms').checked,
          });
          showToast('Affiliate application submitted for Admin review', 'success');
          draw();
        } catch (err) {
          showToast(err.message, 'error');
        }
      };
      return;
    }

    if (aff.status === 'pending' || aff.status === 'suspended') {
      $('uPageBody').innerHTML = `
        <div class="ln-card" style="text-align:center;padding:34px 20px;">
          <div style="font-size:12px;font-weight:700;color:${aff.status === 'suspended' ? 'var(--error)' : 'var(--gold)'};text-transform:uppercase;">Affiliate Status: ${escapeHtml(aff.status)}</div>
          <h2 style="font-size:21px;margin:8px 0;">${aff.status === 'pending' ? 'Application Under Admin Review' : 'Affiliate Account Suspended'}</h2>
          <p style="font-size:13px;color:var(--text-muted);max-width:48ch;margin:0 auto;">
            ${
              aff.status === 'pending'
                ? 'Your Affiliate Dashboard, referral link creation, and commission tools remain locked until an Admin verifies and approves your application.'
                : escapeHtml(aff.rejectionReason || 'Your affiliate account is currently suspended. Contact Admin support for review.')
            }
          </p>
        </div>
      `;
      return;
    }

    // Approved Affiliate Full Dashboard + Level Progression
    const levelEval = evaluateAffiliateLevel(aff.id);
    const liveAff = levelEval?.affiliate || aff;
    const currentTier = levelEval?.currentTier;
    const nextTier = levelEval?.nextTier;
    const allLevels = levelEval?.levels || getAffiliateLevels(cfg);
    const tierStats = levelEval?.stats;
    const metrics = getAffiliateDashboardMetrics(aff.id);
    const links = listAffiliateLinks(aff.id);
    const comms = appServices.affiliates.commissions.list().filter((c) => c.affiliateId === aff.id);
    const withdrawals = appServices.affiliates.withdrawals.list().filter((w) => w.affiliateId === aff.id);
    const prods = listPublishedProducts();
    const cats = listCategories();
    const isHeld = Boolean(liveAff.commissionHold || liveAff.withdrawalHold);

    let tabHtml = '';
    if (state.affiliateTab === 'dashboard') {
      tabHtml = `
        <div class="ln-card" style="margin-bottom:14px;border:1px solid ${escapeAttr(currentTier?.badgeColor || 'var(--gold)')};">
          <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:10px;">
            <div>
              <div style="font-size:11px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:${escapeAttr(currentTier?.badgeColor || 'var(--gold)')};">AFFILIATE LEVEL STATUS</div>
              <h3 style="font-size:20px;margin:2px 0;display:flex;align-items:center;gap:8px;">
                <span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:${escapeAttr(currentTier?.badgeColor || 'var(--gold)')};"></span>
                ${escapeHtml(currentTier?.name || 'Bronze')} Level · <span style="color:var(--gold);">${Number(currentTier?.commissionRate || 8)}% Commission</span>
              </h3>
              <div style="font-size:12px;color:var(--text-muted);">${escapeHtml(currentTier?.subtitle || '')}</div>
            </div>
            <div style="text-align:right;font-size:12px;">
              <div>Verified Orders: <strong>${tierStats?.lifetimeOrders ?? 0}</strong></div>
              <div>Verified Sales: <strong class="tabular">${money(tierStats?.lifetimeSales ?? 0)}</strong></div>
            </div>
          </div>
          ${
            nextTier
              ? `<div style="padding:10px 12px;border-radius:10px;background:var(--surface-alt);border:1px solid var(--border);margin-bottom:10px;">
                  <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;font-size:12px;margin-bottom:6px;">
                    <strong>Next Level: ${escapeHtml(nextTier.name)} (${Number(nextTier.commissionRate)}% Commission)</strong>
                    <span style="color:var(--text-muted);">${tierStats.ordersRemaining} orders &amp; ${money(tierStats.salesRemaining)} sales needed</span>
                  </div>
                  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px;font-size:11px;">
                    <div>
                      <div style="display:flex;justify-content:space-between;margin-bottom:4px;"><span>Orders Target</span><strong>${tierStats.lifetimeOrders} / ${nextTier.minOrders}</strong></div>
                      <div style="height:7px;background:rgba(255,255,255,0.08);border-radius:999px;overflow:hidden;"><div style="width:${tierStats.ordersProgress}%;height:100%;background:var(--gold);"></div></div>
                    </div>
                    <div>
                      <div style="display:flex;justify-content:space-between;margin-bottom:4px;"><span>Sales Target</span><strong>${money(tierStats.lifetimeSales)} / ${money(nextTier.minSales)}</strong></div>
                      <div style="height:7px;background:rgba(255,255,255,0.08);border-radius:999px;overflow:hidden;"><div style="width:${tierStats.salesProgress}%;height:100%;background:var(--success);"></div></div>
                    </div>
                  </div>
                </div>`
              : `<div style="padding:8px 12px;border-radius:10px;background:rgba(124,232,255,0.08);border:1px solid rgba(124,232,255,0.35);font-size:12px;margin-bottom:10px;">★ You have reached the highest <strong>Diamond Level</strong> tier!</div>`
          }
          <div style="display:flex;gap:8px;flex-wrap:wrap;font-size:11px;color:var(--text-muted);">
            ${(currentTier?.benefits || []).map((b) => `<span style="padding:4px 8px;border:1px solid var(--border);border-radius:6px;">✓ ${escapeHtml(b)}</span>`).join('')}
          </div>
          ${
            currentTier && currentTier.order > 1
              ? `<div style="margin-top:8px;font-size:11px;color:var(--text-muted);">Retention Requirement (${tierStats.windowDays}-day window): ${tierStats.recentOrders}/${currentTier.retainOrdersInWindow} orders · ${money(tierStats.recentSales)}/${money(currentTier.retainSalesInWindow)} sales</div>`
              : ''
          }
        </div>

        <div class="u-stats-4" style="margin-bottom:16px;">
          <div class="u-stat-box"><small>Available Balance</small><strong style="color:var(--success);">${money(metrics.availableBalance)}</strong></div>
          <div class="u-stat-box"><small>Pending Commission</small><strong>${money(metrics.pendingCommission)}</strong></div>
          <div class="u-stat-box"><small>Total Sales Driven</small><strong>${money(metrics.totalSales)}</strong></div>
          <div class="u-stat-box"><small>Conversion Rate</small><strong>${metrics.conversionRate}%</strong></div>
          <div class="u-stat-box"><small>Total / Unique Clicks</small><strong>${metrics.totalClicks} / ${metrics.uniqueClicks}</strong></div>
          <div class="u-stat-box"><small>Orders / Conversions</small><strong>${metrics.totalOrders} / ${metrics.successfulConversions}</strong></div>
          <div class="u-stat-box"><small>Today / Weekly</small><strong>${money(metrics.todayEarnings)} / ${money(metrics.weeklyEarnings)}</strong></div>
          <div class="u-stat-box"><small>Monthly / Lifetime</small><strong>${money(metrics.monthlyEarnings)} / ${money(metrics.lifetimeEarnings)}</strong></div>
        </div>
        <div class="ln-card">
          <h3 style="font-size:15px;margin-bottom:8px;">Earnings Summary</h3>
          <div class="ln-table-wrap">
            <table class="ln-table">
              <tr><td>Approved Commission</td><td class="tabular"><strong>${money(metrics.approvedCommission)}</strong></td><td>Paid Commission</td><td class="tabular"><strong>${money(metrics.paidCommission)}</strong></td></tr>
              <tr><td>Withdrawn Amount</td><td class="tabular"><strong>${money(metrics.withdrawnAmount)}</strong></td><td>Pending / Held Payout</td><td class="tabular"><strong>${money(metrics.pendingWithdrawal)}</strong></td></tr>
              <tr><td>Held Commissions</td><td class="tabular"><strong style="color:var(--warning);">${money(metrics.heldCommission)}</strong></td><td>Rejected / Reversed</td><td class="tabular"><strong>${money(metrics.rejectedCommission)}</strong></td></tr>
            </table>
          </div>
        </div>
      `;
    } else if (state.affiliateTab === 'links') {
      tabHtml = `
        <div class="ln-card" style="margin-bottom:14px;">
          <h3 style="font-size:16px;margin-bottom:10px;">Create 7-Day Referral Link (${Number(cfg.affiliateConfig?.linkExpiryHours || 168)} Hours)</h3>
          <div class="ln-field">
            <label>Link Type</label>
            <input type="hidden" id="affLinkType" value="store" />
            <div class="ln-seg-grid" id="affLinkTypeCards">
              <button type="button" class="ln-seg-card active" data-aff-ltype="store"><div><strong>Store Link</strong><small>Full storefront</small></div><span class="ln-seg-accent">✓</span></button>
              <button type="button" class="ln-seg-card" data-aff-ltype="product"><div><strong>Product Link</strong><small>Single item</small></div></button>
              <button type="button" class="ln-seg-card" data-aff-ltype="category"><div><strong>Category Link</strong><small>Department</small></div></button>
            </div>
          </div>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;">
            <div class="ln-field" id="affLinkTargetWrap" style="display:none;"><label>Target</label><select id="affLinkTarget" class="ln-select"></select></div>
            <div class="ln-field"><label>Campaign Label</label><input id="affLinkLabel" class="ln-input" placeholder="e.g. Facebook Spring Post" /></div>
          </div>
          <button type="button" class="ln-btn ln-btn-gold" id="btnCreateAffLink">Generate 7-Day Link</button>
        </div>

        <div class="ln-card">
          <h3 style="font-size:16px;margin-bottom:10px;">My Referral Links (${links.length})</h3>
          ${
            links.length
              ? links
                  .map((l) => {
                    const liveStatus = evaluateLinkStatus(l);
                    const fullUrl = `${window.location.origin}/${l.urlQuery}`;
                    const hrsLeft = Math.max(0, Math.round((Number(l.expiresAtMs || 0) - Date.now()) / 3600000));
                    return `
                    <div style="padding:12px 0;border-bottom:1px solid var(--border);">
                      <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;">
                        <div>
                          <strong>${escapeHtml(l.label)}</strong> · <span class="mono" style="font-size:12px;">${escapeHtml(l.code)}</span>
                          <div style="font-size:11px;color:var(--text-muted);">${escapeHtml(l.type)} · ${liveStatus === 'active' ? `${hrsLeft}h remaining` : `Status: ${liveStatus}`}</div>
                        </div>
                        <span class="ln-status ${liveStatus === 'active' || liveStatus === 'sold' ? 'ln-status-success' : 'ln-status-muted'}">${escapeHtml(liveStatus.toUpperCase())}</span>
                      </div>
                      <div style="font-size:12px;color:var(--text-muted);margin:6px 0;">Clicks: ${l.clicks} (${l.uniqueClicks} unique) · Orders: ${l.orders} · Sales: ${money(l.sales)} · Commission: ${money(l.commission)}</div>
                      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px;">
                        <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-copy-link="${escapeAttr(fullUrl)}">Copy Link</button>
                        <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-qr-link="${escapeAttr(fullUrl)}" data-qr-label="${escapeAttr(l.label)}">QR Code</button>
                        <a class="ln-btn ln-btn-outline ln-btn-sm" style="text-decoration:none;" target="_blank" rel="noopener noreferrer" href="https://wa.me/?text=${encodeURIComponent(fullUrl)}">WhatsApp</a>
                        <a class="ln-btn ln-btn-outline ln-btn-sm" style="text-decoration:none;" target="_blank" rel="noopener noreferrer" href="https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(fullUrl)}">Facebook</a>
                        ${liveStatus === 'active' ? `<button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-disable-link="${escapeAttr(l.id)}">Disable</button>` : ''}
                        <button type="button" class="ln-btn ln-btn-danger ln-btn-sm" data-delete-link="${escapeAttr(l.id)}">Delete</button>
                      </div>
                    </div>`;
                  })
                  .join('')
              : '<div class="ln-empty">No referral links created yet.</div>'
          }
        </div>
      `;
    } else if (state.affiliateTab === 'commissions') {
      tabHtml = `
        <div class="ln-card">
          <h3 style="font-size:16px;margin-bottom:10px;">Commission Ledger</h3>
          ${
            comms.length
              ? `<div class="ln-table-wrap"><table class="ln-table"><thead><tr><th>Order</th><th>Link</th><th>Level Rate</th><th>Order Total</th><th>Commission</th><th>Status</th></tr></thead><tbody>${comms
                  .map(
                    (c) => `<tr><td class="mono">${escapeHtml(c.orderId)}</td><td class="mono">${escapeHtml(c.linkCode)}</td><td>${escapeHtml(String(c.affiliateLevel || 'bronze').toUpperCase())} (${Number(c.commissionRateApplied || 8)}%)</td><td class="tabular">${money(c.orderTotal)}</td><td class="tabular"><strong>${money(c.commissionAmount)}</strong></td><td><span class="ln-status ${c.status === 'approved' || c.status === 'paid' ? 'ln-status-success' : c.status === 'pending' || c.status === 'held' ? 'ln-status-warning' : 'ln-status-error'}">${escapeHtml(c.status)}</span></td></tr>`
                  )
                  .join('')}</tbody></table></div>`
              : '<div class="ln-empty">No commissions recorded yet.</div>'
          }
        </div>
      `;
    } else if (state.affiliateTab === 'withdraw') {
      const withdrawLocked = Boolean(liveAff.withdrawalHold || liveAff.commissionHold);
      tabHtml = `
        <div class="ln-card" style="margin-bottom:14px;">
          <h3 style="font-size:16px;margin-bottom:6px;">Request Payout</h3>
          <p style="font-size:12px;color:var(--text-muted);margin-bottom:12px;">Available Balance: <strong class="tabular" style="color:var(--success);">${money(metrics.availableBalance)}</strong> · Minimum Withdrawal: <strong class="tabular">${money(cfg.affiliateConfig?.minWithdrawal || 500)}</strong></p>
          ${withdrawLocked ? `<div class="ln-card" style="border-color:var(--error);margin-bottom:12px;font-size:12px;background:rgba(229,83,75,0.08);"><strong>Payouts Temporarily On Hold (Rule #7):</strong> ${escapeHtml(liveAff.holdReason || 'Admin verification hold active.')}</div>` : ''}
          <div class="ln-field">
            <label>Payout Method</label>
            <input type="hidden" id="wMethod" value="bKash" />
            <div class="ln-seg-grid" id="wMethodCards">
              <button type="button" class="ln-seg-card active" data-w-method="bKash"><div><strong>bKash</strong><small>Mobile Wallet</small></div><span class="ln-seg-accent">✓</span></button>
              <button type="button" class="ln-seg-card" data-w-method="Nagad"><div><strong>Nagad</strong><small>Mobile Wallet</small></div></button>
              <button type="button" class="ln-seg-card" data-w-method="Bank"><div><strong>Bank Transfer</strong><small>BEFTN / IBAN</small></div></button>
            </div>
          </div>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;">
            <div class="ln-field"><label>Amount (BDT)</label><input id="wAmount" type="number" class="ln-input" placeholder="${cfg.affiliateConfig?.minWithdrawal || 500}" /></div>
            <div class="ln-field"><label>Account Holder *</label><input id="wHolder" class="ln-input" value="${escapeAttr(liveAff.name)}" /></div>
            <div class="ln-field"><label>Account / Wallet Number *</label><input id="wNumber" class="ln-input" value="${escapeAttr(liveAff.phone)}" /></div>
          </div>
          <button type="button" class="ln-btn ln-btn-gold" id="btnReqWithdraw" ${withdrawLocked ? 'disabled' : ''}>Submit Withdrawal Request</button>
        </div>

        <div class="ln-card">
          <h3 style="font-size:16px;margin-bottom:10px;">Withdrawal History</h3>
          ${
            withdrawals.length
              ? `<div class="ln-table-wrap"><table class="ln-table"><thead><tr><th>ID</th><th>Method</th><th>Amount</th><th>Status</th><th>Tx / Ref</th></tr></thead><tbody>${withdrawals
                  .map(
                    (w) => `<tr><td class="mono">${escapeHtml(w.id)}</td><td>${escapeHtml(w.method)} (${escapeHtml(w.accountNumber)})</td><td class="tabular"><strong>${money(w.amount)}</strong></td><td>${escapeHtml(w.status)}</td><td class="mono">${escapeHtml(w.transactionId || '—')}</td></tr>`
                  )
                  .join('')}</tbody></table></div>`
              : '<div class="ln-empty">No withdrawal requests yet.</div>'
          }
        </div>
      `;
    } else if (state.affiliateTab === 'levels') {
      tabHtml = `
        <div class="ln-card" style="margin-bottom:14px;">
          <h3 style="font-size:16px;margin-bottom:10px;">Affiliate Level Tiers (Bronze · Silver · Gold · Diamond)</h3>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px;">
            ${allLevels
              .map((lvl) => {
                const isCur = lvl.id === currentTier?.id;
                return `
                <div class="ln-card" style="border-color:${isCur ? escapeAttr(lvl.badgeColor) : 'var(--border)'};background:${isCur ? 'rgba(201,164,92,0.08)' : 'var(--surface-alt)'};">
                  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">
                    <strong style="color:${escapeAttr(lvl.badgeColor)};font-size:15px;">${escapeHtml(lvl.name)} Level</strong>
                    <span style="font-size:13px;font-weight:700;color:var(--gold);">${Number(lvl.commissionRate)}%</span>
                  </div>
                  <div style="font-size:11px;color:var(--text-muted);margin-bottom:8px;">${escapeHtml(lvl.subtitle)}${isCur ? ' · CURRENT' : ''}</div>
                  <div style="font-size:11px;margin-bottom:6px;">
                    <div>Upgrade: <strong>${lvl.minOrders} orders</strong> &amp; <strong>${money(lvl.minSales)}</strong> sales</div>
                    ${lvl.order > 1 ? `<div>Retention: ${lvl.retainOrdersInWindow} orders &amp; ${money(lvl.retainSalesInWindow)} / ${tierStats.windowDays}d</div>` : '<div>Entry tier (no retention minimum)</div>'}
                  </div>
                  <div style="font-size:11px;color:var(--text-muted);">
                    ${(lvl.benefits || []).map((b) => `<div>• ${escapeHtml(b)}</div>`).join('')}
                  </div>
                </div>`;
              })
              .join('')}
          </div>
        </div>
        <div class="ln-card">
          <h3 style="font-size:16px;margin-bottom:8px;">10 Enforced Affiliate Program Rules</h3>
          ${rulesListHtml}
        </div>
      `;
    } else if (state.affiliateTab === 'leaderboard') {
      const board = getAffiliateLeaderboard(state.leaderboardPeriod);
      tabHtml = `
        <div class="ln-card">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
            <h3 style="font-size:16px;">Top Affiliates (${escapeHtml(state.leaderboardPeriod)})</h3>
            <div style="display:flex;gap:6px;">
              <button type="button" class="ln-btn ln-btn-sm ${state.leaderboardPeriod === 'weekly' ? '' : 'ln-btn-outline'}" data-lb-period="weekly">Weekly</button>
              <button type="button" class="ln-btn ln-btn-sm ${state.leaderboardPeriod === 'monthly' ? '' : 'ln-btn-outline'}" data-lb-period="monthly">Monthly</button>
            </div>
          </div>
          ${
            board.length
              ? `<div class="ln-table-wrap"><table class="ln-table"><thead><tr><th>Rank</th><th>Partner</th><th>Level</th><th>Orders</th><th>Conv.</th><th>Sales</th><th>Commission</th></tr></thead><tbody>${board
                  .map((r, i) => `<tr><td>#${i + 1}</td><td><strong>${escapeHtml(r.name)}</strong> (${escapeHtml(r.affiliateCode)})</td><td><span style="color:${escapeAttr(r.levelBadgeColor)};font-weight:700;">${escapeHtml(r.levelName)}</span></td><td class="tabular">${r.orders}</td><td class="tabular">${r.conversionRate}%</td><td class="tabular">${money(r.totalSales)}</td><td class="tabular"><strong>${money(r.totalCommission)}</strong></td></tr>`)
                  .join('')}</tbody></table></div>`
              : '<div class="ln-empty">No affiliate leaderboard data yet.</div>'
          }
        </div>
      `;
    } else if (state.affiliateTab === 'profile') {
      const affNotifs = getNotificationsForScope('affiliate', user.uid).slice(0, 10);
      tabHtml = `
        <div class="ln-card" style="margin-bottom:14px;">
          <h3 style="font-size:16px;margin-bottom:10px;">Partner Profile · <span class="mono">${escapeHtml(liveAff.affiliateCode)}</span></h3>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px;">
            <div class="ln-field"><label>Display Name</label><input id="affProfName" class="ln-input" value="${escapeAttr(liveAff.name)}" /></div>
            <div class="ln-field"><label>Phone</label><input id="affProfPhone" class="ln-input" value="${escapeAttr(liveAff.phone)}" /></div>
            <div class="ln-field"><label>Social / Website URL</label><input id="affProfSocial" class="ln-input" value="${escapeAttr(liveAff.socialLink || '')}" /></div>
            <div class="ln-field"><label>Promotion Medium</label><input id="affProfMedium" class="ln-input" value="${escapeAttr(liveAff.promotionMedium || '')}" /></div>
          </div>
          <div class="ln-field"><label>Marketing Plan / Bio</label><textarea id="affProfBio" class="ln-textarea">${escapeHtml(liveAff.marketingPlan || liveAff.bio || '')}</textarea></div>
          <button type="button" class="ln-btn" id="btnSaveAffProf">Save Profile</button>
        </div>
        <div class="ln-card">
          <h3 style="font-size:16px;margin-bottom:10px;">Affiliate Notifications</h3>
          ${affNotifs.length ? affNotifs.map((n) => `<div style="padding:8px 0;border-bottom:1px solid var(--border);font-size:13px;"><strong>${escapeHtml(n.title)}</strong><div style="color:var(--text-muted);">${escapeHtml(n.message)}</div></div>`).join('') : '<p style="color:var(--text-muted);font-size:13px;">No affiliate notifications yet.</p>'}
        </div>
      `;
    }

    $('uPageBody').innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:14px;">
        <div>
          <div style="font-size:12px;color:var(--gold);font-weight:700;">
            APPROVED PARTNER · ${escapeHtml(liveAff.affiliateCode)} · <span style="color:${escapeAttr(currentTier?.badgeColor || 'var(--gold)')};">${escapeHtml(currentTier?.name || 'Bronze')} (${Number(currentTier?.commissionRate || 8)}%)</span>
          </div>
          <h2 style="font-size:19px;">${escapeHtml(liveAff.name)}</h2>
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;">
          ${[
            ['dashboard', 'Dashboard'],
            ['links', 'Links & QR'],
            ['commissions', 'Commissions'],
            ['withdraw', 'Withdraw'],
            ['levels', 'Levels & Rules'],
            ['leaderboard', 'Leaderboard'],
            ['profile', 'Profile'],
          ]
            .map(([k, lbl]) => `<button type="button" class="ln-btn ln-btn-sm ${state.affiliateTab === k ? '' : 'ln-btn-outline'}" data-aff-tab="${k}">${lbl}</button>`)
            .join('')}
        </div>
      </div>
      ${isHeld ? `<div class="ln-card" style="border-color:var(--warning);margin-bottom:12px;font-size:12px;background:rgba(217,155,38,0.1);"><strong>Account Hold Active (Rule #7):</strong> ${escapeHtml(liveAff.holdReason || 'Commissions or payouts are under Admin verification review.')}</div>` : ''}
      ${tabHtml}
    `;

    $('uPageBody').querySelectorAll('[data-aff-tab]').forEach((b) => {
      b.onclick = () => { state.affiliateTab = b.dataset.affTab; draw(); };
    });
    $('uPageBody').querySelectorAll('[data-lb-period]').forEach((b) => {
      b.onclick = () => { state.leaderboardPeriod = b.dataset.lbPeriod; draw(); };
    });

    const typeInp = $('affLinkType');
    if (typeInp) {
      const updateTargets = () => {
        const wrap = $('affLinkTargetWrap');
        const sel = $('affLinkTarget');
        if (typeInp.value === 'store') {
          wrap.style.display = 'none';
        } else if (typeInp.value === 'product') {
          wrap.style.display = 'block';
          sel.innerHTML = prods.map((p) => `<option value="${escapeAttr(p.id)}">${escapeHtml(p.name)}</option>`).join('');
        } else {
          wrap.style.display = 'block';
          sel.innerHTML = cats.map((c) => `<option value="${escapeAttr(c.name)}">${escapeHtml(c.name)}</option>`).join('');
        }
      };
      $('uPageBody').querySelectorAll('[data-aff-ltype]').forEach((b) => {
        b.onclick = () => {
          typeInp.value = b.dataset.affLtype;
          $('uPageBody').querySelectorAll('[data-aff-ltype]').forEach((card) => {
            const active = card === b;
            card.classList.toggle('active', active);
            const mark = card.querySelector('.ln-seg-accent');
            if (active && !mark) card.insertAdjacentHTML('beforeend', '<span class="ln-seg-accent">✓</span>');
            if (!active && mark) mark.remove();
          });
          updateTargets();
        };
      });
      updateTargets();
      $('btnCreateAffLink').onclick = () => {
        try {
          const tSel = $('affLinkTarget');
          const targetId = typeInp.value === 'store' ? '' : tSel.value;
          const targetName = typeInp.value === 'store' ? 'LUXE NEXUS Store' : tSel.options[tSel.selectedIndex]?.text || targetId;
          createAffiliateLink({
            affiliateId: aff.id,
            type: typeInp.value,
            targetId,
            targetName,
            label: $('affLinkLabel').value || targetName,
          });
          showToast('7-day affiliate link generated', 'success');
          draw();
        } catch (err) {
          showToast(err.message, 'error');
        }
      };
    }

    $('uPageBody').querySelectorAll('[data-copy-link]').forEach((b) => {
      b.onclick = async () => {
        await navigator.clipboard?.writeText(b.dataset.copyLink).catch(() => {});
        showToast('Referral link copied to clipboard', 'success');
      };
    });
    $('uPageBody').querySelectorAll('[data-qr-link]').forEach((b) => {
      b.onclick = () => {
        let modal = document.getElementById('ln-qr-modal');
        if (!modal) {
          modal = document.createElement('div');
          modal.id = 'ln-qr-modal';
          modal.className = 'ln-modal-backdrop';
          document.body.appendChild(modal);
        }
        modal.innerHTML = `
          <div class="ln-modal" style="text-align:center;">
            <h3 style="margin-bottom:6px;">${escapeHtml(b.dataset.qrLabel)}</h3>
            <p style="font-size:12px;color:var(--text-muted);margin-bottom:14px;">Scan or share this QR code to track referrals.</p>
            <div style="display:flex;justify-content:center;margin-bottom:14px;">${renderQrSvg(b.dataset.qrLink, 180)}</div>
            <div class="mono" style="font-size:11px;word-break:break-all;margin-bottom:14px;color:var(--text-muted);">${escapeHtml(b.dataset.qrLink)}</div>
            <button type="button" class="ln-btn" id="btnCloseQr">Done</button>
          </div>
        `;
        modal.classList.add('open');
        modal.querySelector('#btnCloseQr').onclick = () => modal.classList.remove('open');
      };
    });
    $('uPageBody').querySelectorAll('[data-disable-link]').forEach((b) => {
      b.onclick = () => { setAffiliateLinkState(b.dataset.disableLink, 'disabled', user.uid); draw(); };
    });
    $('uPageBody').querySelectorAll('[data-delete-link]').forEach((b) => {
      b.onclick = () => { setAffiliateLinkState(b.dataset.deleteLink, 'delete', user.uid); draw(); };
    });

    const wMethodInp = $('wMethod');
    if (wMethodInp) {
      $('uPageBody').querySelectorAll('[data-w-method]').forEach((b) => {
        b.onclick = () => {
          wMethodInp.value = b.dataset.wMethod;
          $('uPageBody').querySelectorAll('[data-w-method]').forEach((card) => {
            const active = card === b;
            card.classList.toggle('active', active);
            const mark = card.querySelector('.ln-seg-accent');
            if (active && !mark) card.insertAdjacentHTML('beforeend', '<span class="ln-seg-accent">✓</span>');
            if (!active && mark) mark.remove();
          });
        };
      });
    }

    const wBtn = $('btnReqWithdraw');
    if (wBtn) {
      wBtn.onclick = () => {
        try {
          requestAffiliateWithdrawal(
            aff.id,
            {
              method: $('wMethod').value,
              amount: $('wAmount').value,
              accountHolder: $('wHolder').value,
              accountNumber: $('wNumber').value,
            },
            user.uid
          );
          showToast('Withdrawal request submitted', 'success');
          draw();
        } catch (err) {
          showToast(err.message, 'error');
        }
      };
    }

    const saveProfBtn = $('btnSaveAffProf');
    if (saveProfBtn) {
      saveProfBtn.onclick = () => {
        try {
          updateAffiliateProfile(
            aff.id,
            {
              name: $('affProfName').value,
              phone: $('affProfPhone').value,
              socialLink: $('affProfSocial').value,
              promotionMedium: $('affProfMedium').value,
              marketingPlan: $('affProfBio').value,
              bio: $('affProfBio').value,
            },
            user.uid
          );
          showToast('Affiliate profile saved', 'success');
          draw();
        } catch (err) {
          showToast(err.message, 'error');
        }
      };
    }
  };
  draw();
}

function openAccountPage() {
  openOverlay('My Account', 'account');
  const user = getActiveUser('user');
  if (user) {
    const orders = listOrdersForUser(user);
    const aff = getAffiliateByUserId(user.uid);
    const menuItems = getActiveNavigation('accountMenu', user.role);
    const updateInfo = checkUpdateStatus();
    const displayName = getDisplayUserName(user);
    const createdHrs = Math.floor(Math.max(0, Date.now() - (Date.parse(user.createdAt || '') || Date.now())) / 3600000);

    $('uPageBody').innerHTML = `
      <div class="ln-card" style="background:linear-gradient(135deg,#171316,#4B121D);border:1px solid rgba(201,164,92,0.34);color:#F5F1E8;margin-bottom:14px;">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;">
          <div>
            <div style="font-size:11px;color:var(--gold);font-weight:700;letter-spacing:0.1em;">LUXE NEXUS MEMBER · ACCOUNT AGE ${createdHrs}H</div>
            <h2 style="font-size:22px;margin:4px 0;">${escapeHtml(displayName)}</h2>
            <div style="font-size:12px;color:#DFD8CE;">
              ${escapeHtml(user.name)}${user.username ? ` (@${escapeHtml(user.username)})` : ''} · ${escapeHtml(user.email)} ${user.emailVerified ? '✓' : '(Unverified)'} · ${escapeHtml(user.phone || 'No phone')} ${user.phoneVerified ? '✓' : '(Unverified)'}
            </div>
          </div>
          <div style="text-align:right;">
            <div style="font-size:11px;color:#DFD8CE;">Orders: <strong>${orders.length}</strong></div>
            <div style="font-size:11px;color:#DFD8CE;">Affiliate: <strong>${aff ? `${escapeHtml(aff.status)}${aff.level ? ` · ${escapeHtml(String(aff.level).toUpperCase())}` : ''}` : 'Not joined'}</strong></div>
          </div>
        </div>
      </div>

      <div class="ln-card" style="margin-bottom:14px;">
        <div style="font-size:12px;font-weight:700;color:var(--gold);letter-spacing:0.06em;text-transform:uppercase;margin-bottom:8px;">Complete Profile &amp; Contact Verification</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;">
          <div class="ln-field" style="margin-bottom:0;"><label>Username (Shown in App)</label><input id="profUsername" class="ln-input" value="${escapeAttr(user.username || '')}" placeholder="e.g. LN_Saikat" /></div>
          <div class="ln-field" style="margin-bottom:0;"><label>Full Name *</label><input id="profFullName" class="ln-input" value="${escapeAttr(user.name || '')}" /></div>
          <div class="ln-field" style="margin-bottom:0;"><label>Mobile Number *</label><input id="profPhone" class="ln-input" value="${escapeAttr(user.phone || '')}" placeholder="01XXXXXXXXX" /></div>
          <div class="ln-field" style="margin-bottom:0;"><label>Age (Years, Min 18 for Affiliate) *</label><input id="profAge" type="number" min="10" max="120" class="ln-input" value="${escapeAttr(user.age ?? '')}" placeholder="e.g. 24" /></div>
          <div class="ln-field" style="margin-bottom:0;"><label>City / District *</label><input id="profCity" class="ln-input" value="${escapeAttr(user.city || '')}" placeholder="e.g. Dhaka" /></div>
          <div class="ln-field" style="margin-bottom:0;"><label>Social Media / Website URL</label><input id="profSocial" class="ln-input" value="${escapeAttr(user.socialUrl || '')}" placeholder="https://..." /></div>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:12px;">
          <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="btnSaveProfileIdentity">Save Complete Profile</button>
          <button type="button" class="ln-btn ln-btn-sm ${user.emailVerified ? 'ln-btn-outline' : 'ln-btn-gold'}" id="btnVerifyEmail" ${user.emailVerified ? 'disabled' : ''}>
            ${user.emailVerified ? '✓ Email Verified' : 'Verify Email Now'}
          </button>
          <button type="button" class="ln-btn ln-btn-sm ${user.phoneVerified ? 'ln-btn-outline' : 'ln-btn-gold'}" id="btnVerifyPhone" ${user.phoneVerified ? 'disabled' : ''}>
            ${user.phoneVerified ? '✓ Mobile Verified' : 'Verify Mobile Now'}
          </button>
        </div>
      </div>

      <div class="ln-card" style="margin-bottom:14px;padding:6px 14px;">
        ${menuItems
          .map(
            (m) => `
          <button type="button" class="u-drawer-link" data-acc-nav="${escapeAttr(m.id)}" style="border-bottom:1px solid var(--border);border-radius:0;">
            <span>${escapeHtml(m.icon || '•')}</span>
            <span style="flex:1;">${escapeHtml(m.label)}</span>
            <span style="color:var(--text-muted);">›</span>
          </button>`
          )
          .join('')}
      </div>

      <div class="ln-card" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:14px;">
        <div>
          <strong>App Version v${escapeHtml(updateInfo.currentVersion)}</strong>
          <div style="font-size:12px;color:var(--text-muted);">${updateInfo.hasUpdate ? `Update v${escapeHtml(updateInfo.latestVersion)} available` : 'Up to date'}</div>
        </div>
        <div style="display:flex;gap:8px;">
          ${updateInfo.hasUpdate ? `<button type="button" class="ln-btn ln-btn-gold ln-btn-sm" id="btnCheckUpd">Install Update</button>` : ''}
          <button type="button" class="ln-btn ln-btn-danger ln-btn-sm" id="btnUserLogout">Logout</button>
        </div>
      </div>
    `;

    $('btnSaveProfileIdentity').onclick = () => {
      try {
        const nextName = $('profFullName').value.trim();
        const nextUsername = $('profUsername').value.trim();
        const nextPhone = $('profPhone').value.trim();
        const nextAge = $('profAge').value ? Number($('profAge').value) : null;
        const nextCity = $('profCity').value.trim();
        const nextSocial = $('profSocial').value.trim();
        if (!nextName || nextName.length < 2) {
          showToast('Full name must be at least 2 characters.', 'error');
          return;
        }
        updateAccountProfile(user.uid, {
          name: nextName,
          username: nextUsername,
          phone: nextPhone,
          age: nextAge,
          city: nextCity,
          socialUrl: nextSocial,
        });
        renderBrandAndNav();
        showToast('Profile saved', 'success');
        openAccountPage();
      } catch (err) {
        showToast(err.message, 'error');
      }
    };
    $('btnVerifyEmail').onclick = () => {
      try {
        verifyAccountContact(user.uid, 'email');
        showToast('Email address verified', 'success');
        openAccountPage();
      } catch (err) {
        showToast(err.message, 'error');
      }
    };
    $('btnVerifyPhone').onclick = () => {
      try {
        const currentPhoneInput = $('profPhone').value.trim();
        if (currentPhoneInput && currentPhoneInput !== (user.phone || '')) {
          updateAccountProfile(user.uid, { phone: currentPhoneInput });
        }
        verifyAccountContact(user.uid, 'phone');
        showToast('Mobile number verified', 'success');
        openAccountPage();
      } catch (err) {
        showToast(err.message, 'error');
      }
    };
    $('uPageBody').querySelectorAll('[data-acc-nav]').forEach((b) => {
      b.onclick = () => navigateTo(b.dataset.accNav);
    });
    const updBtn = $('btnCheckUpd');
    if (updBtn) {
      updBtn.onclick = () =>
        renderUpdateModal({
          updateStatus: updateInfo,
          onUpdateNow: async (rel) => {
            await applyAppUpdate(rel);
            showToast(`Updated to v${rel.version}`, 'success');
            openAccountPage();
          },
          onSkip: (v) => skipAppUpdate(v),
          onLater: () => {},
        });
    }
    $('btnUserLogout').onclick = () => {
      logoutAccount('user');
      updateBadges();
      renderBrandAndNav();
      showToast('Signed out', 'success');
      openAccountPage();
    };
    return;
  }

  // Premium Login / Signup / Forgot Password Screen
  const drawAuth = () => {
    const isSignup = state.authMode === 'signup';
    const isForgot = state.authMode === 'forgot';
    $('uPageBody').innerHTML = `
      <div class="ln-card" style="max-width:460px;margin:0 auto;">
        <div style="display:flex;gap:8px;margin-bottom:16px;">
          <button type="button" class="ln-btn ln-btn-sm ${state.authMode === 'login' ? '' : 'ln-btn-outline'}" id="tabAuthLogin" style="flex:1;">Sign In</button>
          <button type="button" class="ln-btn ln-btn-sm ${state.authMode === 'signup' ? '' : 'ln-btn-outline'}" id="tabAuthSignup" style="flex:1;">Create Account</button>
        </div>

        ${
          isForgot
            ? `
          <h3 style="margin-bottom:10px;">Reset Password</h3>
          <div class="ln-field"><label>Registered Email or Phone *</label><input id="rstContact" class="ln-input" placeholder="you@example.com or 01XXXXXXXXX" /></div>
          <div class="ln-field"><label>New Password *</label><input id="rstPass" type="password" class="ln-input" /></div>
          <div class="ln-field"><label>Confirm Password *</label><input id="rstConfirm" type="password" class="ln-input" /></div>
          <button type="button" class="ln-btn ln-btn-gold" id="btnDoReset" style="width:100%;">Update Password</button>
          <button type="button" class="ln-btn ln-btn-outline" id="btnBackLogin" style="width:100%;margin-top:8px;">Back to Sign In</button>
        `
            : `
          ${isSignup ? `<div class="ln-field"><label>Full Name *</label><input id="authName" class="ln-input" placeholder="Your full name" /></div>` : ''}
          ${isSignup ? `<div class="ln-field"><label>Username (Optional)</label><input id="authUsername" class="ln-input" placeholder="e.g. LN_Saikat" /></div>` : ''}
          <div class="ln-field"><label>Email Address *</label><input id="authEmail" type="email" class="ln-input" placeholder="you@example.com" /></div>
          ${isSignup ? `<div class="ln-field"><label>Phone Number *</label><input id="authPhone" type="tel" class="ln-input" placeholder="01XXXXXXXXX" /></div>` : ''}
          <div class="ln-field">
            <label>Password *</label>
            <div style="display:flex;gap:6px;">
              <input id="authPass" type="password" class="ln-input" placeholder="Minimum 6 characters" />
              <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="btnTogglePassVis">Show</button>
            </div>
            ${isSignup ? `<div id="authStrengthLbl" style="font-size:11px;color:var(--text-muted);margin-top:4px;"></div>` : ''}
          </div>
          ${isSignup ? `<div class="ln-field"><label>Confirm Password *</label><input id="authConfirmPass" type="password" class="ln-input" placeholder="Re-enter password" /></div>` : ''}
          <label style="display:flex;align-items:center;gap:8px;font-size:12px;margin:10px 0 14px;">
            <input type="checkbox" id="authRemember" checked /> Remember me on this device
          </label>
          <button type="button" class="ln-btn ln-btn-gold" id="btnAuthSubmit" style="width:100%;">${isSignup ? 'Create Account' : 'Sign In'}</button>
          ${!isSignup ? `<button type="button" class="ln-btn ln-btn-outline" id="btnForgotPass" style="width:100%;margin-top:8px;">Forgot Password?</button>` : ''}
          <div style="border-top:1px solid var(--border);margin-top:16px;padding-top:14px;">
            <button type="button" class="ln-btn ln-btn-outline" id="btnGoogleFuture" style="width:100%;">Continue with Google (Firebase Auth Ready)</button>
          </div>
        `
        }
      </div>
    `;

    $('tabAuthLogin').onclick = () => { state.authMode = 'login'; drawAuth(); };
    $('tabAuthSignup').onclick = () => { state.authMode = 'signup'; drawAuth(); };

    if (isForgot) {
      $('btnBackLogin').onclick = () => { state.authMode = 'login'; drawAuth(); };
      $('btnDoReset').onclick = async () => {
        try {
          await resetPassword({ contact: $('rstContact').value, newPassword: $('rstPass').value, confirmPassword: $('rstConfirm').value });
          showToast('Password updated. You can now sign in.', 'success');
          state.authMode = 'login';
          drawAuth();
        } catch (err) {
          showToast(err.message, 'error');
        }
      };
      return;
    }

    $('btnTogglePassVis').onclick = () => {
      const inp = $('authPass');
      const hidden = inp.type === 'password';
      inp.type = hidden ? 'text' : 'password';
      $('btnTogglePassVis').textContent = hidden ? 'Hide' : 'Show';
    };
    if (isSignup) {
      $('authPass').oninput = () => {
        const s = evaluatePasswordStrength($('authPass').value);
        $('authStrengthLbl').textContent = `Password strength: ${s.label}`;
      };
    } else {
      $('btnForgotPass').onclick = () => { state.authMode = 'forgot'; drawAuth(); };
    }
    $('btnGoogleFuture').onclick = () => {
      const desc = appServices.auth.prepareGoogleOAuthDescriptor();
      showToast(desc.message);
    };
    $('btnAuthSubmit').onclick = async () => {
      try {
        if (isSignup) {
          await signupAccount({
            name: $('authName').value,
            username: $('authUsername')?.value || '',
            email: $('authEmail').value,
            phone: $('authPhone').value,
            password: $('authPass').value,
            confirmPassword: $('authConfirmPass').value,
          });
        }
        await loginAccount({
          email: $('authEmail').value,
          password: $('authPass').value,
          appScope: 'user',
          rememberMe: $('authRemember').checked,
        });
        updateBadges();
        renderBrandAndNav();
        showToast(isSignup ? 'Account created & signed in' : 'Signed in successfully', 'success');
        if (state.pendingBuyNowCheckout && state.checkoutMode === 'buy_now' && state.buyNowItem) {
          state.pendingBuyNowCheckout = false;
          openCheckoutPage();
        } else {
          openAccountPage();
        }
      } catch (err) {
        showToast(err.message, 'error');
      }
    };
  };
  drawAuth();
}

function openAccountSettingsPage(section) {
  const user = getActiveUser('user');
  const prefs = getUserInternationalPrefs();
  openOverlay(section === 'addresses' ? 'Address Book' : section === 'payments' ? 'Payment Methods' : 'International Settings', 'intl');

  if (section === 'addresses') {
    if (!user) return openAccountPage();
    const addresses = user.addresses || [];
    $('uPageBody').innerHTML = `
      <div class="ln-card" style="margin-bottom:14px;">
        <h3 style="margin-bottom:10px;">Add Shipping Address</h3>
        <div class="ln-field"><label>Label / Recipient Name *</label><input id="addrName" class="ln-input" value="${escapeAttr(user.name)}" /></div>
        <div class="ln-field"><label>Phone *</label><input id="addrPhone" class="ln-input" value="${escapeAttr(user.phone || '')}" /></div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
          <div class="ln-field"><label>District *</label><input id="addrDist" class="ln-input" placeholder="Dhaka" /></div>
          <div class="ln-field"><label>Upazila *</label><input id="addrUpz" class="ln-input" placeholder="Banani" /></div>
        </div>
        <div class="ln-field"><label>Full Address *</label><textarea id="addrFull" class="ln-textarea"></textarea></div>
        <button type="button" class="ln-btn" id="btnSaveAddr">Save Address</button>
      </div>
      <div class="ln-card">
        <h3 style="margin-bottom:10px;">Saved Addresses</h3>
        ${addresses.length ? addresses.map((a, idx) => `<div style="padding:10px 0;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;gap:10px;"><div><strong>${escapeHtml(a.name)}</strong> · ${escapeHtml(a.phone)}<div style="font-size:12px;color:var(--text-muted);">${escapeHtml(a.address)}, ${escapeHtml(a.upazila)}, ${escapeHtml(a.district)}</div></div><button type="button" class="ln-btn ln-btn-danger ln-btn-sm" data-del-addr="${idx}">Remove</button></div>`).join('') : '<p style="color:var(--text-muted);font-size:13px;">No saved addresses yet.</p>'}
      </div>
    `;
    $('btnSaveAddr').onclick = () => {
      const next = [
        { name: $('addrName').value.trim(), phone: $('addrPhone').value.trim(), district: $('addrDist').value.trim(), upazila: $('addrUpz').value.trim(), address: $('addrFull').value.trim() },
        ...addresses,
      ];
      updateAccountProfile(user.uid, { addresses: next });
      showToast('Address saved', 'success');
      openAccountSettingsPage('addresses');
    };
    $('uPageBody').querySelectorAll('[data-del-addr]').forEach((b) => {
      b.onclick = () => {
        const next = addresses.filter((_, i) => i !== Number(b.dataset.delAddr));
        updateAccountProfile(user.uid, { addresses: next });
        openAccountSettingsPage('addresses');
      };
    });
    return;
  }

  if (section === 'payments') {
    const methods = getAvailablePaymentMethods();
    $('uPageBody').innerHTML = `
      <div class="ln-card">
        <h3 style="margin-bottom:10px;">Available Payment Methods</h3>
        ${methods.map((m) => `<div style="padding:10px 0;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;"><div><strong>${escapeHtml(m.name)}</strong><div style="font-size:12px;color:var(--text-muted);">Region: ${escapeHtml(m.region)}</div></div><span class="ln-status ${m.enabled ? 'ln-status-success' : 'ln-status-muted'}">${m.enabled ? 'Active' : 'Coming Soon / Admin Disabled'}</span></div>`).join('')}
      </div>
    `;
    return;
  }

  const langs = [
    { val: 'en', title: 'English', sub: 'International' },
    { val: 'bn', title: 'বাংলা (Bengali)', sub: 'Bangladesh' },
  ];
  const countries = [
    { val: 'Bangladesh', sub: 'South Asia' },
    { val: 'United States', sub: 'North America' },
    { val: 'United Kingdom', sub: 'Europe' },
    { val: 'European Union', sub: 'Eurozone' },
  ];
  const currencies = [
    { val: 'BDT', sym: '৳', sub: 'Bangladeshi Taka' },
    { val: 'USD', sym: '$', sub: 'US Dollar' },
    { val: 'EUR', sym: '€', sub: 'Euro' },
    { val: 'GBP', sym: '£', sub: 'British Pound' },
  ];

  $('uPageBody').innerHTML = `
    <div class="ln-card" style="max-width:600px;margin:0 auto;">
      <div style="font-size:11px;font-weight:700;letter-spacing:0.1em;color:var(--gold);text-transform:uppercase;margin-bottom:4px;">PREFERENCES</div>
      <h3 style="font-family:var(--font-serif);font-size:20px;margin-bottom:16px;">Language, Country &amp; Currency</h3>

      <input type="hidden" id="intlLang" value="${escapeAttr(prefs.language)}" />
      <input type="hidden" id="intlCountry" value="${escapeAttr(prefs.country)}" />
      <input type="hidden" id="intlCurrency" value="${escapeAttr(prefs.currency)}" />

      <div class="ln-field">
        <label>Display Language</label>
        <div class="ln-seg-grid">
          ${langs
            .map(
              (l) => `
            <button type="button" class="ln-seg-card ${prefs.language === l.val ? 'active' : ''}" data-intl-lang="${escapeAttr(l.val)}">
              <div><strong>${escapeHtml(l.title)}</strong><small>${escapeHtml(l.sub)}</small></div>
              ${prefs.language === l.val ? '<span class="ln-seg-accent">✓</span>' : ''}
            </button>`
            )
            .join('')}
        </div>
      </div>

      <div class="ln-field">
        <label>Country / Region</label>
        <div class="ln-seg-grid">
          ${countries
            .map(
              (c) => `
            <button type="button" class="ln-seg-card ${prefs.country === c.val ? 'active' : ''}" data-intl-country="${escapeAttr(c.val)}">
              <div><strong>${escapeHtml(c.val)}</strong><small>${escapeHtml(c.sub)}</small></div>
              ${prefs.country === c.val ? '<span class="ln-seg-accent">✓</span>' : ''}
            </button>`
            )
            .join('')}
        </div>
      </div>

      <div class="ln-field">
        <label>Display Currency</label>
        <div class="ln-seg-grid">
          ${currencies
            .map(
              (cur) => `
            <button type="button" class="ln-seg-card ${prefs.currency === cur.val ? 'active' : ''}" data-intl-curr="${escapeAttr(cur.val)}">
              <div><strong>${escapeHtml(cur.val)} (${escapeHtml(cur.sym)})</strong><small>${escapeHtml(cur.sub)}</small></div>
              ${prefs.currency === cur.val ? '<span class="ln-seg-accent">✓</span>' : ''}
            </button>`
            )
            .join('')}
        </div>
      </div>

      <button type="button" class="ln-btn ln-btn-gold" id="btnSaveIntl" style="width:100%;margin-top:6px;">Save International Preferences</button>
    </div>
  `;

  const bindSegGroup = (attr, inputId) => {
    $('uPageBody').querySelectorAll(`[${attr}]`).forEach((b) => {
      b.onclick = () => {
        $(inputId).value = b.getAttribute(attr);
        $('uPageBody').querySelectorAll(`[${attr}]`).forEach((card) => {
          const active = card === b;
          card.classList.toggle('active', active);
          const mark = card.querySelector('.ln-seg-accent');
          if (active && !mark) card.insertAdjacentHTML('beforeend', '<span class="ln-seg-accent">✓</span>');
          if (!active && mark) mark.remove();
        });
      };
    });
  };
  bindSegGroup('data-intl-lang', 'intlLang');
  bindSegGroup('data-intl-country', 'intlCountry');
  bindSegGroup('data-intl-curr', 'intlCurrency');

  $('btnSaveIntl').onclick = () => {
    setUserInternationalPrefs({
      language: $('intlLang').value,
      country: $('intlCountry').value,
      currency: $('intlCurrency').value,
    });
    renderBrandAndNav();
    renderHomeSections();
    showToast('International preferences updated', 'success');
  };
}

function openWishlistPage() {
  openOverlay('Saved Wishlist', 'wishlist');
  const prods = listPublishedProducts().filter((p) => state.wishlist.includes(p.id));
  $('uPageBody').innerHTML = prods.length
    ? renderProductCards(prods)
    : `<div class="ln-empty"><h4>Your wishlist is empty</h4><p style="font-size:13px;">Save items while browsing to review them later.</p></div>`;
  bindProductCardHandlers($('uPageBody'));
}

function openComparePage() {
  openOverlay('Product Comparison', 'compare');
  const prods = listPublishedProducts().filter((p) => state.compareIds.includes(p.id));
  if (!prods.length) {
    $('uPageBody').innerHTML = `<div class="ln-empty"><h4>No products selected for comparison</h4><p style="font-size:13px;">Open any product and click Compare.</p></div>`;
    return;
  }
  $('uPageBody').innerHTML = `
    <div class="ln-card ln-table-wrap">
      <table class="ln-table">
        <thead><tr><th>Attribute</th>${prods.map((p) => `<th>${escapeHtml(p.name)}</th>`).join('')}</tr></thead>
        <tbody>
          <tr><td>Brand</td>${prods.map((p) => `<td>${escapeHtml(p.brand || '—')}</td>`).join('')}</tr>
          <tr><td>Price</td>${prods.map((p) => `<td class="tabular"><strong>${money(p.offerPrice || p.price)}</strong></td>`).join('')}</tr>
          <tr><td>Rating</td>${prods.map((p) => `<td>★ ${escapeHtml(p.rating)}</td>`).join('')}</tr>
          <tr><td>Material</td>${prods.map((p) => `<td>${escapeHtml(p.material || '—')}</td>`).join('')}</tr>
          <tr><td>Warranty</td>${prods.map((p) => `<td>${escapeHtml(p.warranty || '—')}</td>`).join('')}</tr>
          <tr><td>Action</td>${prods.map((p) => `<td><button type="button" class="ln-btn ln-btn-sm" data-open-prod="${escapeAttr(p.id)}">View</button></td>`).join('')}</tr>
        </tbody>
      </table>
    </div>
  `;
  bindProductCardHandlers($('uPageBody'));
}

function openSupportPage() {
  const cfg = getPlatformConfig();
  openOverlay('Help Center & Policies', 'support');
  $('uPageBody').innerHTML = `
    <div class="ln-card" style="margin-bottom:14px;">
      <h3 style="margin-bottom:6px;">Concierge Support</h3>
      <p style="font-size:13px;color:var(--text-muted);margin-bottom:12px;">${escapeHtml(cfg.pages?.supportText || '')} (${escapeHtml(cfg.support)})</p>
      <div class="ln-field"><label>Contact Email or Phone *</label><input id="supContact" class="ln-input" placeholder="you@example.com" /></div>
      <div class="ln-field"><label>Message *</label><textarea id="supMsg" class="ln-textarea" placeholder="Describe how we can assist..."></textarea></div>
      <button type="button" class="ln-btn" id="btnSendSup">Submit Support Request</button>
    </div>
    <div class="ln-card">
      <h3 style="margin-bottom:8px;">Return Policy, Privacy &amp; Terms</h3>
      <p style="font-size:13px;margin-bottom:8px;"><strong>Returns:</strong> ${escapeHtml(cfg.pages?.returns || '')}</p>
      <p style="font-size:13px;margin-bottom:8px;"><strong>Privacy:</strong> ${escapeHtml(cfg.pages?.privacy || '')}</p>
      <p style="font-size:13px;"><strong>Terms:</strong> ${escapeHtml(cfg.pages?.terms || '')}</p>
    </div>
  `;
  $('btnSendSup').onclick = () => {
    const c = $('supContact').value.trim();
    const m = $('supMsg').value.trim();
    if (!c || !m) {
      showToast('Please provide your contact and message', 'error');
      return;
    }
    const tickets = appServices.storage.getCollection('supportTickets', []);
    tickets.unshift({ id: `TKT-${Date.now()}`, contact: c, message: m, createdAt: new Date().toISOString() });
    appServices.storage.setCollection('supportTickets', tickets);
    $('supMsg').value = '';
    showToast('Support message recorded', 'success');
  };
}

function toggleDrawer(force) {
  const d = $('uDrawer');
  const b = $('uDrawerBackdrop');
  const show = force === undefined ? !d.classList.contains('show') : force;
  d.classList.toggle('show', show);
  b.classList.toggle('show', show);
}

function init() {
  ensureEcosystemSeeded();
  if (localStorage.getItem('ln_theme_variant') === 'light') document.body.classList.add('light-atelier');
  initLuxurySelectObserver();

  captureIncomingReferral();
  renderBrandAndNav();
  populateFilterOptions();
  renderHomeSections();
  updateBadges();

  // Re-resolve desktop vs mobile hero layout/image when crossing breakpoint
  window.addEventListener('resize', () => {
    const isMob = window.innerWidth < 760;
    if (isMob !== state.lastIsMobile) {
      state.lastIsMobile = isMob;
      if (!state.currentPage) renderHomeSections();
    }
  });

  // Header & Drawer bindings
  $('btnOpenDrawer').onclick = () => toggleDrawer(true);
  $('btnCloseDrawer').onclick = () => toggleDrawer(false);
  $('uDrawerBackdrop').onclick = () => toggleDrawer(false);
  $('btnDrawerAccount').onclick = () => { toggleDrawer(false); navigateTo('account'); };
  if ($('btnHeaderUser')) $('btnHeaderUser').onclick = () => navigateTo('account');
  $('btnUserTheme').onclick = () => {
    document.body.classList.toggle('light-atelier');
    localStorage.setItem('ln_theme_variant', document.body.classList.contains('light-atelier') ? 'light' : 'dark');
    applyDesignTokensToDocument(getPlatformConfig());
  };
  $('btnHeaderCart').onclick = () => navigateTo('cart');
  $('btnUserNotifs').onclick = () => {
    const user = getActiveUser('user');
    renderNotificationModal({ audience: 'user', userId: user?.uid || '', onUpdated: updateBadges });
  };
  $('btnOverlayBack').onclick = closeOverlay;
  $('btnOverlayClose').onclick = closeOverlay;
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && $('uVariantModal')?.classList.contains('show')) {
      closeVariantPopup();
    }
  });

  // Search & Filters
  $('btnToggleFilters').onclick = () => {
    const p = $('uFilterPanel');
    p.style.display = p.style.display === 'none' ? 'block' : 'none';
  };
  $('uSearchInput').oninput = () => { state.filters.search = $('uSearchInput').value; renderHomeSections(); };
  $('fCategory').onchange = () => { state.filters.category = $('fCategory').value; renderHomeSections(); };
  $('fBrand').onchange = () => { state.filters.brand = $('fBrand').value; renderHomeSections(); };
  $('fMinPrice').oninput = () => { state.filters.minPrice = $('fMinPrice').value; renderHomeSections(); };
  $('fMaxPrice').oninput = () => { state.filters.maxPrice = $('fMaxPrice').value; renderHomeSections(); };
  $('fSort').onchange = () => { state.filters.sort = $('fSort').value; renderHomeSections(); };
  $('fInStock').onchange = () => { state.filters.inStockOnly = $('fInStock').checked; renderHomeSections(); };

  // Live Cross-App Synchronization via BroadcastChannel
  appServices.settings.subscribe(() => { renderBrandAndNav(); renderHomeSections(); });
  appServices.products.subscribe(() => { populateFilterOptions(); renderHomeSections(); });
  appServices.categories.subscribe(() => { populateFilterOptions(); renderHomeSections(); });
  appServices.notifications.subscribe(updateBadges);

  // Check App Updates & Announcements
  const upd = checkUpdateStatus();
  if (upd.shouldPrompt) {
    renderUpdateModal({
      updateStatus: upd,
      onUpdateNow: async (rel) => {
        await applyAppUpdate(rel);
        showToast(`Updated to v${rel.version}`, 'success');
      },
      onSkip: (v) => skipAppUpdate(v),
      onLater: () => {},
    });
  } else {
    const anns = getActiveAnnouncements('user');
    if (anns.length && !sessionStorage.getItem(`ln_ann_${anns[0].id}`)) {
      sessionStorage.setItem(`ln_ann_${anns[0].id}`, '1');
      renderAnnouncementModal(anns[0], (action) => {
        if (action && action.startsWith('page:')) navigateTo(action.slice(5));
      });
    }
  }
}

init();
