/**
 * LUXE NEXUS Admin Hero Banner / Slider Advanced Control Module
 * Manages multi-slide hero banners, drag/button reordering, desktop/mobile imagery,
 * preset & custom sizing/layout, 6 transition animations, auto-slide behavior,
 * live desktop/mobile preview, and instant real-time storefront synchronization.
 */

import { getPlatformConfig } from '../services/settings-service.js';
import {
  HEIGHT_PRESETS,
  DESKTOP_SIZE_PRESETS,
  MOBILE_SIZE_PRESETS,
  normalizeHeroSlide,
  normalizeHeroSliderConfig,
  reorderHeroSlides,
  createEmptyHeroSlide,
  saveHeroBannerConfig,
  resetHeroBannerConfig,
} from '../services/hero-banner-service.js';
import { mountHeroSlider } from '../shared/hero-slider-engine.js';
import { escapeHtml, escapeAttr, sanitizeUrl } from '../shared/utilities.js';
import { showToast, openConfirmDialog } from '../shared/shared-components.js';

const SAMPLE_BANNER_IMAGES = [
  { label: 'Atelier Lookbook', url: '/src/assets/images/hero_luxe_collection_1795240520616.jpg' },
  { label: 'Chronograph', url: '/src/assets/images/prod_chronograph_watch_1795240520418.jpg' },
  { label: 'Leather Tote', url: '/src/assets/images/prod_leather_bag_1795240519945.jpg' },
  { label: 'Studio Audio', url: '/src/assets/images/prod_studio_audio_1795240519980.jpg' },
];

const QUICK_LINKS = [
  { label: 'All Products', value: 'category:all' },
  { label: 'Fashion', value: 'category:Fashion' },
  { label: 'Watches', value: 'category:Watches' },
  { label: 'Leather Goods', value: 'category:Leather' },
  { label: 'Audio', value: 'category:Audio' },
  { label: 'Categories Page', value: 'page:categories' },
  { label: 'Affiliate Program', value: 'page:affiliate' },
];

let activePreviewSlider = null;

function createDraftFromConfig() {
  const cfg = getPlatformConfig();
  const slides = (cfg.bannerSlides || []).map((s, idx) => normalizeHeroSlide(s, idx));
  const heroSlider = normalizeHeroSliderConfig(cfg.heroSlider || {});
  return {
    slides,
    heroSlider,
    selectedIdx: 0,
    previewDevice: 'desktop',
    previewSlideIdx: 0,
    showBulkAdder: false,
  };
}

export function renderHeroBannerManager(host, actor) {
  const draft = createDraftFromConfig();
  let dragSrcIdx = null;

  const unmountPreview = () => {
    if (activePreviewSlider && typeof activePreviewSlider.destroy === 'function') {
      activePreviewSlider.destroy();
      activePreviewSlider = null;
    }
  };

  const renderPreviewOnly = () => {
    unmountPreview();
    const viewport = host.querySelector('#admHeroPreviewViewport');
    const previewBox = host.querySelector('#admHeroPreviewBox');
    if (!viewport || !previewBox) return;

    viewport.classList.toggle('is-mobile', draft.previewDevice === 'mobile');
    const enabledSlides = draft.slides.filter((s) => s.enabled !== false);
    if (!enabledSlides.length) {
      previewBox.innerHTML = `<div class="ln-empty" style="padding:28px;">All slides are disabled. Enable at least one slide to display the Hero Banner on the storefront.</div>`;
      return;
    }

    const safeIdx = Math.max(0, Math.min(draft.previewSlideIdx, enabledSlides.length - 1));
    activePreviewSlider = mountHeroSlider(previewBox, {
      slides: enabledSlides,
      heroSlider: draft.heroSlider,
      viewportWidth: draft.previewDevice === 'mobile' ? 390 : 1280,
      stageId: 'admLiveHeroStage',
      headingTag: 'h2',
      initialIdx: safeIdx,
      onSlideChange: (idx) => {
        draft.previewSlideIdx = idx;
      },
      onSlideLink: (lnk) => {
        showToast(`Preview CTA destination: ${lnk}`);
      },
    });
  };

  const renderSlideListOnly = () => {
    const listHost = host.querySelector('#admHeroSlidesList');
    if (!listHost) return;
    if (!draft.slides.length) {
      listHost.innerHTML = `<div class="ln-empty">No banner slides yet. Click "Add New Banner" or paste multiple URLs below.</div>`;
      return;
    }

    listHost.innerHTML = draft.slides
      .map((s, idx) => {
        const thumb = sanitizeUrl(s.image || s.mobileImage, true);
        const isSel = idx === draft.selectedIdx;
        return `
          <div class="adm-hero-slide-row ${isSel ? 'is-selected' : ''}" draggable="true" data-slide-row="${idx}">
            <span class="adm-hero-drag" title="Drag to reorder" aria-label="Drag handle">⋮⋮</span>
            ${
              thumb
                ? `<img class="adm-hero-thumb" src="${escapeAttr(thumb)}" alt="" referrerpolicy="no-referrer" onerror="this.style.visibility='hidden'" />`
                : `<div class="adm-hero-thumb ln-img-fallback" style="font-size:10px;">No Image</div>`
            }
            <div style="flex:1;min-width:140px;cursor:pointer;" data-hero-select="${idx}">
              <div style="display:flex;align-items:center;gap:6px;">
                <strong style="font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(s.title || `Slide #${idx + 1}`)}</strong>
                ${s.enabled === false ? `<span class="ln-status ln-status-muted" style="font-size:11px;">(Disabled)</span>` : ''}
              </div>
              <div style="font-size:11px;color:var(--text-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                ${escapeHtml(s.subtitle || 'No subtitle')} · ${escapeHtml(s.link || 'category:all')}
              </div>
            </div>
            <div style="display:flex;align-items:center;gap:8px;margin-left:auto;flex-shrink:0;">
              <label style="display:flex;align-items:center;gap:4px;font-size:11px;color:var(--text-muted);cursor:pointer;" title="Enable or disable slide">
                <input type="checkbox" data-hero-toggle="${idx}" ${s.enabled !== false ? 'checked' : ''} />
                On
              </label>
              <div style="display:flex;gap:4px;">
                <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-hero-up="${idx}" ${idx === 0 ? 'disabled' : ''} aria-label="Move slide up">↑</button>
                <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-hero-down="${idx}" ${idx === draft.slides.length - 1 ? 'disabled' : ''} aria-label="Move slide down">↓</button>
                <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-hero-edit="${idx}">Edit</button>
                <button type="button" class="ln-btn ln-btn-danger ln-btn-sm" data-hero-del="${idx}" aria-label="Delete slide">✕</button>
              </div>
            </div>
          </div>
        `;
      })
      .join('');

    listHost.querySelectorAll('[data-slide-row]').forEach((row) => {
      const idx = Number(row.dataset.slideRow);
      row.addEventListener('dragstart', (ev) => {
        dragSrcIdx = idx;
        if (ev.dataTransfer) {
          ev.dataTransfer.effectAllowed = 'move';
          ev.dataTransfer.setData('text/plain', String(idx));
        }
      });
      row.addEventListener('dragover', (ev) => {
        ev.preventDefault();
        row.classList.add('is-drag-over');
      });
      row.addEventListener('dragleave', () => {
        row.classList.remove('is-drag-over');
      });
      row.addEventListener('drop', (ev) => {
        ev.preventDefault();
        row.classList.remove('is-drag-over');
        if (dragSrcIdx === null || dragSrcIdx === idx) return;
        const selectedSlideId = draft.slides[draft.selectedIdx]?.id;
        draft.slides = reorderHeroSlides(draft.slides, dragSrcIdx, idx);
        const nextSel = draft.slides.findIndex((x) => x.id === selectedSlideId);
        if (nextSel >= 0) draft.selectedIdx = nextSel;
        dragSrcIdx = null;
        renderSlideListOnly();
        renderSlideEditorOnly();
        renderPreviewOnly();
      });
    });

    listHost.querySelectorAll('[data-hero-select], [data-hero-edit]').forEach((el) => {
      el.onclick = () => {
        const idx = Number(el.dataset.heroSelect ?? el.dataset.heroEdit);
        draft.selectedIdx = idx;
        const enabledIdx = draft.slides.filter((x) => x.enabled !== false).findIndex((x) => x.id === draft.slides[idx]?.id);
        if (enabledIdx >= 0) draft.previewSlideIdx = enabledIdx;
        renderSlideListOnly();
        renderSlideEditorOnly();
        renderPreviewOnly();
      };
    });

    listHost.querySelectorAll('[data-hero-toggle]').forEach((chk) => {
      chk.onchange = () => {
        const idx = Number(chk.dataset.heroToggle);
        if (!draft.slides[idx]) return;
        draft.slides[idx].enabled = chk.checked;
        renderSlideListOnly();
        if (idx === draft.selectedIdx) {
          const edChk = host.querySelector('#edSlideEnabled');
          if (edChk) edChk.checked = chk.checked;
        }
        renderPreviewOnly();
      };
    });

    listHost.querySelectorAll('[data-hero-up]').forEach((btn) => {
      btn.onclick = () => {
        const idx = Number(btn.dataset.heroUp);
        if (idx <= 0) return;
        const selectedId = draft.slides[draft.selectedIdx]?.id;
        draft.slides = reorderHeroSlides(draft.slides, idx, idx - 1);
        const nextSel = draft.slides.findIndex((x) => x.id === selectedId);
        if (nextSel >= 0) draft.selectedIdx = nextSel;
        renderSlideListOnly();
        renderSlideEditorOnly();
        renderPreviewOnly();
      };
    });

    listHost.querySelectorAll('[data-hero-down]').forEach((btn) => {
      btn.onclick = () => {
        const idx = Number(btn.dataset.heroDown);
        if (idx >= draft.slides.length - 1) return;
        const selectedId = draft.slides[draft.selectedIdx]?.id;
        draft.slides = reorderHeroSlides(draft.slides, idx, idx + 1);
        const nextSel = draft.slides.findIndex((x) => x.id === selectedId);
        if (nextSel >= 0) draft.selectedIdx = nextSel;
        renderSlideListOnly();
        renderSlideEditorOnly();
        renderPreviewOnly();
      };
    });

    listHost.querySelectorAll('[data-hero-del]').forEach((btn) => {
      btn.onclick = () => {
        const idx = Number(btn.dataset.heroDel);
        if (draft.slides.length <= 1) {
          showToast('Keep at least one hero banner slide (you can disable or edit it).', 'error');
          return;
        }
        draft.slides.splice(idx, 1);
        draft.selectedIdx = Math.max(0, Math.min(draft.selectedIdx, draft.slides.length - 1));
        renderSlideListOnly();
        renderSlideEditorOnly();
        renderPreviewOnly();
      };
    });
  };

  const renderSlideEditorOnly = () => {
    const edHost = host.querySelector('#admHeroSlideEditor');
    if (!edHost) return;
    if (!draft.slides.length) {
      edHost.innerHTML = `<div class="ln-empty">Add or select a slide to edit its content and imagery.</div>`;
      return;
    }

    draft.selectedIdx = Math.max(0, Math.min(draft.selectedIdx, draft.slides.length - 1));
    const slide = draft.slides[draft.selectedIdx];
    const deskThumb = sanitizeUrl(slide.image, true);
    const mobThumb = sanitizeUrl(slide.mobileImage, true);

    edHost.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:12px;flex-wrap:wrap;">
        <h3 style="font-size:15px;">Edit Slide #${draft.selectedIdx + 1}</h3>
        <label style="display:flex;align-items:center;gap:6px;font-size:12px;font-weight:600;color:var(--gold);">
          <input type="checkbox" id="edSlideEnabled" ${slide.enabled !== false ? 'checked' : ''} />
          Slide Enabled
        </label>
      </div>

      <div class="ln-field">
        <label>Desktop Banner Image URL *</label>
        <input id="edSlideImg" class="ln-input" value="${escapeAttr(slide.image || '')}" placeholder="https://... or /src/assets/images/..." />
        <div class="adm-hero-seg" style="margin-top:6px;">
          ${SAMPLE_BANNER_IMAGES.map(
            (img) => `<button type="button" data-sample-img="${escapeAttr(img.url)}">${escapeHtml(img.label)}</button>`
          ).join('')}
        </div>
        <div style="margin-top:8px;display:flex;align-items:center;gap:10px;">
          <img id="edSlideImgPreview" src="${escapeAttr(deskThumb)}" alt="Desktop preview" referrerpolicy="no-referrer" style="width:128px;height:66px;object-fit:cover;border-radius:8px;border:1px solid var(--border);display:${deskThumb ? 'block' : 'none'};" />
          <span id="edSlideImgErr" style="font-size:11px;color:var(--text-muted);">${deskThumb ? 'Desktop image loaded' : 'Enter a valid http(s) or local image path'}</span>
        </div>
      </div>

      <div class="ln-field">
        <label>Mobile Banner Image URL (Optional — uses Desktop image if empty)</label>
        <input id="edSlideMobileImg" class="ln-input" value="${escapeAttr(slide.mobileImage || '')}" placeholder="Optional mobile-specific banner URL" />
        ${
          mobThumb
            ? `<div style="margin-top:6px;display:flex;align-items:center;gap:8px;"><img id="edSlideMobPreview" src="${escapeAttr(mobThumb)}" alt="Mobile preview" referrerpolicy="no-referrer" style="width:74px;height:52px;object-fit:cover;border-radius:7px;border:1px solid var(--border);" /><span style="font-size:11px;color:var(--text-muted);">Active below 760px viewport</span></div>`
            : ''
        }
      </div>

      <div class="adm-grid-2">
        <div class="ln-field">
          <label>Subtitle / Eyebrow</label>
          <input id="edSlideSubtitle" class="ln-input" value="${escapeAttr(slide.subtitle || slide.eyebrow || '')}" placeholder="e.g. NEW SEASON ARCHIVE" />
        </div>
        <div class="ln-field">
          <label>Banner Title</label>
          <input id="edSlideTitle" class="ln-input" value="${escapeAttr(slide.title || '')}" placeholder="Headline text" />
        </div>
      </div>

      <div class="ln-field">
        <label>Description</label>
        <textarea id="edSlideDesc" class="ln-textarea" style="min-height:66px;" placeholder="Supporting editorial copy">${escapeHtml(slide.desc || '')}</textarea>
      </div>

      <div class="adm-grid-2">
        <div class="ln-field">
          <label>Button Text (leave blank to hide CTA)</label>
          <input id="edSlideBtn" class="ln-input" value="${escapeAttr(slide.button || '')}" placeholder="e.g. Explore Collection" />
        </div>
        <div class="ln-field">
          <label>Button Link / Action</label>
          <input id="edSlideLink" class="ln-input" value="${escapeAttr(slide.link || 'category:all')}" placeholder="category:all, page:affiliate, or https://..." />
        </div>
      </div>
      <div class="adm-hero-seg" style="margin-top:-4px;">
        ${QUICK_LINKS.map(
          (q) => `<button type="button" data-quick-link="${escapeAttr(q.value)}">${escapeHtml(q.label)}</button>`
        ).join('')}
      </div>
    `;

    const updateSelectedRowText = () => {
      const row = host.querySelector(`[data-slide-row="${draft.selectedIdx}"]`);
      if (!row) return;
      const strong = row.querySelector('strong');
      if (strong) strong.textContent = slide.title || `Slide #${draft.selectedIdx + 1}`;
    };

    const previewImg = edHost.querySelector('#edSlideImgPreview');
    const previewErr = edHost.querySelector('#edSlideImgErr');
    if (previewImg) {
      previewImg.onerror = () => {
        previewImg.style.display = 'none';
        if (previewErr) previewErr.textContent = 'Image preview failed to load — verify URL';
      };
      previewImg.onload = () => {
        previewImg.style.display = 'block';
        if (previewErr) previewErr.textContent = 'Desktop image loaded';
      };
    }

    edHost.querySelector('#edSlideEnabled').onchange = (e) => {
      slide.enabled = e.target.checked;
      renderSlideListOnly();
      renderPreviewOnly();
    };

    edHost.querySelector('#edSlideImg').oninput = (e) => {
      slide.image = sanitizeUrl(e.target.value, true) || e.target.value.trim();
      const thumbEl = host.querySelector(`[data-slide-row="${draft.selectedIdx}"] .adm-hero-thumb`);
      const clean = sanitizeUrl(slide.image, true);
      if (thumbEl && thumbEl.tagName === 'IMG' && clean) {
        thumbEl.style.visibility = 'visible';
        thumbEl.src = clean;
      }
      if (previewImg) {
        if (clean) {
          previewImg.src = clean;
          previewImg.style.display = 'block';
        } else {
          previewImg.style.display = 'none';
          if (previewErr) previewErr.textContent = 'Enter a valid http(s) or local image path';
        }
      }
      renderPreviewOnly();
    };

    edHost.querySelector('#edSlideMobileImg').oninput = (e) => {
      slide.mobileImage = sanitizeUrl(e.target.value, true) || e.target.value.trim();
      renderPreviewOnly();
    };

    edHost.querySelector('#edSlideSubtitle').oninput = (e) => {
      slide.subtitle = e.target.value;
      slide.eyebrow = e.target.value;
      renderPreviewOnly();
    };

    edHost.querySelector('#edSlideTitle').oninput = (e) => {
      slide.title = e.target.value;
      updateSelectedRowText();
      renderPreviewOnly();
    };

    edHost.querySelector('#edSlideDesc').oninput = (e) => {
      slide.desc = e.target.value;
      renderPreviewOnly();
    };

    edHost.querySelector('#edSlideBtn').oninput = (e) => {
      slide.button = e.target.value;
      renderPreviewOnly();
    };

    edHost.querySelector('#edSlideLink').oninput = (e) => {
      slide.link = e.target.value;
      renderPreviewOnly();
    };

    edHost.querySelectorAll('[data-sample-img]').forEach((btn) => {
      btn.onclick = () => {
        const url = btn.dataset.sampleImg;
        edHost.querySelector('#edSlideImg').value = url;
        slide.image = url;
        renderSlideListOnly();
        renderSlideEditorOnly();
        renderPreviewOnly();
      };
    });

    edHost.querySelectorAll('[data-quick-link]').forEach((btn) => {
      btn.onclick = () => {
        const lnk = btn.dataset.quickLink;
        edHost.querySelector('#edSlideLink').value = lnk;
        slide.link = lnk;
        renderSlideListOnly();
        renderPreviewOnly();
      };
    });
  };

  const renderAll = () => {
    const hs = draft.heroSlider;
    host.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:16px;flex-wrap:wrap;">
        <div>
          <h3 style="font-family:var(--font-serif);font-size:21px;color:var(--gold);">Hero Banner / Slider Control</h3>
          <p style="font-size:12px;color:var(--text-muted);margin-top:2px;">Control slides, drag order, responsive size &amp; aspect ratio, animations, and auto-slide synced live to the User App.</p>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <button type="button" class="ln-btn ln-btn-outline" id="btnHeroReset">Reset to Default</button>
          <button type="button" class="ln-btn ln-btn-gold" id="btnHeroSave">Save Changes</button>
        </div>
      </div>

      <!-- Live Banner Preview -->
      <div class="ln-card" style="margin-bottom:16px;">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:12px;flex-wrap:wrap;">
          <div>
            <h4 style="font-size:15px;">Live Banner Preview</h4>
            <small style="color:var(--text-muted);font-size:11px;">Uses exact User App Hero Slider renderer, presets, custom metrics, and transitions</small>
          </div>
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
            <div class="adm-hero-seg" style="margin:0;">
              <button type="button" id="btnPreviewPrev" title="Trigger Previous Slide Animation">‹ Prev</button>
              <button type="button" id="btnPreviewNext" title="Trigger Next Slide Animation">Next ›</button>
            </div>
            <div class="adm-hero-seg" style="margin:0;">
              <button type="button" class="${draft.previewDevice === 'desktop' ? 'active' : ''}" data-preview-device="desktop">Desktop</button>
              <button type="button" class="${draft.previewDevice === 'mobile' ? 'active' : ''}" data-preview-device="mobile">Mobile (390px)</button>
            </div>
          </div>
        </div>
        <div class="adm-hero-preview-frame">
          <div id="admHeroPreviewViewport" class="adm-hero-preview-viewport ${draft.previewDevice === 'mobile' ? 'is-mobile' : ''}">
            <div id="admHeroPreviewBox"></div>
          </div>
        </div>
      </div>

      <!-- Banner List + Selected Slide Editor -->
      <div class="adm-hero-layout" style="margin-bottom:16px;">
        <div class="ln-card">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:12px;flex-wrap:wrap;">
            <h4 style="font-size:15px;">Banner Slides (${draft.slides.length})</h4>
            <div style="display:flex;gap:6px;flex-wrap:wrap;">
              <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="btnToggleBulkUrls">${draft.showBulkAdder ? 'Hide Bulk Add' : '+ Multiple URLs'}</button>
              <button type="button" class="ln-btn ln-btn-gold ln-btn-sm" id="btnHeroAddSlide">+ Add New Banner</button>
            </div>
          </div>

          ${
            draft.showBulkAdder
              ? `<div style="padding:12px;border:1px solid rgba(201,164,92,0.35);border-radius:10px;background:var(--surface-2);margin-bottom:12px;">
                  <label style="display:block;font-size:12px;font-weight:600;margin-bottom:6px;">Paste Multiple Banner Image URLs (one URL per line)</label>
                  <textarea id="txtBulkBannerUrls" class="ln-textarea" style="min-height:76px;" placeholder="https://example.com/banner-1.jpg&#10;https://example.com/banner-2.jpg"></textarea>
                  <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:8px;">
                    <button type="button" class="ln-btn ln-btn-gold ln-btn-sm" id="btnApplyBulkUrls">Add Image Slides</button>
                  </div>
                </div>`
              : ''
          }

          <div id="admHeroSlidesList" style="display:grid;gap:8px;"></div>
        </div>

        <div class="ln-card" id="admHeroSlideEditor"></div>
      </div>

      <!-- Size & Layout Settings -->
      <div class="ln-card" style="margin-bottom:16px;">
        <h4 style="font-size:16px;margin-bottom:12px;">Banner Size &amp; Layout Settings</h4>

        <div class="adm-hero-grid-3">
          <div class="ln-field">
            <label>Height Preset</label>
            <div class="adm-hero-seg">
              ${['compact', 'standard', 'editorial', 'showcase', 'custom']
                .map(
                  (p) =>
                    `<button type="button" class="${hs.heightPreset === p ? 'active' : ''}" data-height-preset="${p}">${p[0].toUpperCase() + p.slice(1)}</button>`
                )
                .join('')}
            </div>
          </div>

          <div class="ln-field">
            <label>Desktop Banner Height (px)</label>
            <input id="hsDesktopHeight" type="number" min="120" max="1200" class="ln-input" value="${Number(hs.desktopHeight)}" />
          </div>

          <div class="ln-field">
            <label>Mobile Banner Height (px)</label>
            <input id="hsMobileHeight" type="number" min="120" max="1000" class="ln-input" value="${Number(hs.mobileHeight)}" />
          </div>

          <div class="ln-field">
            <label>Minimum Height (px)</label>
            <input id="hsMinHeight" type="number" min="120" max="900" class="ln-input" value="${Number(hs.minHeight)}" />
          </div>

          <div class="ln-field">
            <label>Maximum Height (px)</label>
            <input id="hsMaxHeight" type="number" min="160" max="1200" class="ln-input" value="${Number(hs.maxHeight)}" />
          </div>

          <div class="ln-field">
            <label>Mobile Size Preset</label>
            <div class="adm-hero-seg">
              ${['compact', 'standard', 'tall', 'custom']
                .map(
                  (p) =>
                    `<button type="button" class="${hs.mobileSizePreset === p ? 'active' : ''}" data-mobile-preset="${p}">${p[0].toUpperCase() + p.slice(1)}</button>`
                )
                .join('')}
            </div>
          </div>
        </div>

        <div class="adm-hero-grid-3" style="margin-top:4px;">
          <div class="ln-field">
            <label>Desktop Banner Width Preset</label>
            <div class="adm-hero-seg">
              ${[
                { k: 'compact', lbl: 'Compact (880px)' },
                { k: 'container', lbl: 'Container (1120px)' },
                { k: 'wide', lbl: 'Full Wide' },
                { k: 'custom', lbl: 'Custom' },
              ]
                .map(
                  (p) =>
                    `<button type="button" class="${hs.desktopSizePreset === p.k ? 'active' : ''}" data-desktop-preset="${p.k}">${p.lbl}</button>`
                )
                .join('')}
            </div>
          </div>

          <div class="ln-field">
            <label>Custom Desktop Max Width (px)</label>
            <input id="hsDesktopMaxWidth" type="number" min="480" max="2400" class="ln-input" value="${Number(hs.desktopMaxWidth)}" />
          </div>

          <div class="ln-field">
            <label>Aspect Ratio</label>
            <div class="adm-hero-seg">
              ${['auto', '21/9', '16/9', '16/10', '4/3', 'custom']
                .map(
                  (r) =>
                    `<button type="button" class="${hs.aspectRatio === r ? 'active' : ''}" data-ratio-preset="${r}">${r === 'auto' ? 'Auto' : r}</button>`
                )
                .join('')}
            </div>
            <input id="hsCustomRatio" class="ln-input" style="margin-top:6px;" value="${escapeAttr(hs.customAspectRatio)}" placeholder="Custom e.g. 16/7" />
          </div>
        </div>

        <div class="adm-hero-grid-3" style="margin-top:4px;">
          <div class="ln-field">
            <label>Image Fit</label>
            <div class="adm-hero-seg">
              <button type="button" class="${hs.imageFit === 'cover' ? 'active' : ''}" data-img-fit="cover">Cover</button>
              <button type="button" class="${hs.imageFit === 'contain' ? 'active' : ''}" data-img-fit="contain">Contain</button>
            </div>
          </div>

          <div class="ln-field">
            <label>Image Position</label>
            <div class="adm-hero-seg">
              ${['center', 'left', 'right', 'top', 'bottom']
                .map(
                  (pos) =>
                    `<button type="button" class="${hs.imagePosition === pos ? 'active' : ''}" data-img-pos="${pos}">${pos[0].toUpperCase() + pos.slice(1)}</button>`
                )
                .join('')}
            </div>
          </div>

          <div class="ln-field">
            <label>Border Radius Preset &amp; Custom (px)</label>
            <div class="adm-hero-seg">
              ${[
                { k: '0', lbl: '0px' },
                { k: '10', lbl: '10px' },
                { k: '16', lbl: '16px' },
                { k: '24', lbl: '24px' },
                { k: 'custom', lbl: 'Custom' },
              ]
                .map(
                  (b) =>
                    `<button type="button" class="${hs.borderRadiusPreset === b.k ? 'active' : ''}" data-radius-preset="${b.k}">${b.lbl}</button>`
                )
                .join('')}
            </div>
            <input id="hsBorderRadius" type="number" min="0" max="64" class="ln-input" style="margin-top:6px;" value="${Number(hs.borderRadius)}" />
          </div>
        </div>

        <div class="adm-grid-2" style="margin-top:4px;">
          <div class="ln-field">
            <label>Banner Outer Spacing Preset</label>
            <div class="adm-hero-seg">
              ${[
                { k: '0', lbl: 'Flush (0px)' },
                { k: '12', lbl: 'Tight (12px)' },
                { k: '16', lbl: 'Standard (16px)' },
                { k: '24', lbl: 'Editorial (24px)' },
                { k: 'custom', lbl: 'Custom' },
              ]
                .map(
                  (sp) =>
                    `<button type="button" class="${hs.spacingPreset === sp.k ? 'active' : ''}" data-spacing-preset="${sp.k}">${sp.lbl}</button>`
                )
                .join('')}
            </div>
          </div>

          <div class="ln-field">
            <label>Custom Banner Spacing (px)</label>
            <input id="hsBannerSpacing" type="number" min="0" max="64" class="ln-input" value="${Number(hs.bannerSpacing)}" />
          </div>
        </div>
      </div>

      <!-- Slider Animation & Auto-Slide Settings -->
      <div class="adm-grid-2">
        <div class="ln-card">
          <h4 style="font-size:16px;margin-bottom:12px;">Slider Animation Settings</h4>

          <div class="ln-field">
            <label>Animation Effect</label>
            <div class="adm-hero-seg">
              ${[
                { k: 'fade', lbl: 'Smooth Fade' },
                { k: 'slide-horizontal', lbl: 'Horizontal Slide' },
                { k: 'slide-vertical', lbl: 'Vertical Slide' },
                { k: 'zoom', lbl: 'Subtle Zoom' },
                { k: 'fade-zoom', lbl: 'Fade + Zoom' },
                { k: 'none', lbl: 'None' },
              ]
                .map(
                  (a) =>
                    `<button type="button" class="${hs.animationType === a.k ? 'active' : ''}" data-anim-type="${a.k}">${a.lbl}</button>`
                )
                .join('')}
            </div>
          </div>

          <div class="ln-field">
            <label>Animation Duration: <strong id="hsDurationLabel">${Number(hs.animationDurationMs)}ms</strong></label>
            <div style="display:flex;gap:10px;align-items:center;">
              <input id="hsDurationRange" type="range" min="0" max="2000" step="50" value="${Number(hs.animationDurationMs)}" style="flex:1;accent-color:var(--gold);" />
              <input id="hsDurationMs" type="number" min="0" max="3000" step="50" class="ln-input" style="width:96px;" value="${Number(hs.animationDurationMs)}" />
            </div>
          </div>

          <div class="ln-field">
            <label>Transition Speed / Easing</label>
            <div class="adm-hero-seg">
              ${[
                { k: 'cubic-bezier(0.22, 1, 0.36, 1)', lbl: 'Luxury Smooth' },
                { k: 'ease-in-out', lbl: 'Balanced' },
                { k: 'ease', lbl: 'Natural' },
                { k: 'linear', lbl: 'Uniform' },
              ]
                .map(
                  (es) =>
                    `<button type="button" class="${hs.transitionEasing === es.k ? 'active' : ''}" data-anim-ease="${escapeAttr(es.k)}">${es.lbl}</button>`
                )
                .join('')}
            </div>
          </div>

          <div class="ln-field">
            <label>Animation Intensity</label>
            <div class="adm-hero-seg">
              ${['subtle', 'balanced', 'dramatic']
                .map(
                  (lvl) =>
                    `<button type="button" class="${hs.animationIntensity === lvl ? 'active' : ''}" data-anim-intensity="${lvl}">${lvl[0].toUpperCase() + lvl.slice(1)}</button>`
                )
                .join('')}
            </div>
          </div>
        </div>

        <div class="ln-card">
          <h4 style="font-size:16px;margin-bottom:12px;">Auto-Slide &amp; Navigation Settings</h4>

          <div class="ln-field">
            <label>Auto-Slide Interval / Delay (Seconds)</label>
            <input id="hsIntervalSec" type="number" min="1" max="60" step="0.5" class="ln-input" value="${Number(hs.autoSlideIntervalSec)}" />
          </div>

          <div style="display:grid;gap:10px;margin-top:8px;">
            <label style="display:flex;align-items:center;gap:8px;font-size:13px;">
              <input type="checkbox" id="hsAutoSlide" ${hs.autoSlide ? 'checked' : ''} />
              Enable Auto-Slide
            </label>
            <label style="display:flex;align-items:center;gap:8px;font-size:13px;">
              <input type="checkbox" id="hsPauseHover" ${hs.pauseOnHover ? 'checked' : ''} />
              Pause on Hover
            </label>
            <label style="display:flex;align-items:center;gap:8px;font-size:13px;">
              <input type="checkbox" id="hsPauseInteract" ${hs.pauseOnInteraction ? 'checked' : ''} />
              Pause After Manual Interaction
            </label>
            <label style="display:flex;align-items:center;gap:8px;font-size:13px;">
              <input type="checkbox" id="hsShowArrows" ${hs.showArrows ? 'checked' : ''} />
              Show Manual Previous / Next Arrows
            </label>
            <label style="display:flex;align-items:center;gap:8px;font-size:13px;">
              <input type="checkbox" id="hsShowDots" ${hs.showDots ? 'checked' : ''} />
              Show Pagination Dots
            </label>
            <label style="display:flex;align-items:center;gap:8px;font-size:13px;">
              <input type="checkbox" id="hsLoop" ${hs.loop ? 'checked' : ''} />
              Loop Slider Continuously
            </label>
          </div>
        </div>
      </div>
    `;

    // Bind Top Actions
    host.querySelector('#btnHeroSave').onclick = () => {
      draft.heroSlider = normalizeHeroSliderConfig(draft.heroSlider);
      draft.slides = draft.slides.map((s, idx) => normalizeHeroSlide(s, idx));
      saveHeroBannerConfig({ bannerSlides: draft.slides, heroSlider: draft.heroSlider }, actor);
      showToast('Hero Banner & Slider saved & synced to storefront', 'success');
      renderPreviewOnly();
    };

    host.querySelector('#btnHeroReset').onclick = async () => {
      const ok = await openConfirmDialog({
        title: 'Reset Hero Banner & Slider',
        message: 'Restore all banner slides, sizing, animation, and auto-slide settings back to factory LUXE NEXUS defaults?',
        confirmLabel: 'Reset to Default',
        danger: true,
      });
      if (!ok) return;
      const fresh = resetHeroBannerConfig(actor);
      draft.slides = (fresh.bannerSlides || []).map((s, idx) => normalizeHeroSlide(s, idx));
      draft.heroSlider = normalizeHeroSliderConfig(fresh.heroSlider || {});
      draft.selectedIdx = 0;
      draft.previewSlideIdx = 0;
      showToast('Hero Banner restored to defaults', 'success');
      renderAll();
    };

    // Preview Controls
    host.querySelectorAll('[data-preview-device]').forEach((btn) => {
      btn.onclick = () => {
        draft.previewDevice = btn.dataset.previewDevice;
        host.querySelectorAll('[data-preview-device]').forEach((b) => b.classList.toggle('active', b === btn));
        renderPreviewOnly();
      };
    });
    host.querySelector('#btnPreviewPrev').onclick = () => activePreviewSlider?.prev();
    host.querySelector('#btnPreviewNext').onclick = () => activePreviewSlider?.next();

    // Slide Add / Bulk Add
    host.querySelector('#btnHeroAddSlide').onclick = () => {
      const next = createEmptyHeroSlide();
      draft.slides.push(next);
      draft.selectedIdx = draft.slides.length - 1;
      draft.previewSlideIdx = Math.max(0, draft.slides.filter((x) => x.enabled !== false).length - 1);
      renderSlideListOnly();
      renderSlideEditorOnly();
      renderPreviewOnly();
    };

    host.querySelector('#btnToggleBulkUrls').onclick = () => {
      draft.showBulkAdder = !draft.showBulkAdder;
      renderAll();
    };

    const btnBulk = host.querySelector('#btnApplyBulkUrls');
    if (btnBulk) {
      btnBulk.onclick = () => {
        const raw = host.querySelector('#txtBulkBannerUrls')?.value || '';
        const lines = raw
          .split(/\r?\n/)
          .map((l) => sanitizeUrl(l.trim(), true))
          .filter(Boolean);
        if (!lines.length) {
          showToast('Paste at least one valid http(s) or local image URL.', 'error');
          return;
        }
        lines.forEach((url, i) => {
          const s = createEmptyHeroSlide();
          s.image = url;
          s.title = `Featured Showcase ${draft.slides.length + 1}`;
          s.subtitle = i === 0 ? 'CURATED DROP' : 'LUXE NEXUS';
          draft.slides.push(s);
        });
        draft.selectedIdx = draft.slides.length - 1;
        draft.showBulkAdder = false;
        showToast(`Added ${lines.length} banner slide(s)`, 'success');
        renderAll();
      };
    }

    // Bind Size & Layout Presets & Custom Values
    const markPresetActive = (attr, value) => {
      host.querySelectorAll(`[${attr}]`).forEach((b) => b.classList.toggle('active', b.getAttribute(attr) === value));
    };

    host.querySelectorAll('[data-height-preset]').forEach((btn) => {
      btn.onclick = () => {
        const preset = btn.dataset.heightPreset;
        hs.heightPreset = preset;
        if (HEIGHT_PRESETS[preset]) {
          hs.desktopHeight = HEIGHT_PRESETS[preset].desktopHeight;
          hs.mobileHeight = HEIGHT_PRESETS[preset].mobileHeight;
          host.querySelector('#hsDesktopHeight').value = String(hs.desktopHeight);
          host.querySelector('#hsMobileHeight').value = String(hs.mobileHeight);
        }
        markPresetActive('data-height-preset', preset);
        renderPreviewOnly();
      };
    });

    host.querySelector('#hsDesktopHeight').oninput = (e) => {
      hs.desktopHeight = Number(e.target.value || 290);
      hs.heightPreset = 'custom';
      markPresetActive('data-height-preset', 'custom');
      renderPreviewOnly();
    };

    host.querySelector('#hsMobileHeight').oninput = (e) => {
      hs.mobileHeight = Number(e.target.value || 235);
      hs.heightPreset = 'custom';
      hs.mobileSizePreset = 'custom';
      markPresetActive('data-height-preset', 'custom');
      markPresetActive('data-mobile-preset', 'custom');
      renderPreviewOnly();
    };

    host.querySelector('#hsMinHeight').oninput = (e) => {
      hs.minHeight = Number(e.target.value || 200);
      renderPreviewOnly();
    };

    host.querySelector('#hsMaxHeight').oninput = (e) => {
      hs.maxHeight = Number(e.target.value || 560);
      renderPreviewOnly();
    };

    host.querySelectorAll('[data-mobile-preset]').forEach((btn) => {
      btn.onclick = () => {
        const p = btn.dataset.mobilePreset;
        hs.mobileSizePreset = p;
        if (MOBILE_SIZE_PRESETS[p]) {
          hs.mobileHeight = MOBILE_SIZE_PRESETS[p].mobileHeight;
          host.querySelector('#hsMobileHeight').value = String(hs.mobileHeight);
        }
        markPresetActive('data-mobile-preset', p);
        renderPreviewOnly();
      };
    });

    host.querySelectorAll('[data-desktop-preset]').forEach((btn) => {
      btn.onclick = () => {
        const p = btn.dataset.desktopPreset;
        hs.desktopSizePreset = p;
        if (DESKTOP_SIZE_PRESETS[p]) {
          hs.desktopMaxWidth = DESKTOP_SIZE_PRESETS[p].desktopMaxWidth;
          host.querySelector('#hsDesktopMaxWidth').value = String(hs.desktopMaxWidth);
        }
        markPresetActive('data-desktop-preset', p);
        renderPreviewOnly();
      };
    });

    host.querySelector('#hsDesktopMaxWidth').oninput = (e) => {
      hs.desktopMaxWidth = Number(e.target.value || 1120);
      hs.desktopSizePreset = 'custom';
      markPresetActive('data-desktop-preset', 'custom');
      renderPreviewOnly();
    };

    host.querySelectorAll('[data-ratio-preset]').forEach((btn) => {
      btn.onclick = () => {
        const r = btn.dataset.ratioPreset;
        hs.aspectRatio = r;
        markPresetActive('data-ratio-preset', r);
        renderPreviewOnly();
      };
    });

    host.querySelector('#hsCustomRatio').oninput = (e) => {
      hs.customAspectRatio = e.target.value;
      hs.aspectRatio = 'custom';
      markPresetActive('data-ratio-preset', 'custom');
      renderPreviewOnly();
    };

    host.querySelectorAll('[data-img-fit]').forEach((btn) => {
      btn.onclick = () => {
        hs.imageFit = btn.dataset.imgFit;
        markPresetActive('data-img-fit', hs.imageFit);
        renderPreviewOnly();
      };
    });

    host.querySelectorAll('[data-img-pos]').forEach((btn) => {
      btn.onclick = () => {
        hs.imagePosition = btn.dataset.imgPos;
        markPresetActive('data-img-pos', hs.imagePosition);
        renderPreviewOnly();
      };
    });

    host.querySelectorAll('[data-radius-preset]').forEach((btn) => {
      btn.onclick = () => {
        const p = btn.dataset.radiusPreset;
        hs.borderRadiusPreset = p;
        if (p !== 'custom') {
          hs.borderRadius = Number(p);
          host.querySelector('#hsBorderRadius').value = p;
        }
        markPresetActive('data-radius-preset', p);
        renderPreviewOnly();
      };
    });

    host.querySelector('#hsBorderRadius').oninput = (e) => {
      hs.borderRadius = Number(e.target.value || 0);
      hs.borderRadiusPreset = 'custom';
      markPresetActive('data-radius-preset', 'custom');
      renderPreviewOnly();
    };

    host.querySelectorAll('[data-spacing-preset]').forEach((btn) => {
      btn.onclick = () => {
        const p = btn.dataset.spacingPreset;
        hs.spacingPreset = p;
        if (p !== 'custom') {
          hs.bannerSpacing = Number(p);
          host.querySelector('#hsBannerSpacing').value = p;
        }
        markPresetActive('data-spacing-preset', p);
        renderPreviewOnly();
      };
    });

    host.querySelector('#hsBannerSpacing').oninput = (e) => {
      hs.bannerSpacing = Number(e.target.value || 0);
      hs.spacingPreset = 'custom';
      markPresetActive('data-spacing-preset', 'custom');
      renderPreviewOnly();
    };

    // Bind Animation Controls
    host.querySelectorAll('[data-anim-type]').forEach((btn) => {
      btn.onclick = () => {
        hs.animationType = btn.dataset.animType;
        markPresetActive('data-anim-type', hs.animationType);
        renderPreviewOnly();
      };
    });

    const durLbl = host.querySelector('#hsDurationLabel');
    const durRange = host.querySelector('#hsDurationRange');
    const durNum = host.querySelector('#hsDurationMs');
    const syncDuration = (val) => {
      const clamped = Math.max(0, Math.min(3000, Number(val || 0)));
      hs.animationDurationMs = clamped;
      if (durLbl) durLbl.textContent = `${clamped}ms`;
      if (durRange && Number(durRange.value) !== clamped) durRange.value = String(Math.min(2000, clamped));
      if (durNum && Number(durNum.value) !== clamped) durNum.value = String(clamped);
      renderPreviewOnly();
    };
    durRange.oninput = (e) => syncDuration(e.target.value);
    durNum.oninput = (e) => syncDuration(e.target.value);

    host.querySelectorAll('[data-anim-ease]').forEach((btn) => {
      btn.onclick = () => {
        hs.transitionEasing = btn.dataset.animEase;
        markPresetActive('data-anim-ease', hs.transitionEasing);
        renderPreviewOnly();
      };
    });

    host.querySelectorAll('[data-anim-intensity]').forEach((btn) => {
      btn.onclick = () => {
        hs.animationIntensity = btn.dataset.animIntensity;
        markPresetActive('data-anim-intensity', hs.animationIntensity);
        renderPreviewOnly();
      };
    });

    // Bind Auto-Slide & Navigation Controls
    host.querySelector('#hsIntervalSec').oninput = (e) => {
      hs.autoSlideIntervalSec = Math.max(1, Math.min(60, Number(e.target.value || 5)));
      renderPreviewOnly();
    };
    host.querySelector('#hsAutoSlide').onchange = (e) => { hs.autoSlide = e.target.checked; renderPreviewOnly(); };
    host.querySelector('#hsPauseHover').onchange = (e) => { hs.pauseOnHover = e.target.checked; renderPreviewOnly(); };
    host.querySelector('#hsPauseInteract').onchange = (e) => { hs.pauseOnInteraction = e.target.checked; renderPreviewOnly(); };
    host.querySelector('#hsShowArrows').onchange = (e) => { hs.showArrows = e.target.checked; renderPreviewOnly(); };
    host.querySelector('#hsShowDots').onchange = (e) => { hs.showDots = e.target.checked; renderPreviewOnly(); };
    host.querySelector('#hsLoop').onchange = (e) => { hs.loop = e.target.checked; renderPreviewOnly(); };

    renderSlideListOnly();
    renderSlideEditorOnly();
    renderPreviewOnly();
  };

  renderAll();
}
