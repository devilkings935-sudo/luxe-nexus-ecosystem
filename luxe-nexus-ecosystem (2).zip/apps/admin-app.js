/**
 * LUXE NEXUS Admin Control Studio Controller
 * Full No-Code Control Center, Dynamic Homepage & Navigation Builders,
 * Feature Flags, Popups, RBAC Matrix, Affiliate Control, Financial Ledger, & Update Manager.
 */

import { appServices, recordAuditLog } from '../adapters/backend-adapter.js';
import {
  ensureEcosystemSeeded,
  getPlatformConfig,
  updatePlatformConfig,
  saveAnnouncement,
  deleteAnnouncement,
  applyDesignTokensToDocument,
} from '../services/settings-service.js';
import {
  signupAccount,
  loginAccount,
  getActiveUser,
  logoutAccount,
  resetPassword,
  listAllUsers,
  adminUpdateUserRoleOrStatus,
  approveSellerAccount,
} from '../services/auth-service.js';
import {
  listAllProducts,
  saveProduct,
  setProductApproval,
  listCategories,
  saveCategory,
  deleteCategory,
} from '../services/product-service.js';
import {
  ORDER_STATUSES,
  updateOrderStatus,
  computeFinancialSummary,
} from '../services/order-service.js';
import {
  AFFILIATE_PROGRAM_RULES,
  listAffiliates,
  updateAffiliateStatus,
  adminOverrideCommissionStatus,
  adminProcessWithdrawal,
  getAffiliateLeaderboard,
  getAffiliateLevels,
  getAffiliateLevelConfig,
  adminSetAffiliateLevel,
  adminUpdateAffiliateHolds,
} from '../services/affiliate-service.js';
import { getUnreadCount } from '../services/notification-service.js';
import {
  listReleases,
  publishRelease,
  rollbackRelease,
} from '../services/update-service.js';
import {
  ROLES,
  ROLE_LABELS,
  PERMISSIONS,
  DEFAULT_ROLE_MATRIX,
  canModifyRoleMatrix,
} from '../shared/permissions.js';
import { evaluatePasswordStrength } from '../shared/validators.js';
import {
  escapeHtml,
  escapeAttr,
  formatMoney,
  formatDateTime,
  toCsv,
  sanitizeUrl,
} from '../shared/utilities.js';
import { OFFICIAL_LOGO_URL } from '../shared/configuration.js';
import {
  showToast,
  renderBarChartSvg,
  renderNotificationModal,
  openConfirmDialog,
  openInputDialog,
  initLuxurySelectObserver,
} from '../shared/shared-components.js';
import { renderHeroBannerManager } from './admin-hero-banner.js';

const $ = (id) => document.getElementById(id);

const SECTIONS = [
  { id: 'dashboard', label: 'Dashboard & Finance', icon: '⌂' },
  { id: 'heroBanner', label: 'Hero Banner / Slider', icon: '▣' },
  { id: 'homepage', label: 'Homepage Builder', icon: '◫' },
  { id: 'navigation', label: 'Navigation Manager', icon: '☰' },
  { id: 'features', label: 'Feature Control', icon: '⚙' },
  { id: 'popups', label: 'Popups & Notices', icon: '📣' },
  { id: 'storefront', label: 'Design & Storefront', icon: '✎' },
  { id: 'sellers', label: 'Sellers & Users', icon: '♙' },
  { id: 'products', label: 'Product Control', icon: '▦' },
  { id: 'orders', label: 'Order Management', icon: '▤' },
  { id: 'categories', label: 'Categories', icon: '▧' },
  { id: 'affiliates', label: 'Affiliate Control', icon: '◈' },
  { id: 'roles', label: 'Roles & Permissions', icon: '🛡' },
  { id: 'updates', label: 'Update Manager', icon: '↻' },
  { id: 'settings', label: 'Platform & Intl', icon: '🌐' },
];

const state = {
  activeSection: 'dashboard',
  authMode: 'login',
  storefrontTab: 'brand',
  affiliateSubTab: 'applications',
};

function money(val) {
  const cfg = getPlatformConfig();
  return formatMoney(val, cfg.international?.currency || 'BDT', cfg.international?.exchangeRates || {});
}

function downloadFile(filename, content, mime = 'application/json') {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function renderAuthGate() {
  const gate = $('adminAuthGate');
  const actor = getActiveUser('admin');
  if (actor) {
    gate.style.display = 'none';
    $('admActorRoleBadge').textContent = `${actor.name} · ${ROLE_LABELS[actor.role] || actor.role}`;
    return true;
  }

  gate.style.display = 'flex';
  const hasAdmin = appServices.auth.hasAnyAdminUser();
  if (!hasAdmin && state.authMode === 'login') state.authMode = 'signup';

  $('admAuthTitle').textContent = !hasAdmin
    ? 'Initialize Super Admin'
    : state.authMode === 'signup'
    ? 'Create Admin Account'
    : state.authMode === 'forgot'
    ? 'Reset Admin Password'
    : 'Admin Sign In';
  $('admAuthSubtitle').textContent = !hasAdmin
    ? 'First-run setup: create your Super Admin credentials to unlock the Control Studio.'
    : 'Sign in with your administrator email and password.';

  const host = $('admAuthFormArea');
  if (state.authMode === 'forgot') {
    host.innerHTML = `
      <div class="ln-field"><label>Registered Email *</label><input id="admRstEmail" type="email" class="ln-input" /></div>
      <div class="ln-field"><label>New Password *</label><input id="admRstPass" type="password" class="ln-input" /></div>
      <div class="ln-field"><label>Confirm Password *</label><input id="admRstConf" type="password" class="ln-input" /></div>
      <button type="button" class="ln-btn ln-btn-gold" id="btnAdmDoReset" style="width:100%;">Reset Password</button>
      <button type="button" class="ln-btn ln-btn-outline" id="btnAdmBackLogin" style="width:100%;margin-top:8px;">Back to Sign In</button>
    `;
    $('btnAdmBackLogin').onclick = () => { state.authMode = 'login'; renderAuthGate(); };
    $('btnAdmDoReset').onclick = async () => {
      try {
        await resetPassword({ contact: $('admRstEmail').value, newPassword: $('admRstPass').value, confirmPassword: $('admRstConf').value });
        showToast('Password updated', 'success');
        state.authMode = 'login';
        renderAuthGate();
      } catch (err) {
        showToast(err.message, 'error');
      }
    };
    return false;
  }

  const isSignup = state.authMode === 'signup';
  host.innerHTML = `
    ${isSignup ? `<div class="ln-field"><label>Full Name *</label><input id="admName" class="ln-input" placeholder="Administrator Name" /></div>` : ''}
    <div class="ln-field"><label>Email Address *</label><input id="admEmail" type="email" class="ln-input" placeholder="admin@luxenexus.com" /></div>
    <div class="ln-field">
      <label>Password *</label>
      <div style="display:flex;gap:6px;">
        <input id="admPass" type="password" class="ln-input" placeholder="Minimum 6 characters" />
        <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="btnAdmShowPass">Show</button>
      </div>
      ${isSignup ? `<div id="admPassStrength" style="font-size:11px;color:var(--text-muted);margin-top:4px;"></div>` : ''}
    </div>
    ${isSignup ? `<div class="ln-field"><label>Confirm Password *</label><input id="admConfPass" type="password" class="ln-input" placeholder="Confirm password" /></div>` : ''}
    <label style="display:flex;align-items:center;gap:8px;font-size:12px;margin:8px 0 14px;">
      <input type="checkbox" id="admRemember" checked /> Remember session on this device
    </label>
    <button type="button" class="ln-btn ln-btn-gold" id="btnAdmAuthSubmit" style="width:100%;">${isSignup ? (!hasAdmin ? 'Create Super Admin' : 'Create Admin Account') : 'Sign In to Studio'}</button>
    ${
      hasAdmin
        ? `<div style="display:flex;gap:8px;margin-top:10px;">
            <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="btnAdmToggleMode" style="flex:1;">${isSignup ? 'Use Existing Account' : 'Register Admin'}</button>
            ${!isSignup ? `<button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="btnAdmForgot" style="flex:1;">Forgot Password</button>` : ''}
          </div>`
        : ''
    }
  `;

  $('btnAdmShowPass').onclick = () => {
    const inp = $('admPass');
    const hide = inp.type === 'password';
    inp.type = hide ? 'text' : 'password';
    $('btnAdmShowPass').textContent = hide ? 'Hide' : 'Show';
  };
  if (isSignup) {
    $('admPass').oninput = () => {
      $('admPassStrength').textContent = `Strength: ${evaluatePasswordStrength($('admPass').value).label}`;
    };
  }
  const toggleBtn = $('btnAdmToggleMode');
  if (toggleBtn) toggleBtn.onclick = () => { state.authMode = isSignup ? 'login' : 'signup'; renderAuthGate(); };
  const forgotBtn = $('btnAdmForgot');
  if (forgotBtn) forgotBtn.onclick = () => { state.authMode = 'forgot'; renderAuthGate(); };

  $('btnAdmAuthSubmit').onclick = async () => {
    try {
      if (isSignup) {
        await signupAccount({
          name: $('admName').value,
          email: $('admEmail').value,
          password: $('admPass').value,
          confirmPassword: $('admConfPass').value,
          role: ROLES.ADMIN,
        });
      }
      await loginAccount({
        email: $('admEmail').value,
        password: $('admPass').value,
        appScope: 'admin',
        rememberMe: $('admRemember').checked,
      });
      showToast('Welcome to LUXE NEXUS Admin Control Studio', 'success');
      renderApp();
    } catch (err) {
      showToast(err.message, 'error');
    }
  };
  return false;
}

function renderSidebarAndTabs() {
  $('admSidebarNav').innerHTML = SECTIONS.map(
    (s) => `<button type="button" class="adm-nav-btn ${state.activeSection === s.id ? 'active' : ''}" data-adm-sec="${s.id}"><span>${s.icon}</span>${s.label}</button>`
  ).join('');
  $('admMobileNav').innerHTML = SECTIONS.map(
    (s) => `<button type="button" class="ln-btn ln-btn-sm ${state.activeSection === s.id ? '' : 'ln-btn-outline'}" data-adm-sec="${s.id}">${s.label}</button>`
  ).join('');

  document.querySelectorAll('[data-adm-sec]').forEach((btn) => {
    btn.onclick = () => {
      state.activeSection = btn.dataset.admSec;
      const meta = SECTIONS.find((x) => x.id === state.activeSection);
      $('admPageTitle').textContent = meta ? meta.label : 'Admin';
      renderSidebarAndTabs();
      renderSection();
    };
  });
}

function renderSection() {
  const actor = getActiveUser('admin');
  if (!actor) return;
  const host = $('admContent');
  const sec = state.activeSection;

  if (sec === 'dashboard') return renderDashboard(host);
  if (sec === 'heroBanner') return renderHeroBannerManager(host, actor);
  if (sec === 'homepage') return renderHomepageBuilder(host, actor);
  if (sec === 'navigation') return renderNavigationManager(host, actor);
  if (sec === 'features') return renderFeatureControl(host, actor);
  if (sec === 'popups') return renderPopupManager(host, actor);
  if (sec === 'storefront') return renderStorefrontEditor(host, actor);
  if (sec === 'sellers') return renderSellersAndUsers(host, actor);
  if (sec === 'products') return renderProductsControl(host, actor);
  if (sec === 'orders') return renderOrdersControl(host, actor);
  if (sec === 'categories') return renderCategoriesControl(host, actor);
  if (sec === 'affiliates') return renderAffiliateControl(host, actor);
  if (sec === 'roles') return renderRoleMatrix(host, actor);
  if (sec === 'updates') return renderUpdateManager(host, actor);
  if (sec === 'settings') return renderPlatformSettings(host, actor);
}

function renderDashboard(host) {
  const users = appServices.storage.getCollection('users', []);
  const sellers = appServices.sellers.list();
  const products = listAllProducts();
  const orders = appServices.orders.list();
  const affiliates = listAffiliates();
  const withdrawals = appServices.affiliates.withdrawals.list();
  const fin = computeFinancialSummary(orders);
  const audits = appServices.audits.list().slice(0, 8);

  const affSales = affiliates.reduce(
    (s, a) => s + appServices.affiliates.commissions.list().filter((c) => c.affiliateId === a.id && c.status !== 'rejected' && c.status !== 'reversed').reduce((x, c) => x + Number(c.orderTotal || 0), 0),
    0
  );

  const chartData = [
    { label: 'Sales', value: fin.totalSales, color: 'var(--brand)' },
    { label: 'Gross', value: fin.grossRevenue, color: 'var(--accent-blue)' },
    { label: 'Seller', value: fin.sellerPayout, color: 'var(--success)' },
    { label: 'Affiliate', value: fin.affiliateCommission, color: 'var(--gold)' },
    { label: 'Platform', value: Math.max(0, fin.platformEarnings), color: 'var(--brand)' },
  ];

  host.innerHTML = `
    <div class="adm-kpi-grid">
      <div class="adm-kpi"><small>Total Users</small><strong>${users.length}</strong></div>
      <div class="adm-kpi"><small>Sellers (Approved)</small><strong>${sellers.length} (${sellers.filter((s) => s.approved).length})</strong></div>
      <div class="adm-kpi"><small>Total Products</small><strong>${products.length}</strong></div>
      <div class="adm-kpi"><small>Total Orders</small><strong>${orders.length}</strong></div>
      <div class="adm-kpi"><small>Pending / Delivered / Cancelled</small><strong>${fin.pendingOrders} / ${fin.deliveredOrders} / ${fin.cancelledOrders}</strong></div>
      <div class="adm-kpi"><small>Total Sales</small><strong>${money(fin.totalSales)}</strong></div>
      <div class="adm-kpi"><small>Gross Revenue</small><strong>${money(fin.grossRevenue)}</strong></div>
      <div class="adm-kpi"><small>Net Revenue</small><strong>${money(fin.netRevenue)}</strong></div>
      <div class="adm-kpi"><small>Affiliates</small><strong>${affiliates.length}</strong></div>
      <div class="adm-kpi"><small>Affiliate Sales</small><strong>${money(affSales)}</strong></div>
      <div class="adm-kpi"><small>Affiliate Commission</small><strong>${money(fin.affiliateCommission)}</strong></div>
      <div class="adm-kpi"><small>Pending Withdrawals</small><strong>${withdrawals.filter((w) => w.status === 'pending').length}</strong></div>
    </div>

    <div class="adm-grid-2" style="margin-bottom:18px;">
      <div class="ln-card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
          <h3 style="font-size:15px;">Revenue &amp; Payout Distribution</h3>
          <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="btnExportFinCsv">Export Financial CSV</button>
        </div>
        ${renderBarChartSvg(chartData, 180)}
      </div>

      <div class="ln-card">
        <h3 style="font-size:15px;margin-bottom:10px;">Financial Ledger Summary</h3>
        <table class="ln-table">
          <tr><td>Total Product Sales</td><td class="tabular"><strong>${money(fin.totalSales)}</strong></td></tr>
          <tr><td>Discounts Applied</td><td class="tabular">${money(fin.discounts)}</td></tr>
          <tr><td>Delivery Charges</td><td class="tabular">${money(fin.deliveryCharges)}</td></tr>
          <tr><td>Payment Fees</td><td class="tabular">${money(fin.paymentFees)}</td></tr>
          <tr><td>Refunds</td><td class="tabular" style="color:var(--error);">${money(fin.refunds)}</td></tr>
          <tr><td>Seller Payouts</td><td class="tabular">${money(fin.sellerPayout)}</td></tr>
          <tr><td>Affiliate Commissions</td><td class="tabular">${money(fin.affiliateCommission)}</td></tr>
          <tr><td><strong>Platform Net Earnings</strong></td><td class="tabular"><strong style="color:var(--success);">${money(fin.platformEarnings)}</strong></td></tr>
        </table>
      </div>
    </div>

    <div class="ln-card">
      <h3 style="font-size:15px;margin-bottom:10px;">Recent Platform Activities (Audit Trail)</h3>
      ${
        audits.length
          ? `<div class="ln-table-wrap"><table class="ln-table"><thead><tr><th>Time</th><th>Actor</th><th>Action</th><th>Target</th><th>Details</th></tr></thead><tbody>${audits
              .map((a) => `<tr><td style="font-size:11px;">${formatDateTime(a.timestamp)}</td><td>${escapeHtml(a.actorRole)}</td><td class="mono" style="font-size:11px;">${escapeHtml(a.action)}</td><td class="mono" style="font-size:11px;">${escapeHtml(a.targetId)}</td><td>${escapeHtml(a.details)}</td></tr>`)
              .join('')}</tbody></table></div>`
          : '<div class="ln-empty">No recent audit activities logged yet.</div>'
      }
    </div>
  `;

  $('btnExportFinCsv').onclick = () => {
    const csv = toCsv(
      ['Metric', 'Value_BDT'],
      [
        ['Total Sales', fin.totalSales],
        ['Gross Revenue', fin.grossRevenue],
        ['Net Revenue', fin.netRevenue],
        ['Seller Payout', fin.sellerPayout],
        ['Affiliate Commission', fin.affiliateCommission],
        ['Refunds', fin.refunds],
        ['Discounts', fin.discounts],
        ['Delivery Charges', fin.deliveryCharges],
        ['Payment Fees', fin.paymentFees],
        ['Platform Earnings', fin.platformEarnings],
      ]
    );
    downloadFile('luxe-nexus-financial-report.csv', csv, 'text/csv');
    showToast('Financial CSV exported', 'success');
  };
}

function renderHomepageBuilder(host, actor) {
  const cfg = getPlatformConfig();
  const sections = [...(cfg.sections || [])].sort((a, b) => Number(a.order || 0) - Number(b.order || 0));

  host.innerHTML = `
    <div class="ln-card" style="margin-bottom:14px;">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:12px;">
        <div>
          <h3 style="font-size:16px;">Dynamic Homepage Sections</h3>
          <p style="font-size:12px;color:var(--text-muted);">Reorder, toggle visibility, schedule start/end dates, or edit section titles live in User App.</p>
        </div>
        <button type="button" class="ln-btn ln-btn-gold" id="btnSaveHomepage">Save Homepage Layout</button>
      </div>
      <div id="hpSectionList" style="display:grid;gap:12px;">
        ${sections
          .map(
            (s, idx) => `
          <div class="ln-card" style="padding:14px;background:var(--surface-2);">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:10px;flex-wrap:wrap;">
              <strong>#${idx + 1} · ${escapeHtml(s.type.toUpperCase())}</strong>
              <div style="display:flex;gap:6px;align-items:center;">
                <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-hp-up="${idx}" ${idx === 0 ? 'disabled' : ''}>↑</button>
                <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-hp-down="${idx}" ${idx === sections.length - 1 ? 'disabled' : ''}>↓</button>
                <label style="font-size:12px;display:flex;align-items:center;gap:5px;"><input type="checkbox" data-hp-key="visible" data-hp-idx="${idx}" ${s.visible !== false ? 'checked' : ''}/> Visible</label>
                <label style="font-size:12px;display:flex;align-items:center;gap:5px;"><input type="checkbox" data-hp-key="enabled" data-hp-idx="${idx}" ${s.enabled !== false ? 'checked' : ''}/> Enabled</label>
              </div>
            </div>
            <div class="adm-grid-2">
              <div class="ln-field"><label>Section Title</label><input class="ln-input" data-hp-key="title" data-hp-idx="${idx}" value="${escapeAttr(s.title)}" /></div>
              <div class="ln-field"><label>Subtitle</label><input class="ln-input" data-hp-key="subtitle" data-hp-idx="${idx}" value="${escapeAttr(s.subtitle || '')}" /></div>
              <div class="ln-field"><label>Schedule Start (optional)</label><input type="date" class="ln-input" data-hp-key="startDate" data-hp-idx="${idx}" value="${escapeAttr(s.startDate || '')}" /></div>
              <div class="ln-field"><label>Schedule End (optional)</label><input type="date" class="ln-input" data-hp-key="endDate" data-hp-idx="${idx}" value="${escapeAttr(s.endDate || '')}" /></div>
            </div>
            ${s.type === 'custom' ? `<div class="ln-field"><label>Custom Content</label><textarea class="ln-textarea" data-hp-key="customContent" data-hp-idx="${idx}">${escapeHtml(s.customContent || '')}</textarea></div>` : ''}
          </div>`
          )
          .join('')}
      </div>
    </div>
  `;

  const syncInputsToArray = () => {
    document.querySelectorAll('[data-hp-idx]').forEach((el) => {
      const i = Number(el.dataset.hpIdx);
      const k = el.dataset.hpKey;
      sections[i][k] = el.type === 'checkbox' ? el.checked : el.value;
    });
    sections.forEach((s, i) => { s.order = i + 1; });
  };

  host.querySelectorAll('[data-hp-up]').forEach((b) => {
    b.onclick = () => {
      syncInputsToArray();
      const i = Number(b.dataset.hpUp);
      [sections[i - 1], sections[i]] = [sections[i], sections[i - 1]];
      updatePlatformConfig({ sections }, actor);
      renderHomepageBuilder(host, actor);
    };
  });
  host.querySelectorAll('[data-hp-down]').forEach((b) => {
    b.onclick = () => {
      syncInputsToArray();
      const i = Number(b.dataset.hpDown);
      [sections[i + 1], sections[i]] = [sections[i], sections[i + 1]];
      updatePlatformConfig({ sections }, actor);
      renderHomepageBuilder(host, actor);
    };
  });
  $('btnSaveHomepage').onclick = () => {
    syncInputsToArray();
    updatePlatformConfig({ sections }, actor);
    showToast('Homepage layout saved & synced to User App', 'success');
  };
}

function renderNavigationManager(host, actor) {
  const cfg = getPlatformConfig();
  const nav = structuredClone(cfg.navigation);
  const groups = [
    ['bottomNav', 'User App Bottom Navigation (5 Default Items)'],
    ['headerNav', 'User App Header Navigation'],
    ['discoverMenu', 'Discover Drawer Menu'],
    ['accountMenu', 'My Account Services Menu'],
  ];

  host.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">
      <div><h3 style="font-size:16px;">Dynamic Navigation Manager</h3><p style="font-size:12px;color:var(--text-muted);">Edit titles, icons, order, visibility, and active states across User App menus.</p></div>
      <button type="button" class="ln-btn ln-btn-gold" id="btnSaveNavMgr">Save Navigation</button>
    </div>
    ${groups
      .map(
        ([gKey, gTitle]) => `
      <div class="ln-card" style="margin-bottom:14px;">
        <h4 style="font-size:14px;margin-bottom:10px;">${escapeHtml(gTitle)}</h4>
        <div class="ln-table-wrap">
          <table class="ln-table">
            <thead><tr><th>ID</th><th>Label</th><th>Icon</th><th>Order</th><th>Visible</th><th>Enabled</th></tr></thead>
            <tbody>
              ${(nav[gKey] || [])
                .map(
                  (item, idx) => `
                <tr>
                  <td class="mono">${escapeHtml(item.id)}</td>
                  <td><input class="ln-input" data-nav-g="${gKey}" data-nav-i="${idx}" data-nav-k="label" value="${escapeAttr(item.label)}" /></td>
                  <td><input class="ln-input" style="width:70px;" data-nav-g="${gKey}" data-nav-i="${idx}" data-nav-k="icon" value="${escapeAttr(item.icon || '')}" /></td>
                  <td><input type="number" class="ln-input" style="width:74px;" data-nav-g="${gKey}" data-nav-i="${idx}" data-nav-k="order" value="${Number(item.order || idx + 1)}" /></td>
                  <td><input type="checkbox" data-nav-g="${gKey}" data-nav-i="${idx}" data-nav-k="visible" ${item.visible !== false ? 'checked' : ''} /></td>
                  <td><input type="checkbox" data-nav-g="${gKey}" data-nav-i="${idx}" data-nav-k="enabled" ${item.enabled !== false ? 'checked' : ''} /></td>
                </tr>`
                )
                .join('')}
            </tbody>
          </table>
        </div>
      </div>`
      )
      .join('')}
  `;

  $('btnSaveNavMgr').onclick = () => {
    document.querySelectorAll('[data-nav-g]').forEach((el) => {
      const g = el.dataset.navG;
      const i = Number(el.dataset.navI);
      const k = el.dataset.navK;
      nav[g][i][k] = el.type === 'checkbox' ? el.checked : k === 'order' ? Number(el.value) : el.value;
    });
    updatePlatformConfig({ navigation: nav }, actor);
    showToast('Navigation configuration saved & synced', 'success');
  };
}

function renderFeatureControl(host, actor) {
  const cfg = getPlatformConfig();
  const flags = structuredClone(cfg.featureFlags);
  const grouped = {};
  for (const [key, val] of Object.entries(flags)) {
    const g = val.group || 'General';
    grouped[g] = grouped[g] || [];
    grouped[g].push({ key, ...val });
  }

  host.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">
      <div><h3 style="font-size:16px;">Feature Control Center</h3><p style="font-size:12px;color:var(--text-muted);">Enable or disable platform capabilities across UI and Service Layer.</p></div>
      <button type="button" class="ln-btn ln-btn-gold" id="btnSaveFeatures">Save Feature Flags</button>
    </div>
    ${Object.entries(grouped)
      .map(
        ([grp, list]) => `
      <div class="ln-card" style="margin-bottom:14px;">
        <h4 style="font-size:14px;margin-bottom:10px;">${escapeHtml(grp)} Features</h4>
        <div class="ln-table-wrap">
          <table class="ln-table">
            <thead><tr><th>Feature</th><th>Enabled</th><th>Visible</th><th>Maintenance Message</th></tr></thead>
            <tbody>
              ${list
                .map(
                  (f) => `
                <tr>
                  <td><strong>${escapeHtml(f.label)}</strong><div class="mono" style="font-size:11px;color:var(--text-muted);">${escapeHtml(f.key)}</div></td>
                  <td><input type="checkbox" data-ff-key="${escapeAttr(f.key)}" data-ff-prop="enabled" ${f.enabled !== false ? 'checked' : ''} /></td>
                  <td><input type="checkbox" data-ff-key="${escapeAttr(f.key)}" data-ff-prop="visible" ${f.visible !== false ? 'checked' : ''} /></td>
                  <td><input class="ln-input" data-ff-key="${escapeAttr(f.key)}" data-ff-prop="maintenanceMessage" value="${escapeAttr(f.maintenanceMessage || '')}" /></td>
                </tr>`
                )
                .join('')}
            </tbody>
          </table>
        </div>
      </div>`
      )
      .join('')}
  `;

  $('btnSaveFeatures').onclick = () => {
    document.querySelectorAll('[data-ff-key]').forEach((el) => {
      const k = el.dataset.ffKey;
      const p = el.dataset.ffProp;
      flags[k][p] = el.type === 'checkbox' ? el.checked : el.value;
    });
    updatePlatformConfig({ featureFlags: flags }, actor);
    showToast('Feature flags updated across ecosystem', 'success');
  };
}

function renderPopupManager(host, actor) {
  const list = appServices.announcements.list();
  host.innerHTML = `
    <div class="ln-card" style="margin-bottom:14px;">
      <h3 style="font-size:16px;margin-bottom:12px;">Create Announcement / Popup</h3>
      <div class="adm-grid-2">
        <div class="ln-field"><label>Type</label><select id="popType" class="ln-select"><option value="announcement">Announcement</option><option value="promotional">Promotional Popup</option><option value="notice">Notice</option></select></div>
        <div class="ln-field"><label>Target Audience</label><select id="popAudience" class="ln-select"><option value="all">All Users</option><option value="user">Customers Only</option><option value="seller">Sellers</option></select></div>
        <div class="ln-field"><label>Title *</label><input id="popTitle" class="ln-input" placeholder="e.g. Autumn Archive Event" /></div>
        <div class="ln-field"><label>Image URL</label><input id="popImg" class="ln-input" placeholder="/src/assets/images/..." /></div>
        <div class="ln-field"><label>Button Text</label><input id="popBtnText" class="ln-input" value="Explore Now" /></div>
        <div class="ln-field"><label>Button Action</label><select id="popBtnAction" class="ln-select"><option value="close">Dismiss</option><option value="page:categories">Open Categories</option><option value="page:affiliate">Open Affiliate Program</option></select></div>
        <div class="ln-field"><label>Start Date</label><input id="popStart" type="date" class="ln-input" /></div>
        <div class="ln-field"><label>End Date</label><input id="popEnd" type="date" class="ln-input" /></div>
      </div>
      <div class="ln-field"><label>Description *</label><textarea id="popDesc" class="ln-textarea"></textarea></div>
      <div style="display:flex;gap:16px;margin-bottom:12px;">
        <label style="font-size:12px;"><input type="checkbox" id="popDismiss" checked /> Dismissible</label>
        <label style="font-size:12px;"><input type="checkbox" id="popMandatory" /> Mandatory Notice</label>
        <label style="font-size:12px;"><input type="checkbox" id="popActive" checked /> Active Immediately</label>
      </div>
      <button type="button" class="ln-btn ln-btn-gold" id="btnSavePopup">Publish Popup / Notice</button>
    </div>

    <div class="ln-card">
      <h3 style="font-size:16px;margin-bottom:10px;">Configured Popups (${list.length})</h3>
      ${list
        .map(
          (a) => `
        <div style="padding:10px 0;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;gap:12px;">
          <div>
            <strong>${escapeHtml(a.title)}</strong> · <span style="font-size:11px;color:var(--text-muted);">${escapeHtml(a.type)} · ${a.active ? 'Active' : 'Inactive'}</span>
            <div style="font-size:12px;color:var(--text-muted);">${escapeHtml(a.description)}</div>
          </div>
          <div style="display:flex;gap:6px;">
            <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-toggle-pop="${escapeAttr(a.id)}">${a.active ? 'Disable' : 'Enable'}</button>
            <button type="button" class="ln-btn ln-btn-danger ln-btn-sm" data-del-pop="${escapeAttr(a.id)}">Delete</button>
          </div>
        </div>`
        )
        .join('')}
    </div>
  `;

  $('btnSavePopup').onclick = () => {
    if (!$('popTitle').value.trim()) return showToast('Title is required', 'error');
    saveAnnouncement(
      {
        type: $('popType').value,
        targetAudience: $('popAudience').value,
        title: $('popTitle').value,
        image: $('popImg').value,
        buttonText: $('popBtnText').value,
        buttonAction: $('popBtnAction').value,
        startDate: $('popStart').value,
        endDate: $('popEnd').value,
        dismissible: $('popDismiss').checked,
        mandatory: $('popMandatory').checked,
        active: $('popActive').checked,
      },
      actor
    );
    showToast('Popup saved', 'success');
    renderPopupManager(host, actor);
  };
  host.querySelectorAll('[data-toggle-pop]').forEach((b) => {
    b.onclick = () => {
      const target = list.find((x) => x.id === b.dataset.togglePop);
      if (target) saveAnnouncement({ ...target, active: !target.active }, actor);
      renderPopupManager(host, actor);
    };
  });
  host.querySelectorAll('[data-del-pop]').forEach((b) => {
    b.onclick = () => { deleteAnnouncement(b.dataset.delPop, actor); renderPopupManager(host, actor); };
  });
}

function renderStorefrontEditor(host, actor) {
  const cfg = getPlatformConfig();
  const slides = structuredClone(cfg.bannerSlides || []);

  host.innerHTML = `
    <div class="ln-card">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:14px;">
        <h3 style="font-size:16px;">User App Design &amp; Content Editor</h3>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="btnExportCfg">Export Settings JSON</button>
          <button type="button" class="ln-btn ln-btn-gold ln-btn-sm" id="btnSaveStorefront">Save All Storefront Settings</button>
        </div>
      </div>

      <div class="adm-grid-2">
        <div class="ln-field"><label>Brand Name</label><input id="edBrand" class="ln-input" value="${escapeAttr(cfg.brand)}" /></div>
        <div class="ln-field"><label>Top Announcement</label><input id="edAnnounce" class="ln-input" value="${escapeAttr(cfg.announce)}" /></div>
        <div class="ln-field"><label>Support Contact</label><input id="edSupport" class="ln-input" value="${escapeAttr(cfg.support)}" /></div>
        <div class="ln-field"><label>App Share Link</label><input id="edShareLink" class="ln-input" value="${escapeAttr(cfg.appShareLink || '')}" placeholder="https://..." /></div>
      </div>

      <h4 style="margin:14px 0 8px;">Visual Theme Tokens</h4>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;">
        <div class="ln-field"><label>Primary Brand</label><input id="edPrimary" type="color" class="ln-input" value="${escapeAttr(cfg.primary || '#6E1826')}" /></div>
        <div class="ln-field"><label>Accent Gold</label><input id="edGold" type="color" class="ln-input" value="${escapeAttr(cfg.accentGold || '#C9A45C')}" /></div>
        <div class="ln-field"><label>Page Background</label><input id="edBg" type="color" class="ln-input" value="${escapeAttr(cfg.background || '#0B0B0D')}" /></div>
        <div class="ln-field"><label>Card Surface</label><input id="edCard" type="color" class="ln-input" value="${escapeAttr(cfg.card || '#141418')}" /></div>
        <div class="ln-field"><label>Primary Text</label><input id="edText" type="color" class="ln-input" value="${escapeAttr(cfg.text || '#F5F1E8')}" /></div>
        <div class="ln-field"><label>Button Shape</label><select id="edBtnShape" class="ln-select"><option value="rounded" ${cfg.buttonShape === 'rounded' ? 'selected' : ''}>Rounded</option><option value="pill" ${cfg.buttonShape === 'pill' ? 'selected' : ''}>Pill</option><option value="square" ${cfg.buttonShape === 'square' ? 'selected' : ''}>Square</option></select></div>
      </div>

      <h4 style="margin:14px 0 8px;">Hero Banner Slides (${slides.length})</h4>
      <div id="edSlidesWrap" style="display:grid;gap:10px;margin-bottom:10px;">
        ${slides
          .map(
            (b, i) => `
          <div class="ln-card" style="padding:12px;background:var(--surface-2);">
            <div style="display:flex;justify-content:space-between;margin-bottom:8px;"><strong>Slide ${i + 1}</strong><button type="button" class="ln-btn ln-btn-danger ln-btn-sm" data-rem-slide="${i}">Remove</button></div>
            <div class="adm-grid-2">
              <div class="ln-field"><label>Image URL</label><input class="ln-input" data-sl-i="${i}" data-sl-k="image" value="${escapeAttr(b.image || '')}" /></div>
              <div class="ln-field"><label>Eyebrow</label><input class="ln-input" data-sl-i="${i}" data-sl-k="eyebrow" value="${escapeAttr(b.eyebrow || '')}" /></div>
              <div class="ln-field"><label>Title</label><input class="ln-input" data-sl-i="${i}" data-sl-k="title" value="${escapeAttr(b.title || '')}" /></div>
              <div class="ln-field"><label>Button Text</label><input class="ln-input" data-sl-i="${i}" data-sl-k="button" value="${escapeAttr(b.button || '')}" /></div>
            </div>
            <div class="ln-field"><label>Description</label><input class="ln-input" data-sl-i="${i}" data-sl-k="desc" value="${escapeAttr(b.desc || '')}" /></div>
          </div>`
          )
          .join('')}
      </div>
      <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="btnAddSlide">+ Add Hero Banner Slide</button>

      <h4 style="margin:16px 0 8px;">Checkout &amp; Payment Settings</h4>
      <div class="adm-grid-2">
        <div class="ln-field"><label>Inside Dhaka Fee</label><input id="edDhakaFee" type="number" class="ln-input" value="${Number(cfg.checkout?.dhakaFee || 60)}" /></div>
        <div class="ln-field"><label>Outside Dhaka Fee</label><input id="edOutFee" type="number" class="ln-input" value="${Number(cfg.checkout?.outFee || 120)}" /></div>
      </div>
      <div style="display:flex;gap:16px;flex-wrap:wrap;margin-bottom:14px;">
        <label style="font-size:12px;"><input type="checkbox" id="edCod" ${cfg.checkout?.cod !== false ? 'checked' : ''} /> Cash on Delivery</label>
        <label style="font-size:12px;"><input type="checkbox" id="edBkash" ${cfg.checkout?.bkash ? 'checked' : ''} /> bKash</label>
        <label style="font-size:12px;"><input type="checkbox" id="edNagad" ${cfg.checkout?.nagad ? 'checked' : ''} /> Nagad</label>
        <label style="font-size:12px;"><input type="checkbox" id="edLoginReq" ${cfg.checkout?.loginRequired !== false ? 'checked' : ''} /> Login Required at Checkout</label>
      </div>

      <h4 style="margin:14px 0 8px;">Editable Pages &amp; Policies</h4>
      <div class="ln-field"><label>Footer About Text</label><textarea id="edFooter" class="ln-textarea">${escapeHtml(cfg.pages?.footer || '')}</textarea></div>
      <div class="ln-field"><label>Return &amp; Refund Policy</label><textarea id="edReturns" class="ln-textarea">${escapeHtml(cfg.pages?.returns || '')}</textarea></div>
      <div class="ln-field"><label>Privacy Policy</label><textarea id="edPrivacy" class="ln-textarea">${escapeHtml(cfg.pages?.privacy || '')}</textarea></div>
      <div class="ln-field"><label>Terms &amp; Conditions</label><textarea id="edTerms" class="ln-textarea">${escapeHtml(cfg.pages?.terms || '')}</textarea></div>
    </div>
  `;

  const collectSlides = () => {
    document.querySelectorAll('[data-sl-i]').forEach((el) => {
      slides[Number(el.dataset.slI)][el.dataset.slK] = el.value;
    });
  };
  $('btnAddSlide').onclick = () => {
    collectSlides();
    slides.push({ image: '/src/assets/images/hero_luxe_collection_1795240520616.jpg', eyebrow: 'LUXE NEXUS', title: 'New Featured Drop', desc: 'Explore curated luxury pieces.', button: 'Shop Now', link: 'category:all' });
    updatePlatformConfig({ bannerSlides: slides }, actor);
    renderStorefrontEditor(host, actor);
  };
  host.querySelectorAll('[data-rem-slide]').forEach((b) => {
    b.onclick = () => {
      collectSlides();
      slides.splice(Number(b.dataset.remSlide), 1);
      updatePlatformConfig({ bannerSlides: slides }, actor);
      renderStorefrontEditor(host, actor);
    };
  });
  $('btnSaveStorefront').onclick = () => {
    collectSlides();
    const next = updatePlatformConfig(
      {
        brand: $('edBrand').value,
        announce: $('edAnnounce').value,
        support: $('edSupport').value,
        appShareLink: $('edShareLink').value,
        primary: $('edPrimary').value,
        accentGold: $('edGold').value,
        background: $('edBg').value,
        card: $('edCard').value,
        text: $('edText').value,
        buttonShape: $('edBtnShape').value,
        bannerSlides: slides,
        checkout: {
          ...cfg.checkout,
          dhakaFee: Number($('edDhakaFee').value),
          outFee: Number($('edOutFee').value),
          cod: $('edCod').checked,
          bkash: $('edBkash').checked,
          nagad: $('edNagad').checked,
          loginRequired: $('edLoginReq').checked,
        },
        pages: {
          ...cfg.pages,
          footer: $('edFooter').value,
          returns: $('edReturns').value,
          privacy: $('edPrivacy').value,
          terms: $('edTerms').value,
        },
      },
      actor
    );
    applyDesignTokensToDocument(next);
    showToast('Storefront configuration saved & pushed to User App', 'success');
  };
  $('btnExportCfg').onclick = () => downloadFile('luxe-nexus-platform-config.json', JSON.stringify(getPlatformConfig(), null, 2));
}

function renderSellersAndUsers(host, actor) {
  const sellers = appServices.sellers.list();
  const users = listAllUsers(actor);

  host.innerHTML = `
    <div class="ln-card" style="margin-bottom:16px;">
      <h3 style="font-size:16px;margin-bottom:10px;">Seller Applications &amp; Stores (${sellers.length})</h3>
      ${
        sellers.length
          ? `<div class="ln-table-wrap"><table class="ln-table"><thead><tr><th>Store</th><th>Owner</th><th>Email</th><th>Status</th><th>Action</th></tr></thead><tbody>${sellers
              .map(
                (s) => `
              <tr>
                <td><strong>${escapeHtml(s.storeName)}</strong></td>
                <td>${escapeHtml(s.name)}</td>
                <td>${escapeHtml(s.email)}</td>
                <td><span class="ln-status ${s.approved ? 'ln-status-success' : 'ln-status-warning'}">${escapeHtml(s.status || (s.approved ? 'approved' : 'pending'))}</span></td>
                <td>
                  <div style="display:flex;gap:6px;">
                    ${!s.approved ? `<button type="button" class="ln-btn ln-btn-sm" data-app-seller="${escapeAttr(s.id)}">Approve</button>` : ''}
                    <button type="button" class="ln-btn ln-btn-danger ln-btn-sm" data-rej-seller="${escapeAttr(s.id)}">${s.approved ? 'Suspend' : 'Reject'}</button>
                  </div>
                </td>
              </tr>`
              )
              .join('')}</tbody></table></div>`
          : '<div class="ln-empty">No sellers registered yet.</div>'
      }
    </div>

    <div class="ln-card">
      <h3 style="font-size:16px;margin-bottom:10px;">Registered Platform Accounts (${users.length})</h3>
      <div class="ln-table-wrap">
        <table class="ln-table">
          <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Update Role</th></tr></thead>
          <tbody>
            ${users
              .map(
                (u) => `
              <tr>
                <td><strong>${escapeHtml(u.name)}</strong></td>
                <td>${escapeHtml(u.email)}</td>
                <td>${escapeHtml(ROLE_LABELS[u.role] || u.role)}</td>
                <td>${escapeHtml(u.status)}</td>
                <td>
                  <select class="ln-select" style="min-width:140px;" data-user-role="${escapeAttr(u.uid)}" ${u.role === ROLES.SUPER_ADMIN && actor.role !== ROLES.SUPER_ADMIN ? 'disabled' : ''}>
                    ${Object.entries(ROLE_LABELS).map(([k, lbl]) => `<option value="${k}" ${u.role === k ? 'selected' : ''}>${escapeHtml(lbl)}</option>`).join('')}
                  </select>
                </td>
              </tr>`
              )
              .join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;

  host.querySelectorAll('[data-app-seller]').forEach((b) => {
    b.onclick = () => { approveSellerAccount(b.dataset.appSeller, true, actor); showToast('Seller approved', 'success'); renderSellersAndUsers(host, actor); };
  });
  host.querySelectorAll('[data-rej-seller]').forEach((b) => {
    b.onclick = () => { approveSellerAccount(b.dataset.rejSeller, false, actor, 'Admin review'); showToast('Seller suspended/rejected'); renderSellersAndUsers(host, actor); };
  });
  host.querySelectorAll('[data-user-role]').forEach((sel) => {
    sel.onchange = () => {
      try {
        adminUpdateUserRoleOrStatus(sel.dataset.userRole, { role: sel.value }, actor);
        showToast('User role updated', 'success');
        renderSellersAndUsers(host, actor);
      } catch (err) {
        showToast(err.message, 'error');
        renderSellersAndUsers(host, actor);
      }
    };
  });
}

function renderProductsControl(host, actor) {
  const products = listAllProducts();
  const cats = listCategories();
  host.innerHTML = `
    <div class="ln-card" style="margin-bottom:14px;">
      <h3 style="font-size:16px;margin-bottom:10px;">Quick Add Official Product</h3>
      <div class="adm-grid-2">
        <div class="ln-field"><label>Product Name *</label><input id="admProdName" class="ln-input" /></div>
        <div class="ln-field"><label>Category *</label><select id="admProdCat" class="ln-select">${cats.map((c) => `<option value="${escapeAttr(c.name)}">${escapeHtml(c.name)}</option>`).join('')}</select></div>
        <div class="ln-field"><label>Regular Price *</label><input id="admProdPrice" type="number" class="ln-input" /></div>
        <div class="ln-field"><label>Offer Price</label><input id="admProdOffer" type="number" class="ln-input" /></div>
        <div class="ln-field"><label>Stock</label><input id="admProdStock" type="number" class="ln-input" value="20" /></div>
        <div class="ln-field"><label>Image URL *</label><input id="admProdImg" class="ln-input" value="/src/assets/images/prod_tailored_shirt_1795240519571.jpg" /></div>
      </div>
      <button type="button" class="ln-btn ln-btn-gold" id="btnAdmAddProd">Add &amp; Publish Product</button>
    </div>

    <div class="ln-card">
      <h3 style="font-size:16px;margin-bottom:10px;">All Catalog Products (${products.length})</h3>
      <div class="ln-table-wrap">
        <table class="ln-table">
          <thead><tr><th>Product</th><th>Seller</th><th>Price</th><th>Stock</th><th>Status</th><th>Action</th></tr></thead>
          <tbody>
            ${products
              .map(
                (p) => `
              <tr>
                <td><div style="display:flex;align-items:center;gap:10px;"><img src="${escapeAttr(sanitizeUrl(p.image, true))}" alt="" referrerpolicy="no-referrer" style="width:42px;height:42px;object-fit:cover;border-radius:6px;" /><strong>${escapeHtml(p.name)}</strong></div></td>
                <td>${escapeHtml(p.sellerName || p.sellerId)}</td>
                <td class="tabular">${money(p.offerPrice || p.price)}</td>
                <td class="tabular">${Number(p.stock || 0)}</td>
                <td><span class="ln-status ${p.approved ? 'ln-status-success' : 'ln-status-warning'}">${escapeHtml(p.status)}</span></td>
                <td>
                  <div style="display:flex;gap:6px;">
                    ${!p.approved ? `<button type="button" class="ln-btn ln-btn-sm" data-app-prod="${escapeAttr(p.id)}">Approve</button>` : `<button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-rej-prod="${escapeAttr(p.id)}">Unpublish</button>`}
                  </div>
                </td>
              </tr>`
              )
              .join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;

  $('btnAdmAddProd').onclick = () => {
    try {
      saveProduct(
        {
          name: $('admProdName').value,
          cat: $('admProdCat').value,
          price: $('admProdPrice').value,
          offerPrice: $('admProdOffer').value || $('admProdPrice').value,
          stock: $('admProdStock').value,
          images: [$('admProdImg').value],
          featured: true,
          approved: true,
        },
        actor
      );
      showToast('Product published', 'success');
      renderProductsControl(host, actor);
    } catch (err) {
      showToast(err.message, 'error');
    }
  };
  host.querySelectorAll('[data-app-prod]').forEach((b) => {
    b.onclick = () => { setProductApproval(b.dataset.appProd, true, actor); renderProductsControl(host, actor); };
  });
  host.querySelectorAll('[data-rej-prod]').forEach((b) => {
    b.onclick = () => { setProductApproval(b.dataset.rejProd, false, actor); renderProductsControl(host, actor); };
  });
}

function renderOrdersControl(host, actor) {
  const orders = appServices.orders.list();
  host.innerHTML = `
    <div class="ln-card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
        <h3 style="font-size:16px;">Order Management (${orders.length})</h3>
        <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="btnExportOrdersCsv">Export Orders CSV</button>
      </div>
      ${
        orders.length
          ? `<div class="ln-table-wrap"><table class="ln-table"><thead><tr><th>Order ID</th><th>Customer</th><th>Items</th><th>Total</th><th>Affiliate</th><th>Status</th></tr></thead><tbody>${orders
              .map(
                (o) => `
              <tr>
                <td class="mono">${escapeHtml(o.id)}<div style="font-size:11px;color:var(--text-muted);">${formatDateTime(o.createdAt)}</div></td>
                <td><strong>${escapeHtml(o.customer?.name)}</strong><div style="font-size:11px;color:var(--text-muted);">${escapeHtml(o.customer?.phone)} · ${escapeHtml(o.customer?.district)}</div></td>
                <td>${escapeHtml(o.product)}</td>
                <td class="tabular"><strong>${money(o.total)}</strong></td>
                <td class="mono" style="font-size:11px;">${escapeHtml(o.affiliateId || 'Direct')}</td>
                <td>
                  <select class="ln-select" style="min-width:150px;" data-ord-stat="${escapeAttr(o.id)}">
                    ${ORDER_STATUSES.map((st) => `<option value="${st}" ${o.status === st ? 'selected' : ''}>${st}</option>`).join('')}
                  </select>
                </td>
              </tr>`
              )
              .join('')}</tbody></table></div>`
          : '<div class="ln-empty">No orders placed yet.</div>'
      }
    </div>
  `;

  host.querySelectorAll('[data-ord-stat]').forEach((sel) => {
    sel.onchange = () => {
      try {
        updateOrderStatus(sel.dataset.ordStat, sel.value, actor);
        showToast(`Order updated to ${sel.value}`, 'success');
        renderOrdersControl(host, actor);
      } catch (err) {
        showToast(err.message, 'error');
      }
    };
  });
  $('btnExportOrdersCsv').onclick = () => {
    const csv = toCsv(
      ['OrderID', 'Date', 'Customer', 'Phone', 'Product', 'Total', 'Payment', 'Status'],
      orders.map((o) => [o.id, o.createdAt, o.customer?.name, o.customer?.phone, o.product, o.total, o.payment, o.status])
    );
    downloadFile('luxe-nexus-orders.csv', csv, 'text/csv');
  };
}

function renderCategoriesControl(host, actor) {
  const cats = listCategories();
  let uploadedImg = '';
  host.innerHTML = `
    <div class="ln-card" style="margin-bottom:14px;">
      <h3 style="font-size:16px;margin-bottom:10px;">Add Category</h3>
      <div class="adm-grid-2">
        <div class="ln-field"><label>Category Name *</label><input id="catNameIn" class="ln-input" placeholder="e.g. Fragrances" /></div>
        <div class="ln-field"><label>Image URL</label><input id="catUrlIn" class="ln-input" placeholder="https://... or /src/assets/..." /></div>
      </div>
      <div class="ln-field"><label>Or Upload Local Photo (&lt; 900KB)</label><input id="catFileIn" type="file" accept="image/*" class="ln-input" /></div>
      <button type="button" class="ln-btn ln-btn-gold" id="btnAddCat">Save Category</button>
    </div>

    <div class="ln-card">
      <h3 style="font-size:16px;margin-bottom:10px;">Categories (${cats.length})</h3>
      ${cats
        .map(
          (c) => `
        <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-bottom:1px solid var(--border);gap:12px;">
          <div style="display:flex;align-items:center;gap:12px;">
            <img src="${escapeAttr(sanitizeUrl(c.image, true))}" alt="" referrerpolicy="no-referrer" style="width:46px;height:46px;object-fit:cover;border-radius:8px;background:var(--surface-2);" />
            <strong>${escapeHtml(c.name)}</strong>
          </div>
          <button type="button" class="ln-btn ln-btn-danger ln-btn-sm" data-del-cat="${escapeAttr(c.id)}">Remove</button>
        </div>`
        )
        .join('')}
    </div>
  `;

  $('catFileIn').onchange = (ev) => {
    const f = ev.target.files?.[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => { uploadedImg = String(reader.result || ''); };
    reader.readAsDataURL(f);
  };
  $('btnAddCat').onclick = () => {
    try {
      saveCategory({ name: $('catNameIn').value, image: $('catUrlIn').value || uploadedImg }, actor);
      showToast('Category added', 'success');
      renderCategoriesControl(host, actor);
    } catch (err) {
      showToast(err.message, 'error');
    }
  };
  host.querySelectorAll('[data-del-cat]').forEach((b) => {
    b.onclick = () => { deleteCategory(b.dataset.delCat, actor); renderCategoriesControl(host, actor); };
  });
}

function renderAffiliateControl(host, actor) {
  const affs = listAffiliates();
  const comms = appServices.affiliates.commissions.list();
  const withdrawals = appServices.affiliates.withdrawals.list();
  const cfg = getPlatformConfig();
  const levels = getAffiliateLevels(cfg);
  const board = getAffiliateLeaderboard('monthly');

  host.innerHTML = `
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px;">
      ${[
        ['applications', `Applications & Partners (${affs.length})`],
        ['commissions', `Commissions (${comms.length})`],
        ['withdrawals', `Withdrawals (${withdrawals.length})`],
        ['rules', 'Levels, Rules & Settings'],
        ['leaderboard', 'Leaderboard'],
      ]
        .map(([k, lbl]) => `<button type="button" class="ln-btn ln-btn-sm ${state.affiliateSubTab === k ? '' : 'ln-btn-outline'}" data-asub="${k}">${lbl}</button>`)
        .join('')}
    </div>
    <div id="affControlBody"></div>
  `;

  host.querySelectorAll('[data-asub]').forEach((b) => {
    b.onclick = () => { state.affiliateSubTab = b.dataset.asub; renderAffiliateControl(host, actor); };
  });

  const body = $('affControlBody');
  if (state.affiliateSubTab === 'applications') {
    body.innerHTML = `<div class="ln-card">${
      affs.length
        ? `<div class="ln-table-wrap"><table class="ln-table"><thead><tr><th>Applicant &amp; Channel</th><th>Marketing Plan &amp; Age</th><th>Level</th><th>Status &amp; Hold</th><th>Actions</th></tr></thead><tbody>${affs
            .map((a) => {
              const tier = getAffiliateLevelConfig(a.level || 'bronze', cfg);
              const safeSocial = sanitizeUrl(a.socialLink || '', false);
              const held = Boolean(a.commissionHold || a.withdrawalHold);
              return `
            <tr>
              <td>
                <strong>${escapeHtml(a.name)}</strong> · <span class="mono" style="font-size:11px;">${escapeHtml(a.affiliateCode)}</span>
                <div style="font-size:11px;color:var(--text-muted);">${escapeHtml(a.email)} · ${escapeHtml(a.phone)}</div>
                <div style="font-size:11px;margin-top:3px;">
                  Medium: <strong>${escapeHtml(a.promotionMedium || '—')}</strong> · Followers: <strong>${Number(a.followerCount || 0).toLocaleString()}</strong>
                </div>
                ${
                  safeSocial
                    ? `<a href="${escapeAttr(safeSocial)}" target="_blank" rel="noopener noreferrer" style="font-size:11px;color:var(--gold);word-break:break-all;">${escapeHtml(safeSocial)}</a>`
                    : `<span style="font-size:11px;color:var(--text-muted);">No social URL</span>`
                }
              </td>
              <td style="max-width:240px;">
                <div style="font-size:11px;color:var(--text-muted);margin-bottom:4px;">Age: <strong>${a.age ?? '—'} yrs</strong></div>
                <div style="font-size:12px;line-height:1.45;">${escapeHtml(a.marketingPlan || a.bio || 'No marketing plan provided')}</div>
              </td>
              <td>
                <div style="display:flex;flex-direction:column;gap:5px;min-width:125px;">
                  <span style="font-size:11px;font-weight:700;color:${escapeAttr(tier.badgeColor)};">${escapeHtml(tier.name)} (${Number(tier.commissionRate)}%)</span>
                  <select class="ln-select" data-aff-lvl="${escapeAttr(a.id)}" aria-label="Affiliate Level">
                    ${levels.map((l) => `<option value="${escapeAttr(l.id)}" ${l.id === tier.id ? 'selected' : ''}>${escapeHtml(l.name)} (${Number(l.commissionRate)}%)</option>`).join('')}
                  </select>
                </div>
              </td>
              <td>
                <span class="ln-status ${a.status === 'approved' ? 'ln-status-success' : a.status === 'pending' ? 'ln-status-warning' : 'ln-status-error'}">${escapeHtml(a.status)}</span>
                ${held ? `<div style="margin-top:4px;"><span class="ln-status ln-status-warning">HOLD ACTIVE</span></div>` : ''}
                ${a.rejectionReason ? `<div style="font-size:11px;color:var(--error);margin-top:4px;">${escapeHtml(a.rejectionReason)}</div>` : ''}
              </td>
              <td>
                <div style="display:flex;gap:6px;flex-wrap:wrap;min-width:170px;">
                  ${a.status !== 'approved' ? `<button type="button" class="ln-btn ln-btn-sm" data-aff-st="approved" data-aff-id="${escapeAttr(a.id)}">${a.status === 'suspended' || a.status === 'banned' ? 'Reinstate' : 'Approve'}</button>` : ''}
                  ${a.status === 'pending' ? `<button type="button" class="ln-btn ln-btn-danger ln-btn-sm" data-aff-st="rejected" data-aff-id="${escapeAttr(a.id)}">Reject</button>` : ''}
                  ${a.status === 'approved' ? `<button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-aff-hold="${escapeAttr(a.id)}">${held ? 'Release Hold' : 'Hold'}</button>` : ''}
                  ${a.status === 'approved' ? `<button type="button" class="ln-btn ln-btn-danger ln-btn-sm" data-aff-st="suspended" data-aff-id="${escapeAttr(a.id)}">Suspend</button>` : ''}
                  ${a.status !== 'banned' ? `<button type="button" class="ln-btn ln-btn-danger ln-btn-sm" data-aff-st="banned" data-aff-id="${escapeAttr(a.id)}">Ban</button>` : ''}
                </div>
              </td>
            </tr>`;
            })
            .join('')}</tbody></table></div>`
        : '<div class="ln-empty">No affiliate applications yet.</div>'
    }</div>`;

    body.querySelectorAll('[data-aff-lvl]').forEach((sel) => {
      sel.onchange = () => {
        try {
          adminSetAffiliateLevel(sel.dataset.affLvl, sel.value, actor, { lockManual: false, reason: 'Admin manual tier assignment' });
          showToast('Affiliate level updated', 'success');
          renderAffiliateControl(host, actor);
        } catch (err) {
          showToast(err.message, 'error');
        }
      };
    });

    body.querySelectorAll('[data-aff-hold]').forEach((btn) => {
      btn.onclick = async () => {
        const aff = affs.find((x) => x.id === btn.dataset.affHold);
        if (!aff) return;
        const currentlyHeld = Boolean(aff.commissionHold || aff.withdrawalHold);
        if (currentlyHeld) {
          adminUpdateAffiliateHolds(aff.id, { commissionHold: false, withdrawalHold: false, holdReason: '' }, actor);
          showToast('Affiliate holds released', 'success');
          renderAffiliateControl(host, actor);
          return;
        }
        const reason = await openInputDialog({
          title: `Hold Commissions & Payouts`,
          subtitle: 'Rule #7 Verification Hold',
          message: `Place a temporary hold on ${aff.name} (${aff.affiliateCode}) while reviewing orders or traffic.`,
          label: 'Hold Reason',
          defaultValue: 'Suspicious traffic / order verification',
          confirmLabel: 'Activate Hold',
          danger: true,
        });
        if (!reason) return;
        adminUpdateAffiliateHolds(aff.id, { commissionHold: true, withdrawalHold: true, holdReason: reason }, actor);
        showToast('Commission & withdrawal hold activated', 'success');
        renderAffiliateControl(host, actor);
      };
    });

    body.querySelectorAll('[data-aff-st]').forEach((b) => {
      b.onclick = async () => {
        const nextSt = b.dataset.affSt;
        let reason = '';
        if (['rejected', 'suspended', 'banned'].includes(nextSt)) {
          const entered = await openInputDialog({
            title: `${nextSt.charAt(0).toUpperCase() + nextSt.slice(1)} Affiliate`,
            subtitle: 'Rule #8 & #9 Enforcement',
            message: 'Provide a clear reason shown to the partner.',
            label: 'Reason',
            defaultValue: nextSt === 'banned' ? 'Severe policy violation' : 'Policy review',
            confirmLabel: `Confirm ${nextSt.toUpperCase()}`,
            danger: true,
          });
          if (entered === null) return;
          reason = entered;
        }
        updateAffiliateStatus(b.dataset.affId, nextSt, actor, reason);
        showToast(`Affiliate marked ${nextSt}`, 'success');
        renderAffiliateControl(host, actor);
      };
    });
  } else if (state.affiliateSubTab === 'commissions') {
    body.innerHTML = `<div class="ln-card">${
      comms.length
        ? `<div class="ln-table-wrap"><table class="ln-table"><thead><tr><th>Order</th><th>Affiliate</th><th>Level Rate</th><th>Sale</th><th>Commission</th><th>Status</th><th>Action</th></tr></thead><tbody>${comms
            .map(
              (c) => `
            <tr>
              <td class="mono">${escapeHtml(c.orderId)}</td>
              <td>${escapeHtml(c.affiliateName)}</td>
              <td>${escapeHtml(String(c.affiliateLevel || 'bronze').toUpperCase())} (${Number(c.commissionRateApplied || 8)}%)</td>
              <td class="tabular">${money(c.orderTotal)}</td>
              <td class="tabular"><strong>${money(c.commissionAmount)}</strong></td>
              <td><span class="ln-status ${c.status === 'approved' || c.status === 'paid' ? 'ln-status-success' : c.status === 'pending' || c.status === 'held' ? 'ln-status-warning' : 'ln-status-error'}">${escapeHtml(c.status)}</span></td>
              <td>
                <div style="display:flex;gap:6px;flex-wrap:wrap;">
                  ${['pending', 'held'].includes(c.status) ? `<button type="button" class="ln-btn ln-btn-sm" data-com-act="approved" data-com-id="${escapeAttr(c.id)}">Approve</button>` : ''}
                  ${['pending', 'approved'].includes(c.status) ? `<button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-com-act="held" data-com-id="${escapeAttr(c.id)}">Hold</button>` : ''}
                  ${c.status !== 'reversed' && c.status !== 'paid' ? `<button type="button" class="ln-btn ln-btn-danger ln-btn-sm" data-com-act="reversed" data-com-id="${escapeAttr(c.id)}">Reverse</button>` : ''}
                </div>
              </td>
            </tr>`
            )
            .join('')}</tbody></table></div>`
        : '<div class="ln-empty">No affiliate commissions yet.</div>'
    }</div>`;

    body.querySelectorAll('[data-com-act]').forEach((b) => {
      b.onclick = async () => {
        let reason = '';
        if (b.dataset.comAct === 'held' || b.dataset.comAct === 'reversed') {
          const entered = await openInputDialog({
            title: b.dataset.comAct === 'held' ? 'Hold Commission' : 'Reverse Commission',
            subtitle: 'Commission Audit',
            label: 'Reason',
            defaultValue: b.dataset.comAct === 'held' ? 'Verification hold' : 'Order policy review',
            confirmLabel: 'Confirm',
            danger: true,
          });
          if (entered === null) return;
          reason = entered;
        }
        adminOverrideCommissionStatus(b.dataset.comId, b.dataset.comAct, actor, reason);
        showToast(`Commission ${b.dataset.comAct}`, 'success');
        renderAffiliateControl(host, actor);
      };
    });
  } else if (state.affiliateSubTab === 'withdrawals') {
    body.innerHTML = `<div class="ln-card">${
      withdrawals.length
        ? `<div class="ln-table-wrap"><table class="ln-table"><thead><tr><th>ID</th><th>Affiliate</th><th>Method</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead><tbody>${withdrawals
            .map(
              (w) => `
            <tr>
              <td class="mono">${escapeHtml(w.id)}</td>
              <td>${escapeHtml(w.affiliateName)}</td>
              <td>${escapeHtml(w.method)} · ${escapeHtml(w.accountNumber)}</td>
              <td class="tabular"><strong>${money(w.amount)}</strong></td>
              <td><span class="ln-status ${w.status === 'paid' || w.status === 'approved' ? 'ln-status-success' : w.status === 'pending' || w.status === 'held' ? 'ln-status-warning' : 'ln-status-error'}">${escapeHtml(w.status)}</span> ${w.transactionId ? `<div class="mono" style="font-size:11px;">${escapeHtml(w.transactionId)}</div>` : ''}</td>
              <td>
                <div style="display:flex;gap:6px;flex-wrap:wrap;">
                  ${['pending', 'held'].includes(w.status) ? `<button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-w-act="approved" data-w-id="${escapeAttr(w.id)}">Approve</button>` : ''}
                  ${['pending', 'approved'].includes(w.status) ? `<button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-w-act="held" data-w-id="${escapeAttr(w.id)}">Hold</button>` : ''}
                  ${['pending', 'approved', 'processing'].includes(w.status) ? `<button type="button" class="ln-btn ln-btn-gold ln-btn-sm" data-w-act="paid" data-w-id="${escapeAttr(w.id)}">Mark Paid</button>` : ''}
                  ${['pending', 'approved', 'held'].includes(w.status) ? `<button type="button" class="ln-btn ln-btn-danger ln-btn-sm" data-w-act="rejected" data-w-id="${escapeAttr(w.id)}">Reject</button>` : ''}
                </div>
              </td>
            </tr>`
            )
            .join('')}</tbody></table></div>`
        : '<div class="ln-empty">No withdrawal requests yet.</div>'
    }</div>`;

    body.querySelectorAll('[data-w-act]').forEach((b) => {
      b.onclick = async () => {
        try {
          let tx = '';
          let ref = '';
          let rejReason = '';
          if (b.dataset.wAct === 'paid') {
            const enteredTx = await openInputDialog({
              title: 'Complete Payout',
              subtitle: 'Enter Transaction Reference',
              label: 'Payout Transaction ID *',
              defaultValue: `TX-${Date.now().toString().slice(-6)}`,
              confirmLabel: 'Mark Paid',
            });
            if (!enteredTx) return;
            tx = enteredTx;
            ref = 'Verified Payout';
          } else if (b.dataset.wAct === 'held' || b.dataset.wAct === 'rejected') {
            const enteredReason = await openInputDialog({
              title: b.dataset.wAct === 'held' ? 'Hold Withdrawal' : 'Reject Withdrawal',
              subtitle: 'Rule #7 / #9 Review',
              label: 'Reason',
              defaultValue: b.dataset.wAct === 'held' ? 'Pending order verification hold' : 'Rejected by Admin',
              confirmLabel: 'Confirm',
              danger: true,
            });
            if (enteredReason === null) return;
            rejReason = enteredReason;
          }
          adminProcessWithdrawal(
            b.dataset.wId,
            { status: b.dataset.wAct, transactionId: tx, paymentReference: ref, rejectionReason: rejReason },
            actor
          );
          showToast(`Withdrawal marked ${b.dataset.wAct}`, 'success');
          renderAffiliateControl(host, actor);
        } catch (err) {
          showToast(err.message, 'error');
        }
      };
    });
  } else if (state.affiliateSubTab === 'rules') {
    const aCfg = cfg.affiliateConfig || {};
    body.innerHTML = `
      <div class="ln-card" style="margin-bottom:14px;">
        <h3 style="font-size:16px;margin-bottom:12px;">Program Availability, Eligibility Gate &amp; Commission Settings</h3>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px;margin-bottom:12px;">
          <div class="ln-field"><label>Default Fallback Rate</label><input id="afDefRate" type="number" class="ln-input" value="${Number(aCfg.defaultRate ?? 8)}" /></div>
          <div class="ln-field"><label>Rate Type</label><select id="afRateType" class="ln-select"><option value="percentage" ${aCfg.rateType === 'percentage' ? 'selected' : ''}>Percentage (%)</option><option value="fixed" ${aCfg.rateType === 'fixed' ? 'selected' : ''}>Fixed Amount</option></select></div>
          <div class="ln-field"><label>Link Expiry Duration (Hours)</label><input id="afExpHrs" type="number" class="ln-input" value="${Number(aCfg.linkExpiryHours ?? 168)}" /></div>
          <div class="ln-field"><label>Minimum Withdrawal (BDT)</label><input id="afMinW" type="number" class="ln-input" value="${Number(aCfg.minWithdrawal ?? 500)}" /></div>
          <div class="ln-field"><label>Min Account Age (Hours)</label><input id="afMinAgeHrs" type="number" min="0" class="ln-input" value="${Number(aCfg.minAccountAgeHours ?? 72)}" /></div>
          <div class="ln-field"><label>Min Applicant Age (Years)</label><input id="afMinUserAge" type="number" min="13" class="ln-input" value="${Number(aCfg.minApplicantAge ?? 18)}" /></div>
          <div class="ln-field"><label>Reject Cooldown (Hours)</label><input id="afCooldownHrs" type="number" min="0" class="ln-input" value="${Number(aCfg.reapplyCooldownHours ?? 168)}" /></div>
          <div class="ln-field"><label>Downgrade Window (Days)</label><input id="afDowngradeDays" type="number" min="1" class="ln-input" value="${Number(aCfg.downgradeWindowDays ?? 30)}" /></div>
        </div>
        <div style="display:flex;gap:14px;flex-wrap:wrap;font-size:12px;margin-bottom:14px;">
          <label style="display:flex;align-items:center;gap:6px;"><input type="checkbox" id="afEnabled" ${aCfg.enabled !== false ? 'checked' : ''} /> Program Enabled</label>
          <label style="display:flex;align-items:center;gap:6px;"><input type="checkbox" id="afReqEmail" ${aCfg.requireEmailVerification !== false ? 'checked' : ''} /> Require Verified Email</label>
          <label style="display:flex;align-items:center;gap:6px;"><input type="checkbox" id="afReqPhone" ${aCfg.requirePhoneVerification !== false ? 'checked' : ''} /> Require Verified Mobile</label>
          <label style="display:flex;align-items:center;gap:6px;"><input type="checkbox" id="afReqProfile" ${aCfg.requireCompleteProfile !== false ? 'checked' : ''} /> Require Complete Profile</label>
          <label style="display:flex;align-items:center;gap:6px;"><input type="checkbox" id="afReqSocial" ${aCfg.requireSocialOrWebsite !== false ? 'checked' : ''} /> Require Social / Website</label>
          <label style="display:flex;align-items:center;gap:6px;"><input type="checkbox" id="afAutoUp" ${aCfg.autoUpgradeEnabled !== false ? 'checked' : ''} /> Auto Upgrade Levels</label>
          <label style="display:flex;align-items:center;gap:6px;"><input type="checkbox" id="afAutoDown" ${aCfg.autoDowngradeEnabled !== false ? 'checked' : ''} /> Auto Downgrade on Drop</label>
        </div>

        <h4 style="font-size:14px;color:var(--gold);margin:14px 0 8px;">Affiliate Level Tiers Editor (Bronze · Silver · Gold · Diamond)</h4>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:10px;margin-bottom:14px;">
          ${levels
            .map(
              (lvl) => `
            <div class="ln-card" style="background:var(--surface-alt);border-color:${escapeAttr(lvl.badgeColor)};padding:12px;" data-tier-edit="${escapeAttr(lvl.id)}">
              <div style="font-weight:700;color:${escapeAttr(lvl.badgeColor)};margin-bottom:8px;">${escapeHtml(lvl.name)} Level</div>
              <div class="ln-field" style="margin-bottom:6px;"><label>Commission Rate (%)</label><input type="number" step="0.5" class="ln-input" data-tf="commissionRate" value="${Number(lvl.commissionRate)}" /></div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;">
                <div class="ln-field" style="margin-bottom:6px;"><label>Upgrade Orders</label><input type="number" class="ln-input" data-tf="minOrders" value="${Number(lvl.minOrders)}" /></div>
                <div class="ln-field" style="margin-bottom:6px;"><label>Upgrade Sales</label><input type="number" class="ln-input" data-tf="minSales" value="${Number(lvl.minSales)}" /></div>
                <div class="ln-field" style="margin-bottom:6px;"><label>Retain Orders</label><input type="number" class="ln-input" data-tf="retainOrdersInWindow" value="${Number(lvl.retainOrdersInWindow)}" /></div>
                <div class="ln-field" style="margin-bottom:6px;"><label>Retain Sales</label><input type="number" class="ln-input" data-tf="retainSalesInWindow" value="${Number(lvl.retainSalesInWindow)}" /></div>
              </div>
              <div class="ln-field" style="margin-bottom:0;"><label>Benefits (one per line)</label><textarea class="ln-textarea" style="min-height:60px;" data-tf="benefits">${escapeHtml((lvl.benefits || []).join('\n'))}</textarea></div>
            </div>`
            )
            .join('')}
        </div>

        <button type="button" class="ln-btn ln-btn-gold" id="btnSaveAffRules">Save All Affiliate Level &amp; Program Settings</button>
      </div>

      <div class="ln-card">
        <h3 style="font-size:16px;margin-bottom:8px;">10 Enforced Affiliate Program Rules (Active Policy)</h3>
        ${AFFILIATE_PROGRAM_RULES.map((r) => `<div style="padding:7px 0;border-bottom:1px solid var(--border);font-size:12px;"><strong>${r.id}. ${escapeHtml(r.title)}</strong><div style="color:var(--text-muted);">${escapeHtml(r.description)}</div></div>`).join('')}
      </div>
    `;

    $('btnSaveAffRules').onclick = () => {
      const updatedLevels = levels.map((lvl) => {
        const card = body.querySelector(`[data-tier-edit="${lvl.id}"]`);
        if (!card) return lvl;
        const getVal = (field) => card.querySelector(`[data-tf="${field}"]`)?.value ?? '';
        return {
          ...lvl,
          commissionRate: Math.max(0, Number(getVal('commissionRate') || lvl.commissionRate)),
          minOrders: Math.max(0, Math.floor(Number(getVal('minOrders') || 0))),
          minSales: Math.max(0, Number(getVal('minSales') || 0)),
          retainOrdersInWindow: Math.max(0, Math.floor(Number(getVal('retainOrdersInWindow') || 0))),
          retainSalesInWindow: Math.max(0, Number(getVal('retainSalesInWindow') || 0)),
          benefits: String(getVal('benefits'))
            .split('\n')
            .map((s) => s.trim())
            .filter(Boolean),
        };
      });

      const isEnabled = $('afEnabled').checked;
      updatePlatformConfig(
        {
          platformFlags: { ...cfg.platformFlags, affiliateProgramEnabled: isEnabled },
          affiliateConfig: {
            ...aCfg,
            enabled: isEnabled,
            defaultRate: Number($('afDefRate').value),
            rateType: $('afRateType').value,
            linkExpiryHours: Number($('afExpHrs').value),
            minWithdrawal: Number($('afMinW').value),
            minAccountAgeHours: Number($('afMinAgeHrs').value),
            minApplicantAge: Number($('afMinUserAge').value),
            reapplyCooldownHours: Number($('afCooldownHrs').value),
            downgradeWindowDays: Number($('afDowngradeDays').value),
            requireEmailVerification: $('afReqEmail').checked,
            requirePhoneVerification: $('afReqPhone').checked,
            requireCompleteProfile: $('afReqProfile').checked,
            requireSocialOrWebsite: $('afReqSocial').checked,
            autoUpgradeEnabled: $('afAutoUp').checked,
            autoDowngradeEnabled: $('afAutoDown').checked,
            levels: updatedLevels,
          },
        },
        actor
      );
      showToast('Affiliate levels, eligibility & commission rules saved', 'success');
      renderAffiliateControl(host, actor);
    };
  } else {
    body.innerHTML = `<div class="ln-card">${
      board.length
        ? `<div class="ln-table-wrap"><table class="ln-table"><thead><tr><th>Rank</th><th>Partner</th><th>Level</th><th>Clicks</th><th>Orders</th><th>Sales</th><th>Commission</th></tr></thead><tbody>${board
            .map((r, i) => `<tr><td>#${i + 1}</td><td><strong>${escapeHtml(r.name)}</strong> (${escapeHtml(r.affiliateCode)})</td><td><span style="color:${escapeAttr(r.levelBadgeColor)};font-weight:700;">${escapeHtml(r.levelName)} (${Number(r.commissionRate)}%)</span></td><td class="tabular">${r.clicks}</td><td class="tabular">${r.orders}</td><td class="tabular">${money(r.totalSales)}</td><td class="tabular"><strong>${money(r.totalCommission)}</strong></td></tr>`)
            .join('')}</tbody></table></div>`
        : '<div class="ln-empty">No affiliate sales data yet.</div>'
    }</div>`;
  }
}

function renderRoleMatrix(host, actor) {
  const cfg = getPlatformConfig();
  const matrix = structuredClone(cfg.rolePermissions || DEFAULT_ROLE_MATRIX);
  const canEdit = actor.role === ROLES.SUPER_ADMIN;

  host.innerHTML = `
    <div class="ln-card">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:12px;">
        <div>
          <h3 style="font-size:16px;">Role &amp; Permission Matrix (11 Roles × 11 Permissions)</h3>
          <p style="font-size:12px;color:var(--text-muted);">${canEdit ? 'Super Admin permissions are locked for maximum security.' : 'Read-only view. Only Super Admin may modify role permissions.'}</p>
        </div>
        ${canEdit ? `<button type="button" class="ln-btn ln-btn-gold ln-btn-sm" id="btnSaveMatrix">Save Role Matrix</button>` : ''}
      </div>
      <div class="ln-table-wrap">
        <table class="ln-table">
          <thead><tr><th>Role</th>${PERMISSIONS.map((p) => `<th style="font-size:10px;">${escapeHtml(p.replace('_', ' '))}</th>`).join('')}</tr></thead>
          <tbody>
            ${Object.values(ROLES)
              .map((role) => {
                const list = matrix[role] || DEFAULT_ROLE_MATRIX[role] || [];
                const editable = canModifyRoleMatrix(actor.role, role);
                return `
                <tr>
                  <td><strong>${escapeHtml(ROLE_LABELS[role] || role)}</strong></td>
                  ${PERMISSIONS.map(
                    (perm) => `<td><input type="checkbox" data-rm-role="${role}" data-rm-perm="${perm}" ${list.includes(perm) ? 'checked' : ''} ${editable ? '' : 'disabled'} /></td>`
                  ).join('')}
                </tr>`;
              })
              .join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;

  const saveBtn = $('btnSaveMatrix');
  if (saveBtn) {
    saveBtn.onclick = () => {
      document.querySelectorAll('[data-rm-role]').forEach((el) => {
        const r = el.dataset.rmRole;
        const p = el.dataset.rmPerm;
        if (!canModifyRoleMatrix(actor.role, r)) return;
        matrix[r] = matrix[r] || [];
        if (el.checked && !matrix[r].includes(p)) matrix[r].push(p);
        if (!el.checked) matrix[r] = matrix[r].filter((x) => x !== p);
      });
      updatePlatformConfig({ rolePermissions: matrix }, actor);
      showToast('Role permissions matrix updated', 'success');
    };
  }
}

function renderUpdateManager(host, actor) {
  const releases = listReleases();
  const activeRel = releases.find((r) => r.status === 'active') || releases[0];

  host.innerHTML = `
    <div class="ln-card" style="margin-bottom:14px;">
      <h3 style="font-size:16px;margin-bottom:4px;">Publish App Release (Current Active: v${escapeHtml(activeRel?.version || '2.0.0')})</h3>
      <p style="font-size:12px;color:var(--text-muted);margin-bottom:12px;">Publishes versioned release metadata with SHA-256 manifest verification and triggers the Update Popup in User App.</p>
      <div class="adm-grid-2">
        <div class="ln-field"><label>New Semantic Version *</label><input id="updVer" class="ln-input" placeholder="e.g. 2.1.0" /></div>
        <div class="ln-field"><label>Min Supported Version *</label><input id="updMinVer" class="ln-input" value="1.0.0" /></div>
      </div>
      <div class="ln-field"><label>Release Notes *</label><textarea id="updNotes" class="ln-textarea" placeholder="Summary of enhancements and fixes..."></textarea></div>
      <div class="ln-field"><label>What's New (one item per line)</label><textarea id="updWhatsNew" class="ln-textarea" placeholder="Improved checkout speed&#10;Enhanced affiliate QR sharing"></textarea></div>
      <label style="display:flex;align-items:center;gap:8px;font-size:12px;margin-bottom:12px;"><input type="checkbox" id="updMandatory" /> Mandatory Update (blocks older versions)</label>
      <button type="button" class="ln-btn ln-btn-gold" id="btnPublishRel">Publish Release</button>
    </div>

    <div class="ln-card">
      <h3 style="font-size:16px;margin-bottom:10px;">Release History &amp; Rollback</h3>
      <div class="ln-table-wrap">
        <table class="ln-table">
          <thead><tr><th>Version</th><th>Date</th><th>Min Support</th><th>Mandatory</th><th>Integrity Hash</th><th>Status</th><th>Action</th></tr></thead>
          <tbody>
            ${releases
              .map(
                (r) => `
              <tr>
                <td class="mono"><strong>v${escapeHtml(r.version)}</strong></td>
                <td>${escapeHtml(r.releaseDate)}</td>
                <td class="mono">v${escapeHtml(r.minSupportedVersion)}</td>
                <td>${r.mandatory ? 'Yes' : 'Optional'}</td>
                <td class="mono" style="font-size:11px;">${escapeHtml((r.checksum || 'baseline').slice(0, 12))}</td>
                <td>${escapeHtml(r.status)}</td>
                <td>${r.version !== activeRel?.version ? `<button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-rollback="${escapeAttr(r.version)}">Rollback Here</button>` : '<span style="font-size:11px;color:var(--success);font-weight:700;">Live</span>'}</td>
              </tr>`
              )
              .join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;

  $('btnPublishRel').onclick = async () => {
    try {
      await publishRelease(
        {
          version: $('updVer').value,
          minSupportedVersion: $('updMinVer').value,
          releaseNotes: $('updNotes').value,
          whatsNew: $('updWhatsNew').value,
          mandatory: $('updMandatory').checked,
        },
        actor
      );
      showToast('Release published & manifest checksum generated', 'success');
      renderUpdateManager(host, actor);
    } catch (err) {
      showToast(err.message, 'error');
    }
  };
  host.querySelectorAll('[data-rollback]').forEach((b) => {
    b.onclick = async () => {
      const ok = await openConfirmDialog({ title: 'Rollback Release', message: `Roll back active release to v${b.dataset.rollback}?`, confirmLabel: 'Rollback', danger: true });
      if (!ok) return;
      rollbackRelease(b.dataset.rollback, actor);
      showToast(`Rolled back to v${b.dataset.rollback}`, 'success');
      renderUpdateManager(host, actor);
    };
  });
}

function renderPlatformSettings(host, actor) {
  const cfg = getPlatformConfig();
  const pf = cfg.platformFlags || {};
  const intl = cfg.international || {};

  host.innerHTML = `
    <div class="ln-card" style="margin-bottom:14px;">
      <h3 style="font-size:16px;margin-bottom:12px;">Platform Governance &amp; International Settings</h3>
      <div style="display:grid;gap:10px;margin-bottom:16px;">
        <label style="font-size:13px;"><input type="checkbox" id="pfReg" ${pf.registrationEnabled !== false ? 'checked' : ''} /> Allow Customer Registration</label>
        <label style="font-size:13px;"><input type="checkbox" id="pfSelReg" ${pf.sellerRegistrationEnabled !== false ? 'checked' : ''} /> Allow Seller Registration</label>
        <label style="font-size:13px;"><input type="checkbox" id="pfAff" ${pf.affiliateProgramEnabled !== false ? 'checked' : ''} /> Affiliate Program Enabled</label>
        <label style="font-size:13px;"><input type="checkbox" id="pfProdApp" ${pf.productApprovalRequired !== false ? 'checked' : ''} /> Require Admin Approval for Seller Products</label>
        <label style="font-size:13px;color:var(--error);font-weight:700;"><input type="checkbox" id="pfMaint" ${pf.maintenanceMode ? 'checked' : ''} /> Enable Platform Maintenance Mode</label>
      </div>
      <div class="ln-field"><label>Maintenance Message</label><input id="pfMaintMsg" class="ln-input" value="${escapeAttr(pf.maintenanceMessage || '')}" /></div>

      <h4 style="margin:14px 0 8px;">Default Internationalization &amp; Currency Rates (vs 1 BDT)</h4>
      <div class="adm-grid-2">
        <div class="ln-field"><label>Default Language</label><select id="pfLang" class="ln-select"><option value="en" ${intl.language === 'en' ? 'selected' : ''}>English</option><option value="bn" ${intl.language === 'bn' ? 'selected' : ''}>Bengali (বাংলা)</option></select></div>
        <div class="ln-field"><label>Default Currency</label><select id="pfCurr" class="ln-select"><option value="BDT" ${intl.currency === 'BDT' ? 'selected' : ''}>BDT</option><option value="USD" ${intl.currency === 'USD' ? 'selected' : ''}>USD</option><option value="EUR" ${intl.currency === 'EUR' ? 'selected' : ''}>EUR</option><option value="GBP" ${intl.currency === 'GBP' ? 'selected' : ''}>GBP</option></select></div>
        <div class="ln-field"><label>USD Rate</label><input id="pfUsd" type="number" step="0.0001" class="ln-input" value="${Number(intl.exchangeRates?.USD || 0.0084)}" /></div>
        <div class="ln-field"><label>EUR Rate</label><input id="pfEur" type="number" step="0.0001" class="ln-input" value="${Number(intl.exchangeRates?.EUR || 0.0078)}" /></div>
      </div>
      <button type="button" class="ln-btn ln-btn-gold" id="btnSavePfSettings">Save Platform Settings</button>
    </div>

    <div class="ln-card">
      <h3 style="font-size:16px;margin-bottom:8px;">Full Ecosystem Data Backup &amp; Firebase Readiness</h3>
      <p style="font-size:12px;color:var(--text-muted);margin-bottom:12px;">Current Mode: <strong>Local Development Adapter</strong> · Future Target: <span class="mono">fliex-price (default)</span> (Not connected)</p>
      <div style="display:flex;gap:10px;flex-wrap:wrap;">
        <button type="button" class="ln-btn ln-btn-outline" id="btnExportAllBackup">Export Full Ecosystem JSON</button>
        <label class="ln-btn ln-btn-outline" style="cursor:pointer;">Import Ecosystem Backup<input id="inpImportAllBackup" type="file" accept="application/json" hidden /></label>
      </div>
    </div>
  `;

  $('btnSavePfSettings').onclick = () => {
    updatePlatformConfig(
      {
        platformFlags: {
          registrationEnabled: $('pfReg').checked,
          sellerRegistrationEnabled: $('pfSelReg').checked,
          affiliateProgramEnabled: $('pfAff').checked,
          productApprovalRequired: $('pfProdApp').checked,
          maintenanceMode: $('pfMaint').checked,
          maintenanceMessage: $('pfMaintMsg').value,
        },
        international: {
          ...intl,
          language: $('pfLang').value,
          currency: $('pfCurr').value,
          exchangeRates: {
            BDT: 1,
            USD: Number($('pfUsd').value || 0.0084),
            EUR: Number($('pfEur').value || 0.0078),
            GBP: Number(intl.exchangeRates?.GBP || 0.0066),
          },
        },
      },
      actor
    );
    showToast('Platform settings saved', 'success');
  };

  $('btnExportAllBackup').onclick = () => downloadFile('luxe-nexus-ecosystem-backup.json', JSON.stringify(appServices.storage.exportAllCollections(), null, 2));
  $('inpImportAllBackup').onchange = (ev) => {
    const f = ev.target.files?.[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = () => {
      try {
        appServices.storage.importAllCollections(JSON.parse(String(r.result)));
        recordAuditLog({ actorId: actor.uid, actorRole: actor.role, action: 'IMPORT_BACKUP', targetCollection: 'all', targetId: 'backup' });
        showToast('Ecosystem backup imported', 'success');
        renderApp();
      } catch (err) {
        showToast(err.message, 'error');
      }
    };
    r.readAsText(f);
  };
}

function updateNotifCount() {
  $('admNotifCount').textContent = String(getUnreadCount('admin'));
}

function renderApp() {
  ensureEcosystemSeeded();
  if (localStorage.getItem('ln_theme_variant') === 'light') document.body.classList.add('light-atelier');
  const cfg = getPlatformConfig();
  applyDesignTokensToDocument(cfg);
  const logoSrc = sanitizeUrl(cfg.logo, true) || OFFICIAL_LOGO_URL;
  if ($('admGateLogoImg')) $('admGateLogoImg').src = logoSrc;
  if ($('admSidebarLogoImg')) $('admSidebarLogoImg').src = logoSrc;
  initLuxurySelectObserver();
  if (!renderAuthGate()) return;
  renderSidebarAndTabs();
  renderSection();
  updateNotifCount();
}

$('btnAdmTheme').onclick = () => {
  document.body.classList.toggle('light-atelier');
  localStorage.setItem('ln_theme_variant', document.body.classList.contains('light-atelier') ? 'light' : 'dark');
  applyDesignTokensToDocument(getPlatformConfig());
};
$('btnAdmNotifs').onclick = () => renderNotificationModal({ audience: 'admin', userId: '', onUpdated: updateNotifCount });
$('btnAdminLogout').onclick = () => {
  logoutAccount('admin');
  showToast('Signed out of Admin Studio');
  renderAuthGate();
};

appServices.orders.subscribe(() => { if (getActiveUser('admin')) renderSection(); });
appServices.sellers.subscribe(() => { if (getActiveUser('admin')) renderSection(); });
appServices.affiliates.affiliates.subscribe(() => { if (getActiveUser('admin')) renderSection(); });
appServices.notifications.subscribe(updateNotifCount);

renderApp();
