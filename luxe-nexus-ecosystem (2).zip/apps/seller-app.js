/**
 * LUXE NEXUS Seller Portal Controller
 * Enforces Admin Approval Gate, Strict Seller Data Isolation,
 * 24-Field Product Studio, Stock & Order Fulfillment, and Revenue Reports.
 */

import { appServices } from '../adapters/backend-adapter.js';
import { ensureEcosystemSeeded, getPlatformConfig, getFeatureStatus, applyDesignTokensToDocument } from '../services/settings-service.js';
import { signupAccount, loginAccount, getActiveUser, logoutAccount, updateAccountProfile } from '../services/auth-service.js';
import { listSellerProducts, saveProduct, deleteProduct, listCategories } from '../services/product-service.js';
import { listOrdersForSeller, updateOrderStatus, ORDER_STATUSES } from '../services/order-service.js';
import { getUnreadCount } from '../services/notification-service.js';
import { evaluatePasswordStrength } from '../shared/validators.js';
import { escapeHtml, escapeAttr, formatMoney, formatDateTime, sanitizeUrl, roundMoney, toCsv } from '../shared/utilities.js';
import { ROLES } from '../shared/permissions.js';
import { OFFICIAL_LOGO_URL } from '../shared/configuration.js';
import { showToast, renderNotificationModal, openConfirmDialog, initLuxurySelectObserver } from '../shared/shared-components.js';

const $ = (id) => document.getElementById(id);

const state = {
  activeTab: 'home',
  authMode: 'login',
  editingProductId: '',
};

function money(val) {
  const cfg = getPlatformConfig();
  return formatMoney(val, cfg.international?.currency || 'BDT', cfg.international?.exchangeRates || {});
}

function renderAuthGate() {
  const gate = $('sellerAuthGate');
  const seller = getActiveUser('seller');
  if (seller) {
    gate.style.display = 'none';
    $('selStoreTitle').textContent = seller.storeName || seller.name || 'LUXE NEXUS Seller';
    return true;
  }

  gate.style.display = 'flex';
  const host = $('selAuthFormArea');
  const isSignup = state.authMode === 'signup';
  const regFlag = getFeatureStatus('sellerRegistration', 'seller');

  host.innerHTML = `
    <div style="display:flex;gap:8px;margin-bottom:14px;">
      <button type="button" class="ln-btn ln-btn-sm ${!isSignup ? '' : 'ln-btn-outline'}" id="tabSelLogin" style="flex:1;">Sign In</button>
      <button type="button" class="ln-btn ln-btn-sm ${isSignup ? '' : 'ln-btn-outline'}" id="tabSelSignup" style="flex:1;">Apply as Seller</button>
    </div>
    ${
      isSignup && !regFlag.enabled
        ? `<div class="ln-empty"><p>${escapeHtml(regFlag.maintenanceMessage)}</p></div>`
        : `
      ${isSignup ? `<div class="ln-field"><label>Owner Full Name *</label><input id="selName" class="ln-input" /></div>` : ''}
      ${isSignup ? `<div class="ln-field"><label>Store Name *</label><input id="selStore" class="ln-input" /></div>` : ''}
      ${isSignup ? `<div class="ln-field"><label>Phone Number *</label><input id="selPhone" type="tel" class="ln-input" placeholder="01XXXXXXXXX" /></div>` : ''}
      <div class="ln-field"><label>Email Address *</label><input id="selEmail" type="email" class="ln-input" /></div>
      <div class="ln-field">
        <label>Password *</label>
        <div style="display:flex;gap:6px;">
          <input id="selPass" type="password" class="ln-input" />
          <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="btnSelShowPass">Show</button>
        </div>
        ${isSignup ? `<div id="selPassStrength" style="font-size:11px;color:var(--text-muted);margin-top:4px;"></div>` : ''}
      </div>
      ${isSignup ? `<div class="ln-field"><label>Confirm Password *</label><input id="selConfPass" type="password" class="ln-input" /></div>` : ''}
      <button type="button" class="ln-btn ln-btn-gold" id="btnSelSubmit" style="width:100%;">${isSignup ? 'Submit Seller Application' : 'Sign In to Store'}</button>
      <div id="selAuthMsg" style="margin-top:10px;font-size:12px;color:var(--gold);text-align:center;"></div>
    `
    }
  `;

  $('tabSelLogin').onclick = () => { state.authMode = 'login'; renderAuthGate(); };
  $('tabSelSignup').onclick = () => { state.authMode = 'signup'; renderAuthGate(); };
  const showBtn = $('btnSelShowPass');
  if (showBtn) {
    showBtn.onclick = () => {
      const inp = $('selPass');
      const hide = inp.type === 'password';
      inp.type = hide ? 'text' : 'password';
      showBtn.textContent = hide ? 'Hide' : 'Show';
    };
  }
  if (isSignup && $('selPass')) {
    $('selPass').oninput = () => {
      $('selPassStrength').textContent = `Strength: ${evaluatePasswordStrength($('selPass').value).label}`;
    };
  }
  const submitBtn = $('btnSelSubmit');
  if (submitBtn) {
    submitBtn.onclick = async () => {
      try {
        if (isSignup) {
          await signupAccount({
            name: $('selName').value,
            storeName: $('selStore').value,
            phone: $('selPhone').value,
            email: $('selEmail').value,
            password: $('selPass').value,
            confirmPassword: $('selConfPass').value,
            role: ROLES.SELLER,
          });
          $('selAuthMsg').textContent = 'Application submitted! Admin must approve your store before you can sign in.';
          showToast('Seller application submitted (Pending Admin Approval)', 'success');
        } else {
          await loginAccount({ email: $('selEmail').value, password: $('selPass').value, appScope: 'seller' });
          showToast('Signed in to Seller Portal', 'success');
          renderApp();
        }
      } catch (err) {
        $('selAuthMsg').textContent = err.message;
        showToast(err.message, 'error');
      }
    };
  }
  return false;
}

function renderTab() {
  const seller = getActiveUser('seller');
  if (!seller) return;
  const host = $('selContent');
  document.querySelectorAll('#selTabs .sel-tab-btn').forEach((b) => {
    b.classList.toggle('active', b.dataset.tab === state.activeTab);
  });

  if (state.activeTab === 'home') return renderHome(host, seller);
  if (state.activeTab === 'products') return renderProductStudio(host, seller);
  if (state.activeTab === 'orders') return renderSellerOrders(host, seller);
  if (state.activeTab === 'reports') return renderSellerReports(host, seller);
  if (state.activeTab === 'profile') return renderSellerProfile(host, seller);
}

function renderHome(host, seller) {
  const myProducts = listSellerProducts(seller.uid);
  const myOrders = listOrdersForSeller(seller.uid);
  const deliveredSales = roundMoney(
    myOrders.filter((o) => o.status === 'Delivered').reduce((s, o) => s + Number(o.sellerSubtotal || 0), 0)
  );
  const cfg = getPlatformConfig();
  const feePct = Number(cfg.checkout?.platformFeePercent ?? 10);
  const netPayout = roundMoney(deliveredSales * (1 - feePct / 100));

  host.innerHTML = `
    <div class="sel-kpi-grid">
      <div class="sel-kpi"><small>My Products</small><strong>${myProducts.length}</strong></div>
      <div class="sel-kpi"><small>Pending Approval</small><strong>${myProducts.filter((p) => !p.approved).length}</strong></div>
      <div class="sel-kpi"><small>Store Orders</small><strong>${myOrders.length}</strong></div>
      <div class="sel-kpi"><small>Delivered Sales</small><strong>${money(deliveredSales)}</strong></div>
      <div class="sel-kpi"><small>Est. Net Payout (${100 - feePct}%)</small><strong style="color:var(--success);">${money(netPayout)}</strong></div>
    </div>

    <div class="ln-card" style="margin-bottom:14px;">
      <h3 style="font-size:16px;margin-bottom:6px;">Store Isolation &amp; Operations</h3>
      <p style="font-size:13px;color:var(--text-muted);margin-bottom:12px;">You are viewing only <strong>${escapeHtml(seller.storeName || seller.name)}</strong> products and orders. Affiliate commission approvals and payouts remain centrally governed by Admin.</p>
      <button type="button" class="ln-btn ln-btn-gold" id="btnSelNewProd">+ Create Product Listing</button>
    </div>

    <div class="ln-card">
      <h3 style="font-size:16px;margin-bottom:10px;">Recent Store Orders</h3>
      ${
        myOrders.length
          ? myOrders.slice(0, 5).map((o) => `<div style="display:flex;justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--border);font-size:13px;"><span><strong class="mono">#${escapeHtml(o.id)}</strong> · ${escapeHtml(o.customer?.name)}</span><span class="ln-status ln-status-info">${escapeHtml(o.status)} · ${money(o.sellerSubtotal)}</span></div>`).join('')
          : '<div class="ln-empty">No customer orders for your products yet.</div>'
      }
    </div>
  `;
  $('btnSelNewProd').onclick = () => { state.editingProductId = ''; state.activeTab = 'products'; renderTab(); };
}

function renderProductStudio(host, seller) {
  const uploadFlag = getFeatureStatus('productUpload', ROLES.SELLER);
  const myProducts = listSellerProducts(seller.uid);
  const cats = listCategories();
  const editProd = state.editingProductId ? myProducts.find((p) => p.id === state.editingProductId) : null;

  host.innerHTML = `
    <div class="ln-card" style="margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
        <h3 style="font-size:16px;">${editProd ? `Edit: ${escapeHtml(editProd.name)}` : 'Create Complete Product Listing'}</h3>
        ${editProd ? `<button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="btnSelClearForm">+ New Listing</button>` : ''}
      </div>
      ${
        !uploadFlag.enabled && !editProd
          ? `<div class="ln-empty"><p>${escapeHtml(uploadFlag.maintenanceMessage)}</p></div>`
          : `
        <div class="ln-field"><label>Product Name *</label><input id="spName" class="ln-input" value="${escapeAttr(editProd?.name || '')}" /></div>
        <div class="sel-two">
          <div class="ln-field"><label>Brand</label><input id="spBrand" class="ln-input" value="${escapeAttr(editProd?.brand || seller.storeName || '')}" /></div>
          <div class="ln-field"><label>SKU / Code</label><input id="spSku" class="ln-input" value="${escapeAttr(editProd?.sku || '')}" /></div>
          <div class="ln-field"><label>Category *</label><select id="spCat" class="ln-select">${cats.map((c) => `<option value="${escapeAttr(c.name)}" ${editProd?.cat === c.name ? 'selected' : ''}>${escapeHtml(c.name)}</option>`).join('')}</select></div>
          <div class="ln-field"><label>Subcategory</label><input id="spSubcat" class="ln-input" value="${escapeAttr(editProd?.subcat || '')}" /></div>
          <div class="ln-field"><label>Regular Price (BDT) *</label><input id="spPrice" type="number" class="ln-input" value="${editProd?.price || ''}" /></div>
          <div class="ln-field"><label>Offer Price (BDT)</label><input id="spOffer" type="number" class="ln-input" value="${editProd?.offerPrice || ''}" /></div>
          <div class="ln-field"><label>Discount (%)</label><input id="spDiscount" type="number" class="ln-input" value="${editProd?.discountPercent || ''}" /></div>
          <div class="ln-field"><label>Stock Quantity *</label><input id="spStock" type="number" class="ln-input" value="${editProd?.stock ?? 10}" /></div>
        </div>
        <div class="ln-field"><label>Highlights (one per line)</label><textarea id="spHighlights" class="ln-textarea">${escapeHtml(editProd?.highlights || '')}</textarea></div>
        <div class="ln-field"><label>Full Description</label><textarea id="spDesc" class="ln-textarea">${escapeHtml(editProd?.desc || '')}</textarea></div>
        <div class="ln-field"><label>Specifications (Name: Value per line)</label><textarea id="spSpecs" class="ln-textarea">${escapeHtml(editProd?.specs || '')}</textarea></div>
        <div class="sel-two">
          <div class="ln-field"><label>Sizes</label><input id="spSizes" class="ln-input" value="${escapeAttr(editProd?.sizes || '')}" placeholder="S, M, L, XL" /></div>
          <div class="ln-field"><label>Colors</label><input id="spColors" class="ln-input" value="${escapeAttr(editProd?.colors || '')}" placeholder="Black, Ivory" /></div>
          <div class="ln-field"><label>Material</label><input id="spMaterial" class="ln-input" value="${escapeAttr(editProd?.material || '')}" /></div>
          <div class="ln-field"><label>Weight</label><input id="spWeight" class="ln-input" value="${escapeAttr(editProd?.weight || '')}" /></div>
          <div class="ln-field"><label>Dimensions</label><input id="spDimensions" class="ln-input" value="${escapeAttr(editProd?.dimensions || '')}" /></div>
          <div class="ln-field"><label>Warranty</label><input id="spWarranty" class="ln-input" value="${escapeAttr(editProd?.warranty || '')}" /></div>
          <div class="ln-field"><label>Delivery Info</label><input id="spDelivery" class="ln-input" value="${escapeAttr(editProd?.delivery || '2-4 business days')}" /></div>
          <div class="ln-field"><label>Return Policy</label><input id="spReturn" class="ln-input" value="${escapeAttr(editProd?.return || '7-day return')}" /></div>
        </div>
        <div class="ln-field"><label>What is Included in the Box?</label><textarea id="spIncluded" class="ln-textarea">${escapeHtml(editProd?.included || '')}</textarea></div>
        <div class="ln-field">
          <label>Multiple Product Image URLs (one per line) *</label>
          <textarea id="spImages" class="ln-textarea" placeholder="https://... or /src/assets/images/...">${escapeHtml((editProd?.images || []).join('\n'))}</textarea>
          <div id="spPreview" class="sel-preview-grid"></div>
        </div>
        <div class="ln-field"><label>Product Video URL (optional)</label><input id="spVideo" class="ln-input" value="${escapeAttr(editProd?.video || '')}" /></div>
        <div class="ln-field"><label>Extra Information</label><textarea id="spExtra" class="ln-textarea">${escapeHtml(editProd?.extra || '')}</textarea></div>
        <div style="display:flex;gap:16px;margin-bottom:14px;">
          <label style="font-size:12px;"><input type="checkbox" id="spFeatured" ${editProd?.featured ? 'checked' : ''} /> Request Featured Placement</label>
          <label style="font-size:12px;"><input type="checkbox" id="spActive" ${editProd?.active !== false ? 'checked' : ''} /> Available for Sale</label>
        </div>
        <button type="button" class="ln-btn ln-btn-gold" id="btnSelSaveProd" style="width:100%;">Save Product Details</button>
      `
      }
    </div>

    <div class="ln-card">
      <h3 style="font-size:16px;margin-bottom:10px;">My Store Products (${myProducts.length})</h3>
      ${
        myProducts.length
          ? `<div class="ln-table-wrap"><table class="ln-table"><thead><tr><th>Product</th><th>Price</th><th>Stock</th><th>Status</th><th>Action</th></tr></thead><tbody>${myProducts
              .map(
                (p) => `
              <tr>
                <td><div style="display:flex;align-items:center;gap:10px;"><img src="${escapeAttr(sanitizeUrl(p.image, true))}" alt="" referrerpolicy="no-referrer" style="width:42px;height:42px;object-fit:cover;border-radius:6px;" /><strong>${escapeHtml(p.name)}</strong></div></td>
                <td class="tabular">${money(p.offerPrice || p.price)}</td>
                <td class="tabular">${Number(p.stock || 0)}</td>
                <td><span class="ln-status ${p.approved ? 'ln-status-success' : 'ln-status-warning'}">${escapeHtml(p.status)}</span></td>
                <td>
                  <div style="display:flex;gap:6px;">
                    <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" data-sel-edit="${escapeAttr(p.id)}">Edit</button>
                    <button type="button" class="ln-btn ln-btn-danger ln-btn-sm" data-sel-del="${escapeAttr(p.id)}">Delete</button>
                  </div>
                </td>
              </tr>`
              )
              .join('')}</tbody></table></div>`
          : '<div class="ln-empty">No products added to your store yet.</div>'
      }
    </div>
  `;

  if ($('btnSelClearForm')) {
    $('btnSelClearForm').onclick = () => { state.editingProductId = ''; renderProductStudio(host, seller); };
  }
  const updatePreview = () => {
    const urls = ($('spImages')?.value || '').split(/\n|,/).map((u) => sanitizeUrl(u.trim(), true)).filter(Boolean);
    if ($('spPreview')) $('spPreview').innerHTML = urls.slice(0, 8).map((u) => `<img src="${escapeAttr(u)}" alt="Preview" referrerpolicy="no-referrer" />`).join('');
  };
  if ($('spImages')) {
    $('spImages').oninput = updatePreview;
    updatePreview();
  }
  if ($('spPrice') && $('spOffer') && $('spDiscount')) {
    $('spOffer').oninput = () => {
      const p = Number($('spPrice').value);
      const o = Number($('spOffer').value);
      if (p > 0 && o > 0 && o <= p) $('spDiscount').value = String(Math.round(((p - o) * 100) / p));
    };
    $('spDiscount').oninput = () => {
      const p = Number($('spPrice').value);
      const d = Number($('spDiscount').value);
      if (p > 0 && d >= 0 && d <= 100) $('spOffer').value = String(roundMoney(p * (1 - d / 100)));
    };
  }
  if ($('btnSelSaveProd')) {
    $('btnSelSaveProd').onclick = () => {
      try {
        saveProduct(
          {
            id: state.editingProductId || undefined,
            name: $('spName').value,
            brand: $('spBrand').value,
            sku: $('spSku').value,
            cat: $('spCat').value,
            subcat: $('spSubcat').value,
            price: $('spPrice').value,
            offerPrice: $('spOffer').value || $('spPrice').value,
            stock: $('spStock').value,
            highlights: $('spHighlights').value,
            desc: $('spDesc').value,
            specs: $('spSpecs').value,
            sizes: $('spSizes').value,
            colors: $('spColors').value,
            material: $('spMaterial').value,
            weight: $('spWeight').value,
            dimensions: $('spDimensions').value,
            warranty: $('spWarranty').value,
            delivery: $('spDelivery').value,
            return: $('spReturn').value,
            included: $('spIncluded').value,
            images: $('spImages').value,
            video: $('spVideo').value,
            extra: $('spExtra').value,
            featured: $('spFeatured').checked,
            active: $('spActive').checked,
          },
          seller
        );
        state.editingProductId = '';
        showToast('Product saved! Pending Admin approval if required.', 'success');
        renderProductStudio(host, seller);
      } catch (err) {
        showToast(err.message, 'error');
      }
    };
  }
  host.querySelectorAll('[data-sel-edit]').forEach((b) => {
    b.onclick = () => { state.editingProductId = b.dataset.selEdit; renderProductStudio(host, seller); window.scrollTo(0, 0); };
  });
  host.querySelectorAll('[data-sel-del]').forEach((b) => {
    b.onclick = async () => {
      const ok = await openConfirmDialog({ title: 'Delete Product', message: 'Remove this product listing permanently?', confirmLabel: 'Delete', danger: true });
      if (!ok) return;
      deleteProduct(b.dataset.selDel, seller);
      showToast('Product deleted');
      renderProductStudio(host, seller);
    };
  });
}

function renderSellerOrders(host, seller) {
  const orders = listOrdersForSeller(seller.uid);
  const sellerAllowedStatuses = ORDER_STATUSES.filter((s) => s !== 'Refunded');

  host.innerHTML = `
    <div class="ln-card">
      <h3 style="font-size:16px;margin-bottom:10px;">Store Orders (${orders.length})</h3>
      ${
        orders.length
          ? orders
              .map(
                (o) => `
              <div style="padding:14px 0;border-bottom:1px solid var(--border);">
                <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;">
                  <div>
                    <strong class="mono">#${escapeHtml(o.id)}</strong> · ${formatDateTime(o.createdAt)}
                    ${o.hasAffiliateReferral ? `<span style="margin-left:8px;font-size:11px;color:var(--gold);font-weight:700;">◈ Affiliate Referral (Admin Managed)</span>` : ''}
                  </div>
                  <select class="ln-select" style="width:170px;" data-sel-ord="${escapeAttr(o.id)}">
                    ${sellerAllowedStatuses.map((st) => `<option value="${st}" ${o.status === st ? 'selected' : ''}>${st}</option>`).join('')}
                  </select>
                </div>
                <div style="font-size:13px;margin:6px 0;">
                  ${o.items.map((i) => `<div>${escapeHtml(i.name)} × ${i.qty} — <strong class="tabular">${money(i.lineTotal)}</strong></div>`).join('')}
                </div>
                <div style="font-size:12px;color:var(--text-muted);">Customer: ${escapeHtml(o.customer?.name)} (${escapeHtml(o.customer?.phone)}) · ${escapeHtml(o.customer?.address)}, ${escapeHtml(o.customer?.district)}</div>
              </div>`
              )
              .join('')
          : '<div class="ln-empty">No orders assigned to your store yet.</div>'
      }
    </div>
  `;

  host.querySelectorAll('[data-sel-ord]').forEach((sel) => {
    sel.onchange = () => {
      try {
        updateOrderStatus(sel.dataset.selOrd, sel.value, seller);
        showToast(`Order status updated to ${sel.value}`, 'success');
        renderSellerOrders(host, seller);
      } catch (err) {
        showToast(err.message, 'error');
      }
    };
  });
}

function renderSellerReports(host, seller) {
  const repFlag = getFeatureStatus('sellerReports', ROLES.SELLER);
  if (!repFlag.enabled) {
    host.innerHTML = `<div class="ln-empty"><p>${escapeHtml(repFlag.maintenanceMessage)}</p></div>`;
    return;
  }
  const orders = listOrdersForSeller(seller.uid);
  const cfg = getPlatformConfig();
  const feePct = Number(cfg.checkout?.platformFeePercent ?? 10);
  const delivered = orders.filter((o) => o.status === 'Delivered');
  const gross = roundMoney(delivered.reduce((s, o) => s + Number(o.sellerSubtotal || 0), 0));
  const fee = roundMoney((gross * feePct) / 100);
  const net = roundMoney(gross - fee);

  host.innerHTML = `
    <div class="ln-card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
        <h3 style="font-size:16px;">Sales &amp; Revenue Report</h3>
        <button type="button" class="ln-btn ln-btn-outline ln-btn-sm" id="btnSelExportCsv">Export CSV</button>
      </div>
      <table class="ln-table">
        <tr><td>Total Store Orders</td><td class="tabular"><strong>${orders.length}</strong></td></tr>
        <tr><td>Delivered Orders</td><td class="tabular"><strong>${delivered.length}</strong></td></tr>
        <tr><td>Gross Store Sales (Delivered)</td><td class="tabular"><strong>${money(gross)}</strong></td></tr>
        <tr><td>Platform Service Fee (${feePct}%)</td><td class="tabular">−${money(fee)}</td></tr>
        <tr><td><strong>Net Seller Revenue</strong></td><td class="tabular"><strong style="color:var(--success);">${money(net)}</strong></td></tr>
      </table>
    </div>
  `;
  $('btnSelExportCsv').onclick = () => {
    const csv = toCsv(
      ['OrderID', 'Date', 'Status', 'StoreSubtotal'],
      orders.map((o) => [o.id, o.createdAt, o.status, o.sellerSubtotal])
    );
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'seller-sales-report.csv';
    a.click();
    URL.revokeObjectURL(url);
  };
}

function renderSellerProfile(host, seller) {
  const myProducts = listSellerProducts(seller.uid);
  host.innerHTML = `
    <div class="ln-card" style="margin-bottom:14px;">
      <h3 style="font-size:16px;margin-bottom:10px;">Store Profile</h3>
      <div class="ln-field"><label>Store Name</label><input id="profStoreName" class="ln-input" value="${escapeAttr(seller.storeName || '')}" /></div>
      <div class="ln-field"><label>Store Description</label><textarea id="profStoreDesc" class="ln-textarea">${escapeHtml(seller.storeDesc || '')}</textarea></div>
      <button type="button" class="ln-btn ln-btn-gold" id="btnSaveStoreProf">Save Store Profile</button>
    </div>
    <div class="ln-card">
      <h3 style="font-size:16px;margin-bottom:8px;">Product Catalog Backup</h3>
      <button type="button" class="ln-btn ln-btn-outline" id="btnExportSelProds">Export My Products JSON</button>
    </div>
  `;
  $('btnSaveStoreProf').onclick = () => {
    updateAccountProfile(seller.uid, { storeName: $('profStoreName').value, storeDesc: $('profStoreDesc').value });
    appServices.sellers.upsert(seller.uid, { ...appServices.sellers.getById(seller.uid), storeName: $('profStoreName').value, storeDesc: $('profStoreDesc').value });
    $('selStoreTitle').textContent = $('profStoreName').value || seller.name;
    showToast('Store profile updated', 'success');
  };
  $('btnExportSelProds').onclick = () => {
    const blob = new Blob([JSON.stringify(myProducts, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'luxe-nexus-seller-products.json';
    a.click();
    URL.revokeObjectURL(url);
  };
}

function updateNotifCount() {
  const seller = getActiveUser('seller');
  $('selNotifCount').textContent = String(getUnreadCount('seller', seller?.uid || ''));
}

function renderApp() {
  ensureEcosystemSeeded();
  if (localStorage.getItem('ln_theme_variant') === 'light') document.body.classList.add('light-atelier');
  const cfg = getPlatformConfig();
  applyDesignTokensToDocument(cfg);
  const logoSrc = sanitizeUrl(cfg.logo, true) || OFFICIAL_LOGO_URL;
  if ($('selGateLogoImg')) $('selGateLogoImg').src = logoSrc;
  if ($('selTopLogoImg')) $('selTopLogoImg').src = logoSrc;
  initLuxurySelectObserver();
  if (!renderAuthGate()) return;
  renderTab();
  updateNotifCount();
}

document.querySelectorAll('#selTabs .sel-tab-btn').forEach((btn) => {
  btn.onclick = () => { state.activeTab = btn.dataset.tab; renderTab(); };
});
$('btnSelTheme').onclick = () => {
  document.body.classList.toggle('light-atelier');
  localStorage.setItem('ln_theme_variant', document.body.classList.contains('light-atelier') ? 'light' : 'dark');
  applyDesignTokensToDocument(getPlatformConfig());
};
$('btnSelNotifs').onclick = () => {
  const seller = getActiveUser('seller');
  renderNotificationModal({ audience: 'seller', userId: seller?.uid || '', onUpdated: updateNotifCount });
};
$('btnSelLogout').onclick = () => {
  logoutAccount('seller');
  showToast('Signed out of Seller Portal');
  renderAuthGate();
};

appServices.products.subscribe(() => { if (getActiveUser('seller')) renderTab(); });
appServices.orders.subscribe(() => { if (getActiveUser('seller')) renderTab(); });
appServices.notifications.subscribe(updateNotifCount);

renderApp();
