/**
 * LUXE NEXUS Cloud Functions Source (Prepare-Only for Future Project: fliex-price)
 *
 * Deployment Note:
 * Not initialized or deployed in the current local-adapter stage.
 * When connecting Firebase later, deploy these functions via Firebase CLI.
 */

const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { onDocumentUpdated } = require('firebase-functions/v2/firestore');
const admin = require('firebase-admin');

if (!admin.apps.length) {
  admin.initializeApp();
}
const db = admin.firestore();

const roundMoney = (n) => Math.round((Number(n || 0) + Number.EPSILON) * 100) / 100;

/**
 * 1. Unified Order Creation (Cart & Buy Now) with Transactional Stock Deduction,
 *    Idempotency Check, Server Pricing, and Non-Expired Affiliate Attribution.
 */
exports.createOrder = onCall(async (request) => {
  const { items, customer, area, payment, couponCode, source, idempotencyKey, referralCode } = request.data || {};
  if (!Array.isArray(items) || !items.length) {
    throw new HttpsError('invalid-argument', 'Order items are required.');
  }
  if (!customer || !customer.name || !customer.phone || !customer.address) {
    throw new HttpsError('invalid-argument', 'Complete customer shipping details are required.');
  }

  return db.runTransaction(async (tx) => {
    if (idempotencyKey) {
      const idemRef = db.collection('orderIdempotency').doc(idempotencyKey);
      const idemSnap = await tx.get(idemRef);
      if (idemSnap.exists) {
        throw new HttpsError('already-exists', 'Duplicate order submission prevented.');
      }
      tx.set(idemRef, { createdAt: admin.firestore.FieldValue.serverTimestamp() });
    }

    const cfgSnap = await tx.get(db.collection('platformSettings').doc('global'));
    const cfg = cfgSnap.exists ? cfgSnap.data() : { checkout: { dhakaFee: 60, outFee: 120 } };

    let subtotal = 0;
    const normalizedItems = [];
    const sellerIds = new Set();

    for (const item of items) {
      const prodRef = db.collection('products').doc(item.productId);
      const prodSnap = await tx.get(prodRef);
      if (!prodSnap.exists) throw new HttpsError('not-found', `Product ${item.productId} not found.`);
      const prod = prodSnap.data();
      if (!prod.approved || !prod.active) {
        throw new HttpsError('failed-precondition', `Product ${prod.name} is unavailable.`);
      }
      const qty = Math.max(1, Math.floor(Number(item.qty || 1)));
      if (Number(prod.stock || 0) < qty) {
        throw new HttpsError('failed-precondition', `Insufficient stock for ${prod.name}.`);
      }

      const unitPrice = roundMoney(prod.offerPrice || prod.price);
      const lineTotal = roundMoney(unitPrice * qty);
      subtotal = roundMoney(subtotal + lineTotal);
      sellerIds.add(prod.sellerId);

      tx.update(prodRef, { stock: admin.firestore.FieldValue.increment(-qty) });
      normalizedItems.push({
        productId: prodSnap.id,
        name: prod.name,
        category: prod.cat,
        sellerId: prod.sellerId,
        unitPrice,
        qty,
        lineTotal,
      });
    }

    const deliveryCharge = area === 'outside' ? roundMoney(cfg.checkout?.outFee || 120) : roundMoney(cfg.checkout?.dhakaFee || 60);
    const grandTotal = roundMoney(subtotal + deliveryCharge);
    const nowMs = Date.now();

    const orderRef = db.collection('orders').doc();
    const orderData = {
      id: orderRef.id,
      userId: request.auth?.uid || 'guest',
      customer,
      items: normalizedItems,
      sellerIds: Array.from(sellerIds),
      subtotal,
      delivery: deliveryCharge,
      total: grandTotal,
      area,
      payment,
      source: source || 'cart',
      couponCode: couponCode || '',
      status: 'Placed',
      createdAtMs: nowMs,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    };

    // Server-side 168h Affiliate Attribution check
    if (referralCode) {
      const linkQuery = await db.collection('affiliateLinks').where('code', '==', referralCode).limit(1).get();
      if (!linkQuery.empty) {
        const linkDoc = linkQuery.docs[0];
        const link = linkDoc.data();
        const affSnap = await tx.get(db.collection('affiliates').doc(link.affiliateId));
        if (affSnap.exists && affSnap.data().status === 'approved' && link.status === 'active' && nowMs < link.expiresAtMs) {
          const isSelf = request.auth?.uid && request.auth.uid === link.affiliateUserId;
          if (!isSelf) {
            const rate = Number(cfg.affiliateConfig?.defaultRate || 8);
            const commissionAmount = roundMoney((subtotal * rate) / 100);
            const commRef = db.collection('affiliateCommissions').doc();
            tx.set(commRef, {
              id: commRef.id,
              orderId: orderRef.id,
              affiliateId: link.affiliateId,
              affiliateUserId: link.affiliateUserId,
              linkId: linkDoc.id,
              orderTotal: subtotal,
              commissionAmount,
              status: 'pending',
              createdAtMs: nowMs,
            });
            tx.update(linkDoc.ref, { status: 'sold', orders: admin.firestore.FieldValue.increment(1) });
            orderData.affiliateId = link.affiliateId;
            orderData.affiliateCommissionId = commRef.id;
          }
        }
      }
    }

    tx.set(orderRef, orderData);
    return { orderId: orderRef.id, total: grandTotal };
  });
});

/**
 * 2. Track Referral Click with Server Clock 168-hour Expiry Guard & Self-Referral Check.
 */
exports.trackAffiliateClick = onCall(async (request) => {
  const { code, visitorId, source } = request.data || {};
  if (!code) throw new HttpsError('invalid-argument', 'Referral code is required.');

  const snap = await db.collection('affiliateLinks').where('code', '==', code).limit(1).get();
  if (snap.empty) return { attributed: false, reason: 'Invalid referral code.' };

  const linkDoc = snap.docs[0];
  const link = linkDoc.data();
  const nowMs = Date.now();

  if (nowMs >= Number(link.expiresAtMs || 0) || link.status === 'expired' || link.status === 'disabled') {
    if (link.status === 'active') await linkDoc.ref.update({ status: 'expired' });
    return { attributed: false, reason: 'Referral link expired.' };
  }

  if (request.auth?.uid && request.auth.uid === link.affiliateUserId) {
    return { attributed: false, reason: 'Self-referral is blocked.' };
  }

  await db.collection('affiliateClicks').add({
    linkId: linkDoc.id,
    code: link.code,
    affiliateId: link.affiliateId,
    affiliateUserId: link.affiliateUserId,
    visitorId: visitorId || 'anonymous',
    source: source || 'direct',
    createdAtMs: nowMs,
  });

  await linkDoc.ref.update({ clicks: admin.firestore.FieldValue.increment(1) });
  return { attributed: true, linkId: linkDoc.id, expiresAtMs: link.expiresAtMs };
});

/**
 * 3. Automatic Commission Lifecycle Sync on Order Status Update.
 */
exports.syncCommissionOnOrderUpdate = onDocumentUpdated('orders/{orderId}', async (event) => {
  const before = event.data.before.data();
  const after = event.data.after.data();
  if (before.status === after.status) return null;

  const commsSnap = await db.collection('affiliateCommissions').where('orderId', '==', event.params.orderId).get();
  if (commsSnap.empty) return null;

  const batch = db.batch();
  commsSnap.forEach((docSnap) => {
    const comm = docSnap.data();
    if (after.status === 'Delivered' && comm.status === 'pending') {
      batch.update(docSnap.ref, { status: 'approved', updatedAt: admin.firestore.FieldValue.serverTimestamp() });
    } else if (['Cancelled', 'Refunded'].includes(after.status) && comm.status !== 'paid') {
      batch.update(docSnap.ref, { status: 'reversed', updatedAt: admin.firestore.FieldValue.serverTimestamp() });
    }
  });
  return batch.commit();
});

/**
 * 4. Atomic Affiliate Withdrawal Request (Prevents Double Withdrawal & Over-Balance Abuse).
 */
exports.requestAffiliateWithdrawal = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Authentication required.');
  const { affiliateId, method, accountHolder, accountNumber, amount } = request.data || {};
  const reqAmount = roundMoney(amount);
  if (reqAmount <= 0) throw new HttpsError('invalid-argument', 'Invalid withdrawal amount.');

  return db.runTransaction(async (tx) => {
    const affSnap = await tx.get(db.collection('affiliates').doc(affiliateId));
    if (!affSnap.exists || affSnap.data().userId !== request.auth.uid || affSnap.data().status !== 'approved') {
      throw new HttpsError('permission-denied', 'Approved affiliate profile required.');
    }

    const commsSnap = await tx.get(
      db.collection('affiliateCommissions').where('affiliateId', '==', affiliateId).where('status', '==', 'approved')
    );
    const approvedSum = commsSnap.docs.reduce((s, d) => roundMoney(s + Number(d.data().commissionAmount || 0)), 0);

    const wSnap = await tx.get(
      db.collection('affiliateWithdrawals')
        .where('affiliateId', '==', affiliateId)
        .where('status', 'in', ['pending', 'approved', 'processing'])
    );
    const reservedSum = wSnap.docs.reduce((s, d) => roundMoney(s + Number(d.data().amount || 0)), 0);
    const available = roundMoney(approvedSum - reservedSum);

    if (reqAmount > available) {
      throw new HttpsError('failed-precondition', 'Requested amount exceeds available balance.');
    }

    const wRef = db.collection('affiliateWithdrawals').doc();
    tx.set(wRef, {
      id: wRef.id,
      affiliateId,
      affiliateUserId: request.auth.uid,
      method,
      accountHolder,
      accountNumber,
      amount: reqAmount,
      status: 'pending',
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
    return { withdrawalId: wRef.id, status: 'pending' };
  });
});

/**
 * 5. Verify Link Expiry Callable.
 */
exports.verifyLinkExpiry = onCall(async (request) => {
  const { code } = request.data || {};
  const snap = await db.collection('affiliateLinks').where('code', '==', code).limit(1).get();
  if (snap.empty) return { valid: false, status: 'not_found' };
  const docSnap = snap.docs[0];
  const data = docSnap.data();
  const expired = Date.now() >= Number(data.expiresAtMs || 0);
  if (expired && data.status === 'active') {
    await docSnap.ref.update({ status: 'expired' });
  }
  return { valid: !expired && data.status === 'active', status: expired ? 'expired' : data.status };
});
