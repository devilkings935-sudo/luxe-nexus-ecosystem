/**
 * LUXE NEXUS Unified Backend Adapter Registry (PART 14)
 * Exposes `appServices` repository interface backed by local development adapters
 * with zero runtime Firebase initialization.
 */

import { storageAdapter, getCollection, setCollection, upsertDoc, deleteDoc, subscribe } from './storage-adapter.js';
import { authAdapter } from './auth-adapter.js';
import { hasPermission, canAccessFeature } from '../shared/permissions.js';
import { DEFAULT_CONFIG, FUTURE_FIREBASE_PROJECT } from '../shared/configuration.js';

function createRepository(collectionName, defaultVal = []) {
  return {
    list: () => getCollection(collectionName, defaultVal),
    saveAll: (items) => setCollection(collectionName, items),
    getById: (id) => {
      const list = getCollection(collectionName, defaultVal);
      return Array.isArray(list) ? list.find((x) => String(x.id || x.uid) === String(id)) || null : null;
    },
    upsert: (id, doc) => upsertDoc(collectionName, id, doc),
    remove: (id) => deleteDoc(collectionName, id),
    subscribe: (cb) => subscribe(collectionName, cb),
  };
}

export const productRepository = createRepository('products', []);
export const orderRepository = createRepository('orders', []);
export const categoryRepository = createRepository('categories', []);
export const sellerRepository = createRepository('sellers', []);
export const affiliateRepository = {
  affiliates: createRepository('affiliates', []),
  links: createRepository('affiliateLinks', []),
  clicks: createRepository('affiliateClicks', []),
  referrals: createRepository('affiliateReferrals', []),
  commissions: createRepository('affiliateCommissions', []),
  withdrawals: createRepository('affiliateWithdrawals', []),
  notifications: createRepository('affiliateNotifications', []),
  auditLogs: createRepository('affiliateAuditLogs', []),
};
export const settingsRepository = {
  getConfig: () => getCollection('platformSettings', DEFAULT_CONFIG),
  saveConfig: (cfg) => setCollection('platformSettings', cfg),
  subscribe: (cb) => subscribe('platformSettings', cb),
};
export const notificationRepository = createRepository('notifications', []);
export const auditRepository = createRepository('auditLogs', []);
export const announcementRepository = createRepository('announcements', []);
export const versionRepository = createRepository('appVersions', []);

export const appServices = {
  mode: FUTURE_FIREBASE_PROJECT.mode,
  firebaseTarget: FUTURE_FIREBASE_PROJECT,
  auth: authAdapter,
  storage: storageAdapter,
  products: productRepository,
  orders: orderRepository,
  categories: categoryRepository,
  sellers: sellerRepository,
  affiliates: affiliateRepository,
  settings: settingsRepository,
  notifications: notificationRepository,
  audits: auditRepository,
  announcements: announcementRepository,
  versions: versionRepository,
};

export function assertPermission(actorRole, permission) {
  const cfg = settingsRepository.getConfig();
  const matrix = cfg?.rolePermissions || null;
  if (!hasPermission(actorRole, permission, matrix)) {
    throw new Error(`Access denied: role "${actorRole}" lacks "${permission}" permission.`);
  }
}

export function assertFeatureEnabled(featureKey, actorRole = 'customer') {
  const cfg = settingsRepository.getConfig();
  const flag = cfg?.featureFlags?.[featureKey];
  if (!canAccessFeature(flag, actorRole)) {
    throw new Error(flag?.maintenanceMessage || `Feature "${featureKey}" is currently disabled by Admin.`);
  }
}

export function recordAuditLog({ actorId, actorRole, action, targetCollection, targetId, details = '' }) {
  const entry = {
    id: `AUD-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`,
    actorId: actorId || 'system',
    actorRole: actorRole || 'system',
    action,
    targetCollection,
    targetId: String(targetId || ''),
    details,
    timestamp: new Date().toISOString(),
  };
  const logs = auditRepository.list();
  logs.unshift(entry);
  auditRepository.saveAll(logs.slice(0, 500));
  return entry;
}
