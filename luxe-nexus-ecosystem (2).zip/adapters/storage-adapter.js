/**
 * LUXE NEXUS Storage Adapter (Local Development Prototype + Future Firestore Interface)
 * Uses localStorage + BroadcastChannel in browser, and isolated in-memory Map in Node tests.
 * Never initializes or connects to Firebase SDK during this local prototype phase.
 */

import { FUTURE_FIREBASE_PROJECT } from '../shared/configuration.js';

const STORAGE_PREFIX = 'ln_v2_';
const memoryStore = new Map();
const listeners = new Map();

let channel = null;
if (typeof window !== 'undefined' && typeof BroadcastChannel !== 'undefined') {
  try {
    channel = new BroadcastChannel('luxe-nexus-sync-v2');
    channel.onmessage = (ev) => {
      const col = ev?.data?.collection;
      if (col) notifyListeners(col);
    };
  } catch {
    channel = null;
  }
}

if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {
  window.addEventListener('storage', (ev) => {
    if (ev.key && ev.key.startsWith(STORAGE_PREFIX)) {
      const col = ev.key.slice(STORAGE_PREFIX.length);
      notifyListeners(col);
    }
  });
}

function hasLocalStorage() {
  try {
    return typeof localStorage !== 'undefined' && localStorage !== null;
  } catch {
    return false;
  }
}

function readRaw(key) {
  const fullKey = STORAGE_PREFIX + key;
  if (hasLocalStorage()) {
    return localStorage.getItem(fullKey);
  }
  return memoryStore.has(fullKey) ? memoryStore.get(fullKey) : null;
}

function writeRaw(key, value) {
  const fullKey = STORAGE_PREFIX + key;
  if (hasLocalStorage()) {
    localStorage.setItem(fullKey, value);
  } else {
    memoryStore.set(fullKey, value);
  }
}

function notifyListeners(collection) {
  const subs = listeners.get(collection);
  if (!subs || subs.size === 0) return;
  const data = getCollection(collection);
  for (const cb of subs) {
    try {
      cb(data);
    } catch (err) {
      console.error('Storage listener error:', collection, err);
    }
  }
}

export function getCollection(collection, fallback = []) {
  try {
    const raw = readRaw(collection);
    if (!raw) return Array.isArray(fallback) ? structuredClone(fallback) : structuredClone(fallback);
    const parsed = JSON.parse(raw);
    return parsed;
  } catch {
    return structuredClone(fallback);
  }
}

export function setCollection(collection, data) {
  writeRaw(collection, JSON.stringify(data));
  if (channel) {
    try {
      channel.postMessage({ collection, ts: Date.now() });
    } catch {
      // Ignore broadcast errors in closed tabs
    }
  }
  notifyListeners(collection);
  return data;
}

export function getDoc(collection, id, fallback = null) {
  const data = getCollection(collection, []);
  if (Array.isArray(data)) {
    return data.find((d) => String(d.id || d.uid || d.version) === String(id)) || fallback;
  }
  if (data && typeof data === 'object') {
    return data[id] ?? fallback;
  }
  return fallback;
}

export function upsertDoc(collection, id, doc) {
  const list = getCollection(collection, []);
  if (!Array.isArray(list)) {
    const updatedObj = { ...(list || {}), [id]: doc };
    setCollection(collection, updatedObj);
    return doc;
  }
  const idx = list.findIndex((d) => String(d.id || d.uid || d.version) === String(id));
  const record = { ...doc, id: doc.id ?? id };
  if (idx >= 0) {
    list[idx] = { ...list[idx], ...record };
  } else {
    list.unshift(record);
  }
  setCollection(collection, list);
  return record;
}

export function deleteDoc(collection, id) {
  const list = getCollection(collection, []);
  if (!Array.isArray(list)) return false;
  const next = list.filter((d) => String(d.id || d.uid || d.version) !== String(id));
  setCollection(collection, next);
  return next.length !== list.length;
}

export function subscribe(collection, callback) {
  if (!listeners.has(collection)) listeners.set(collection, new Set());
  listeners.get(collection).add(callback);
  return () => {
    const set = listeners.get(collection);
    if (set) set.delete(callback);
  };
}

export function seedIfEmpty(collection, seedData) {
  const raw = readRaw(collection);
  if (raw === null) {
    setCollection(collection, structuredClone(seedData));
    return true;
  }
  return false;
}

export function resetMemoryStore() {
  memoryStore.clear();
  listeners.clear();
}

export function clearAllLocalCollections() {
  if (hasLocalStorage()) {
    const keysToRemove = [];
    for (let i = 0; i < localStorage.length; i += 1) {
      const k = localStorage.key(i);
      if (k && k.startsWith(STORAGE_PREFIX)) keysToRemove.push(k);
    }
    keysToRemove.forEach((k) => localStorage.removeItem(k));
  }
  memoryStore.clear();
}

export function exportAllCollections() {
  const out = {};
  if (hasLocalStorage()) {
    for (let i = 0; i < localStorage.length; i += 1) {
      const k = localStorage.key(i);
      if (k && k.startsWith(STORAGE_PREFIX)) {
        const name = k.slice(STORAGE_PREFIX.length);
        out[name] = getCollection(name, []);
      }
    }
  } else {
    for (const [k, v] of memoryStore.entries()) {
      out[k.slice(STORAGE_PREFIX.length)] = JSON.parse(v);
    }
  }
  return {
    exportedAt: new Date().toISOString(),
    adapterMode: FUTURE_FIREBASE_PROJECT.mode,
    targetFirebaseProject: FUTURE_FIREBASE_PROJECT.projectId,
    collections: out,
  };
}

export function importAllCollections(snapshot) {
  if (!snapshot || typeof snapshot !== 'object' || !snapshot.collections) {
    throw new Error('Invalid LUXE NEXUS backup format.');
  }
  for (const [col, data] of Object.entries(snapshot.collections)) {
    setCollection(col, data);
  }
  return true;
}

export const storageAdapter = {
  mode: 'local-development-adapter',
  futureProject: FUTURE_FIREBASE_PROJECT,
  getCollection,
  setCollection,
  getDoc,
  upsertDoc,
  deleteDoc,
  subscribe,
  seedIfEmpty,
  exportAllCollections,
  importAllCollections,
};
