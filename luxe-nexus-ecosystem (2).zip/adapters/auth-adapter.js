/**
 * LUXE NEXUS Authentication Adapter
 * Local Development Prototype using salted SHA-256 hashes (no hardcoded admin passwords).
 * Includes Future Google OAuth & Firebase Auth interface descriptors without initializing Firebase SDK.
 */

import { getCollection, setCollection, upsertDoc, getDoc } from './storage-adapter.js';
import { sha256Hex, generateId } from '../shared/utilities.js';
import { ROLES, isAdminRole } from '../shared/permissions.js';

const USERS_COL = 'users';
const SESSION_KEY = 'session_state';

function getSessionStore() {
  return getCollection(SESSION_KEY, {});
}

function setSessionStore(next) {
  return setCollection(SESSION_KEY, next);
}

export async function hashPasswordWithSalt(password, salt) {
  return sha256Hex(`${salt}::${password}::LN_V2`);
}

export function hasAnyAdminUser() {
  const users = getCollection(USERS_COL, []);
  return users.some((u) => isAdminRole(u.role));
}

export async function registerUser({
  name,
  username = '',
  email,
  phone = '',
  password,
  role = ROLES.CUSTOMER,
  storeName = '',
  storeDesc = '',
  dateOfBirth = '',
  age = null,
  city = '',
  socialUrl = '',
  bio = '',
}) {
  const cleanEmail = String(email ?? '').trim().toLowerCase();
  const cleanName = String(name ?? '').trim();
  const cleanUsername = String(username ?? '').trim();
  const cleanPhone = String(phone ?? '').replace(/\s+/g, '');

  const users = getCollection(USERS_COL, []);
  if (users.some((u) => u.email.toLowerCase() === cleanEmail)) {
    throw new Error('An account with this email already exists.');
  }

  // Only allow first-ever admin bootstrap or authorized admin creation
  let assignedRole = role;
  let status = 'active';
  if (isAdminRole(role)) {
    if (hasAnyAdminUser()) {
      // Subsequent admin signups without existing Super Admin approval start pending or require existing admin
      assignedRole = role;
    } else {
      assignedRole = ROLES.SUPER_ADMIN;
    }
  } else if (role === ROLES.SELLER) {
    status = 'pending'; // Seller requires Admin approval before login
  }

  const uid = generateId(assignedRole === ROLES.SELLER ? 'SEL' : isAdminRole(assignedRole) ? 'ADM' : 'USR');
  const salt = generateId('SLT');
  const passwordHash = await hashPasswordWithSalt(password, salt);

  const userRecord = {
    id: uid,
    uid,
    name: cleanName,
    ...(cleanUsername ? { username: cleanUsername } : {}),
    email: cleanEmail,
    phone: cleanPhone,
    emailVerified: false,
    phoneVerified: false,
    dateOfBirth: String(dateOfBirth || '').trim(),
    age: age !== null && age !== '' && Number.isFinite(Number(age)) ? Number(age) : null,
    city: String(city || '').trim(),
    socialUrl: String(socialUrl || '').trim(),
    bio: String(bio || '').trim(),
    role: assignedRole,
    status,
    approved: status === 'active',
    storeName: storeName.trim(),
    storeDesc: storeDesc.trim(),
    salt,
    passwordHash,
    addresses: [],
    paymentMethods: [],
    createdAt: new Date().toISOString(),
  };

  upsertDoc(USERS_COL, uid, userRecord);
  return stripSensitive(userRecord);
}

export async function authenticateUser({ email, password, appScope = 'user', rememberMe = true }) {
  const cleanEmail = String(email ?? '').trim().toLowerCase();
  const users = getCollection(USERS_COL, []);
  const user = users.find((u) => u.email.toLowerCase() === cleanEmail);
  if (!user) {
    throw new Error('No account found with that email address.');
  }

  const candidateHash = await hashPasswordWithSalt(password, user.salt);
  if (candidateHash !== user.passwordHash) {
    throw new Error('Email or password is incorrect.');
  }

  if (appScope === 'admin' && !isAdminRole(user.role)) {
    throw new Error('This account does not have Admin Control Studio permissions.');
  }
  if (appScope === 'seller') {
    if (user.role !== ROLES.SELLER && !isAdminRole(user.role)) {
      throw new Error('This account is not registered as a Seller.');
    }
    if (user.role === ROLES.SELLER && (user.status !== 'approved' && user.status !== 'active' || !user.approved)) {
      throw new Error('Your Seller account is pending Admin approval.');
    }
  }
  if (user.status === 'suspended') {
    throw new Error('This account has been suspended. Please contact support.');
  }

  const safeUser = stripSensitive(user);
  const sessions = getSessionStore();
  sessions[appScope] = {
    uid: safeUser.uid,
    rememberMe: !!rememberMe,
    signedInAt: new Date().toISOString(),
  };
  setSessionStore(sessions);
  return safeUser;
}

export function getCurrentSessionUser(appScope = 'user') {
  const sessions = getSessionStore();
  const sess = sessions?.[appScope];
  if (!sess?.uid) return null;
  const user = getDoc(USERS_COL, sess.uid, null);
  if (!user || user.status === 'suspended') return null;
  return stripSensitive(user);
}

export function logoutSession(appScope = 'user') {
  const sessions = getSessionStore();
  delete sessions[appScope];
  setSessionStore(sessions);
}

export async function resetUserPassword({ contact, newPassword }) {
  const clean = String(contact ?? '').trim().toLowerCase();
  const users = getCollection(USERS_COL, []);
  const user = users.find(
    (u) => u.email.toLowerCase() === clean || (u.phone && u.phone === contact.replace(/\s+/g, ''))
  );
  if (!user) {
    throw new Error('No account matches that email or mobile number.');
  }
  const salt = generateId('SLT');
  const passwordHash = await hashPasswordWithSalt(newPassword, salt);
  upsertDoc(USERS_COL, user.uid, { ...user, salt, passwordHash, updatedAt: new Date().toISOString() });
  return true;
}

export function updateUserProfile(uid, updates) {
  const existing = getDoc(USERS_COL, uid, null);
  if (!existing) throw new Error('User not found.');
  // Never allow client profile update to escalate role, approval status, or contact verification flags
  const {
    role: _r,
    approved: _a,
    status: _s,
    passwordHash: _p,
    salt: _sl,
    emailVerified: _ev,
    phoneVerified: _pv,
    ...safeUpdates
  } = updates || {};

  const nextEmail = safeUpdates.email !== undefined ? String(safeUpdates.email).trim().toLowerCase() : existing.email;
  const nextPhone = safeUpdates.phone !== undefined ? String(safeUpdates.phone).replace(/\s+/g, '') : existing.phone;
  const emailChanged = nextEmail !== (existing.email || '').toLowerCase();
  const phoneChanged = nextPhone !== (existing.phone || '').replace(/\s+/g, '');

  const merged = {
    ...existing,
    ...safeUpdates,
    email: nextEmail,
    phone: nextPhone,
    emailVerified: emailChanged ? false : Boolean(existing.emailVerified),
    phoneVerified: phoneChanged ? false : Boolean(existing.phoneVerified),
    updatedAt: new Date().toISOString(),
  };
  upsertDoc(USERS_COL, uid, merged);
  return stripSensitive(merged);
}

export function verifyUserContact(uid, channel) {
  const existing = getDoc(USERS_COL, uid, null);
  if (!existing) throw new Error('User not found.');
  if (channel !== 'email' && channel !== 'phone') {
    throw new Error('Verification channel must be email or phone.');
  }
  if (channel === 'email' && !String(existing.email || '').trim()) {
    throw new Error('Add an email address before verifying.');
  }
  if (channel === 'phone' && !String(existing.phone || '').trim()) {
    throw new Error('Add a valid mobile number before verifying.');
  }
  const nowIso = new Date().toISOString();
  const merged = {
    ...existing,
    ...(channel === 'email' ? { emailVerified: true, emailVerifiedAt: nowIso } : {}),
    ...(channel === 'phone' ? { phoneVerified: true, phoneVerifiedAt: nowIso } : {}),
    updatedAt: nowIso,
  };
  upsertDoc(USERS_COL, uid, merged);
  return stripSensitive(merged);
}

export function prepareGoogleOAuthDescriptor() {
  return {
    provider: 'google.com',
    ready: false,
    mode: 'future-firebase-auth',
    message: 'Google Sign-In architecture is prepared for Firebase Auth (project: fliex-price). Sign in with email and password in local prototype mode.',
  };
}

export function stripSensitive(user) {
  if (!user) return null;
  const { passwordHash: _ph, salt: _s, ...safe } = user;
  return safe;
}

export const authAdapter = {
  registerUser,
  authenticateUser,
  getCurrentSessionUser,
  logoutSession,
  resetUserPassword,
  updateUserProfile,
  verifyUserContact,
  hasAnyAdminUser,
  prepareGoogleOAuthDescriptor,
};
