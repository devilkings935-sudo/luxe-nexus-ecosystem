/**
 * LUXE NEXUS Product Variant Selection, Color Family, Stock & Quantity Validation Service
 */

import { roundMoney, sanitizeUrl } from '../shared/utilities.js';

function parseListField(raw) {
  if (Array.isArray(raw)) {
    return raw.map((x) => String(x || '').trim()).filter(Boolean);
  }
  return String(raw || '')
    .split(',')
    .map((x) => x.trim())
    .filter(Boolean);
}

/**
 * Build normalized Color Family options for a product from its real data.
 * Uses product.colorVariants / product.colorImages / product.variants when available,
 * and falls back cleanly across product.images and product.image.
 */
export function buildProductColorOptions(product) {
  if (!product) return [];
  const rawColors = parseListField(product.colors);
  const colorVariants = Array.isArray(product.colorVariants) ? product.colorVariants : [];
  const variants = Array.isArray(product.variants) ? product.variants : [];
  const colorImages = product.colorImages && typeof product.colorImages === 'object' ? product.colorImages : {};
  const gallery = (Array.isArray(product.images) && product.images.length ? product.images : [product.image])
    .map((u) => sanitizeUrl(u, true))
    .filter(Boolean);
  const fallbackImg = sanitizeUrl(product.image, true) || gallery[0] || '';
  const baseStock = Math.max(0, Number(product.stock ?? 0));
  const isProductLive = product.active !== false && product.approved !== false;

  const names = rawColors.length
    ? rawColors
    : [...new Set(colorVariants.map((cv) => String(cv?.name || '').trim()).filter(Boolean))];

  return names.map((name, idx) => {
    const cvMatch = colorVariants.find((cv) => String(cv?.name || '').toLowerCase() === name.toLowerCase());
    const matchingVariants = variants.filter((v) => String(v?.color || '').toLowerCase() === name.toLowerCase());
    let stock = baseStock;
    if (matchingVariants.length) {
      stock = matchingVariants.reduce((sum, v) => sum + Math.max(0, Number(v?.stock ?? 0)), 0);
    } else if (cvMatch && cvMatch.stock !== undefined && cvMatch.stock !== null) {
      stock = Math.max(0, Number(cvMatch.stock));
    }

    const explicitImg = sanitizeUrl(cvMatch?.image || colorImages[name] || '', true);
    const indexedGalleryImg = gallery[idx % (gallery.length || 1)] || fallbackImg;
    const image = explicitImg || indexedGalleryImg || fallbackImg;

    return {
      name,
      image,
      stock,
      available: isProductLive && stock > 0,
    };
  });
}

/**
 * Build normalized Size options for a product, optionally scoped by selectedColor.
 */
export function buildProductSizeOptions(product, selectedColor = '') {
  if (!product) return [];
  const rawSizes = parseListField(product.sizes);
  const variants = Array.isArray(product.variants) ? product.variants : [];
  const sizeStocks = product.sizeStocks && typeof product.sizeStocks === 'object' ? product.sizeStocks : {};
  const baseStock = Math.max(0, Number(product.stock ?? 0));
  const isProductLive = product.active !== false && product.approved !== false;

  return rawSizes.map((name) => {
    let stock = baseStock;
    if (variants.length) {
      const sizeMatches = variants.filter((v) => {
        const sizeOk = String(v?.size || '').toLowerCase() === name.toLowerCase();
        if (!selectedColor) return sizeOk;
        const colorOk = !v?.color || String(v.color).toLowerCase() === selectedColor.toLowerCase();
        return sizeOk && colorOk;
      });
      stock = sizeMatches.length
        ? sizeMatches.reduce((sum, v) => sum + Math.max(0, Number(v?.stock ?? 0)), 0)
        : 0;
    } else if (sizeStocks[name] !== undefined && sizeStocks[name] !== null) {
      stock = Math.max(0, Number(sizeStocks[name]));
    }

    return {
      name,
      stock,
      available: isProductLive && stock > 0,
    };
  });
}

/**
 * Resolve exact available stock for the chosen (color, size) combination.
 */
export function resolveVariantStock(product, { color = '', size = '' } = {}) {
  if (!product || product.active === false || product.approved === false) return 0;
  const baseStock = Math.max(0, Number(product.stock ?? 0));
  const variants = Array.isArray(product.variants) ? product.variants : [];
  if (variants.length) {
    const matched = variants.filter((v) => {
      const colorOk = !color || !v?.color || String(v.color).toLowerCase() === String(color).toLowerCase();
      const sizeOk = !size || !v?.size || String(v.size).toLowerCase() === String(size).toLowerCase();
      return colorOk && sizeOk;
    });
    if (matched.length) {
      return matched.reduce((sum, v) => sum + Math.max(0, Number(v?.stock ?? 0)), 0);
    }
    return 0;
  }

  let effective = baseStock;
  if (color) {
    const colorOpt = buildProductColorOptions(product).find((c) => c.name.toLowerCase() === String(color).toLowerCase());
    if (colorOpt) effective = Math.min(effective, colorOpt.stock);
  }
  if (size) {
    const sizeOpt = buildProductSizeOptions(product, color).find((s) => s.name.toLowerCase() === String(size).toLowerCase());
    if (sizeOpt) effective = Math.min(effective, sizeOpt.stock);
  }
  return Math.max(0, effective);
}

/**
 * Clamp quantity strictly between 1 and available stock (or 0 if out of stock).
 */
export function clampVariantQty(requestedQty, availableStock) {
  const stock = Math.max(0, Math.floor(Number(availableStock ?? 0)));
  if (stock <= 0) return 0;
  const clean = Math.floor(Number(requestedQty || 1));
  if (!Number.isFinite(clean) || clean < 1) return 1;
  return Math.min(stock, clean);
}

/**
 * Resolve default selectable variants (first available color + first available size).
 */
export function resolveDefaultVariantSelection(product) {
  const colorOpts = buildProductColorOptions(product);
  const firstColor = colorOpts.find((c) => c.available)?.name || colorOpts[0]?.name || '';
  const sizeOpts = buildProductSizeOptions(product, firstColor);
  const firstSize = sizeOpts.find((s) => s.available)?.name || sizeOpts[0]?.name || '';
  const availableStock = resolveVariantStock(product, { color: firstColor, size: firstSize });
  return {
    color: firstColor,
    size: firstSize,
    qty: availableStock > 0 ? 1 : 0,
    availableStock,
  };
}

/**
 * Validate complete Buy Now variant selection & compute authoritative totals.
 */
export function validateBuyNowSelection(product, { color = '', size = '', qty = 1 } = {}) {
  if (!product || !product.id) {
    return { valid: false, error: 'Product not found.' };
  }
  if (product.active === false || product.approved === false) {
    return { valid: false, error: 'This product is currently unavailable.' };
  }
  if (Number(product.stock ?? 0) <= 0) {
    return { valid: false, error: 'This product is currently out of stock.' };
  }

  const colorOpts = buildProductColorOptions(product);
  const chosenColor = String(color || '').trim();
  if (colorOpts.length) {
    const matchedColor = colorOpts.find((c) => c.name.toLowerCase() === chosenColor.toLowerCase());
    if (!matchedColor) {
      return { valid: false, error: 'Please select a color option.' };
    }
    if (!matchedColor.available) {
      return { valid: false, error: `"${matchedColor.name}" is currently out of stock.` };
    }
  }

  const sizeOpts = buildProductSizeOptions(product, chosenColor);
  const chosenSize = String(size || '').trim();
  if (sizeOpts.length) {
    const matchedSize = sizeOpts.find((s) => s.name.toLowerCase() === chosenSize.toLowerCase());
    if (!matchedSize) {
      return { valid: false, error: 'Please select a size option.' };
    }
    if (!matchedSize.available) {
      return { valid: false, error: `Size "${matchedSize.name}" is currently out of stock.` };
    }
  }

  const availableStock = resolveVariantStock(product, { color: chosenColor, size: chosenSize });
  if (availableStock <= 0) {
    return { valid: false, error: 'Selected variant is currently out of stock.' };
  }

  const cleanQty = Math.floor(Number(qty || 0));
  if (!Number.isFinite(cleanQty) || cleanQty < 1) {
    return { valid: false, error: 'Minimum quantity is 1.' };
  }
  if (cleanQty > availableStock) {
    return { valid: false, error: `Only ${availableStock} ${availableStock === 1 ? 'item' : 'items'} available in stock.` };
  }

  const unitPrice = roundMoney(product.offerPrice || product.price);
  const regularPrice = roundMoney(product.price);
  const discountPercent =
    regularPrice > unitPrice ? Number(product.discountPercent || Math.round(((regularPrice - unitPrice) / regularPrice) * 100)) : 0;
  const colorMatch = colorOpts.find((c) => c.name.toLowerCase() === chosenColor.toLowerCase());
  const image = colorMatch?.image || sanitizeUrl(product.image || (product.images && product.images[0]) || '', true);

  return {
    valid: true,
    normalized: {
      productId: product.id,
      name: product.name,
      category: product.cat || '',
      color: chosenColor,
      size: chosenSize,
      qty: cleanQty,
      unitPrice,
      regularPrice,
      discountPercent,
      totalPrice: roundMoney(unitPrice * cleanQty),
      regularTotalPrice: roundMoney(regularPrice * cleanQty),
      image,
      availableStock,
    },
  };
}
