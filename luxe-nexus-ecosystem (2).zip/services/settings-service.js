/**
 * LUXE NEXUS Settings, Configuration, Homepage Builder, Navigation & Internationalization Service
 */

import { appServices, assertPermission, recordAuditLog } from '../adapters/backend-adapter.js';
import {
  DEFAULT_CONFIG,
  DEFAULT_HERO_SLIDER_SETTINGS,
  OFFICIAL_LOGO_URL,
  SEED_CATEGORIES,
  SEED_PRODUCTS,
  SEED_SELLERS,
  SEED_ANNOUNCEMENTS,
  SEED_VERSIONS,
} from '../shared/configuration.js';
import { canAccessFeature } from '../shared/permissions.js';
import { isWithinSchedule, sanitizeUrl, generateId } from '../shared/utilities.js';

export function ensureEcosystemSeeded() {
  appServices.storage.seedIfEmpty('platformSettings', DEFAULT_CONFIG);
  appServices.storage.seedIfEmpty('categories', SEED_CATEGORIES);
  appServices.storage.seedIfEmpty('products', SEED_PRODUCTS);
  appServices.storage.seedIfEmpty('sellers', SEED_SELLERS);
  appServices.storage.seedIfEmpty('announcements', SEED_ANNOUNCEMENTS);
  appServices.storage.seedIfEmpty('appVersions', SEED_VERSIONS);
}

export function getPlatformConfig() {
  ensureEcosystemSeeded();
  const stored = appServices.settings.getConfig() || {};
  const isLegacyLight =
    stored.themeVersion !== DEFAULT_CONFIG.themeVersion &&
    (stored.background === '#F7F8FA' || stored.primary === '#233B65' || !stored.themeVersion);

  const migratedColors = isLegacyLight
    ? {
        primary: DEFAULT_CONFIG.primary,
        accentGold: DEFAULT_CONFIG.accentGold,
        accentBlue: DEFAULT_CONFIG.accentBlue,
        background: DEFAULT_CONFIG.background,
        card: DEFAULT_CONFIG.card,
        secondarySurface: DEFAULT_CONFIG.secondarySurface,
        text: DEFAULT_CONFIG.text,
        secondaryText: DEFAULT_CONFIG.secondaryText,
        border: DEFAULT_CONFIG.border,
        themeVersion: DEFAULT_CONFIG.themeVersion,
      }
    : {};

  const rawSections = Array.isArray(stored.sections) && stored.sections.length ? stored.sections : DEFAULT_CONFIG.sections;
  let normalizedSections = rawSections;
  if (stored.sections && stored.sectionsLayoutVersion !== DEFAULT_CONFIG.sectionsLayoutVersion) {
    const heroSec = rawSections.find((s) => s.type === 'hero');
    const catSec = rawSections.find((s) => s.type === 'categories');
    if (heroSec && catSec && Number(heroSec.order || 0) < Number(catSec.order || 0)) {
      normalizedSections = rawSections.map((s) => {
        if (s.type === 'categories') return { ...s, order: Number(heroSec.order || 1) };
        if (s.type === 'hero') return { ...s, order: Number(catSec.order || 2) };
        return s;
      });
    }
  }

  return {
    ...DEFAULT_CONFIG,
    ...stored,
    ...migratedColors,
    logo: stored.logo || OFFICIAL_LOGO_URL,
    heroSlider: { ...DEFAULT_HERO_SLIDER_SETTINGS, ...(stored.heroSlider || {}) },
    checkout: { ...DEFAULT_CONFIG.checkout, ...(stored.checkout || {}) },
    international: {
      ...DEFAULT_CONFIG.international,
      ...(stored.international || {}),
      exchangeRates: {
        ...DEFAULT_CONFIG.international.exchangeRates,
        ...(stored.international?.exchangeRates || {}),
      },
    },
    affiliateConfig: {
      ...DEFAULT_CONFIG.affiliateConfig,
      ...(stored.affiliateConfig || {}),
      levels:
        Array.isArray(stored.affiliateConfig?.levels) && stored.affiliateConfig.levels.length === 4
          ? stored.affiliateConfig.levels
          : DEFAULT_CONFIG.affiliateConfig.levels,
      categoryRates: {
        ...DEFAULT_CONFIG.affiliateConfig.categoryRates,
        ...(stored.affiliateConfig?.categoryRates || {}),
      },
      productRates: {
        ...DEFAULT_CONFIG.affiliateConfig.productRates,
        ...(stored.affiliateConfig?.productRates || {}),
      },
    },
    platformFlags: { ...DEFAULT_CONFIG.platformFlags, ...(stored.platformFlags || {}) },
    featureFlags: { ...DEFAULT_CONFIG.featureFlags, ...(stored.featureFlags || {}) },
    navigation: { ...DEFAULT_CONFIG.navigation, ...(stored.navigation || {}) },
    pages: { ...DEFAULT_CONFIG.pages, ...(stored.pages || {}) },
    sectionsLayoutVersion: DEFAULT_CONFIG.sectionsLayoutVersion,
    sections: normalizedSections,
  };
}

export function updatePlatformConfig(partialConfig, actor = { uid: 'admin', role: 'super_admin' }) {
  assertPermission(actor.role, 'manage_settings');
  const current = getPlatformConfig();
  const next = {
    ...current,
    ...partialConfig,
    sectionsLayoutVersion: DEFAULT_CONFIG.sectionsLayoutVersion,
    updatedAt: new Date().toISOString(),
  };
  appServices.settings.saveConfig(next);
  recordAuditLog({
    actorId: actor.uid,
    actorRole: actor.role,
    action: 'UPDATE_PLATFORM_CONFIG',
    targetCollection: 'platformSettings',
    targetId: 'main',
    details: Object.keys(partialConfig || {}).join(', '),
  });
  return next;
}

export function isFeatureEnabled(featureKey, role = 'customer') {
  const cfg = getPlatformConfig();
  if (featureKey === 'affiliateProgram' && cfg.platformFlags?.affiliateProgramEnabled === false) {
    return false;
  }
  if (featureKey === 'sellerRegistration' && cfg.platformFlags?.sellerRegistrationEnabled === false) {
    return false;
  }
  const flag = cfg.featureFlags?.[featureKey];
  return canAccessFeature(flag, role);
}

export function getFeatureStatus(featureKey, role = 'customer') {
  const cfg = getPlatformConfig();
  const flag = cfg.featureFlags?.[featureKey] || { enabled: true, visible: true };
  const enabled = isFeatureEnabled(featureKey, role);
  return {
    enabled,
    visible: flag.visible !== false && enabled,
    maintenanceMessage: flag.maintenanceMessage || 'This feature is temporarily unavailable.',
  };
}

export function getActiveHomepageSections(nowMs = Date.now()) {
  const cfg = getPlatformConfig();
  return [...(cfg.sections || [])]
    .filter((s) => s.enabled !== false && s.visible !== false && isWithinSchedule(s.startDate, s.endDate, nowMs))
    .sort((a, b) => Number(a.order || 0) - Number(b.order || 0));
}

export function getActiveNavigation(navKey = 'bottomNav', role = 'customer') {
  const cfg = getPlatformConfig();
  const list = cfg.navigation?.[navKey] || [];
  return [...list]
    .filter((item) => {
      if (item.enabled === false || item.visible === false) return false;
      if (item.id === 'affiliate' && !isFeatureEnabled('affiliateProgram', role)) return false;
      if (item.id === 'wishlist' && !isFeatureEnabled('wishlist', role)) return false;
      if (item.id === 'compare' && !isFeatureEnabled('productComparison', role)) return false;
      if (item.id === 'orders' && !isFeatureEnabled('orderHistory', role)) return false;
      if (item.id === 'addresses' && !isFeatureEnabled('addressBook', role)) return false;
      if (item.id === 'payments' && !isFeatureEnabled('paymentMethods', role)) return false;
      if (item.id === 'support' && !isFeatureEnabled('support', role)) return false;
      return true;
    })
    .sort((a, b) => Number(a.order || 0) - Number(b.order || 0));
}

export function getActiveAnnouncements(audience = 'user', nowMs = Date.now()) {
  ensureEcosystemSeeded();
  const list = appServices.announcements.list();
  return list.filter((a) => {
    if (!a.active) return false;
    if (a.targetAudience && a.targetAudience !== 'all' && a.targetAudience !== audience) return false;
    return isWithinSchedule(a.startDate, a.endDate, nowMs);
  });
}

export function saveAnnouncement(item, actor = { uid: 'admin', role: 'super_admin' }) {
  assertPermission(actor.role, 'manage_settings');
  const record = {
    id: item.id || generateId('ANN'),
    type: item.type || 'announcement',
    title: String(item.title || '').trim(),
    description: String(item.description || '').trim(),
    image: sanitizeUrl(item.image || '', true),
    buttonText: String(item.buttonText || 'Learn More').trim(),
    buttonAction: String(item.buttonAction || 'close').trim(),
    frequency: item.frequency || 'once_per_session',
    startDate: item.startDate || '',
    endDate: item.endDate || '',
    targetAudience: item.targetAudience || 'all',
    dismissible: item.dismissible !== false,
    mandatory: !!item.mandatory,
    active: item.active !== false,
    updatedAt: new Date().toISOString(),
  };
  appServices.announcements.upsert(record.id, record);
  return record;
}

export function deleteAnnouncement(id, actor = { uid: 'admin', role: 'super_admin' }) {
  assertPermission(actor.role, 'manage_settings');
  return appServices.announcements.remove(id);
}

export function getUserInternationalPrefs() {
  const cfg = getPlatformConfig();
  const saved = appServices.storage.getCollection('userIntlPrefs', null);
  return {
    language: saved?.language || cfg.international.language || 'en',
    country: saved?.country || cfg.international.country || 'Bangladesh',
    currency: saved?.currency || cfg.international.currency || 'BDT',
    region: saved?.region || cfg.international.region || 'South Asia',
  };
}

export function setUserInternationalPrefs(prefs) {
  const current = getUserInternationalPrefs();
  const next = { ...current, ...prefs };
  appServices.storage.setCollection('userIntlPrefs', next);
  return next;
}

export const TRANSLATIONS = {
  en: {
    home: 'Home',
    categories: 'Categories',
    affiliate: 'Affiliate Program',
    orders: 'My Orders',
    account: 'My Account',
    featured: 'Featured Products',
    trending: 'Trending Now',
    newArrivals: 'New Arrivals',
    bestSellers: 'Best Sellers',
    recommended: 'Recommended For You',
    addToCart: 'Add to Cart',
    buyNow: 'Buy Now',
    seeMore: 'See More',
    checkout: 'Checkout',
    cart: 'Shopping Cart',
    inStock: 'In Stock',
    outOfStock: 'Out of Stock',
  },
  bn: {
    home: 'হোম',
    categories: 'ক্যাটাগরি',
    affiliate: 'অ্যাফিলিয়েট প্রোগ্রাম',
    orders: 'আমার অর্ডার',
    account: 'আমার অ্যাকাউন্ট',
    featured: 'বাছাইকৃত পণ্য',
    trending: 'জনপ্রিয় এখন',
    newArrivals: 'নতুন কালেকশন',
    bestSellers: 'সেরা বিক্রিত',
    recommended: 'আপনার জন্য পরামর্শ',
    addToCart: 'কার্টে যোগ করুন',
    buyNow: 'এখনই কিনুন',
    seeMore: 'আরও দেখুন',
    checkout: 'চেকআউট',
    cart: 'শপিং কার্ট',
    inStock: 'স্টকে আছে',
    outOfStock: 'স্টক শেষ',
  },
};

export function t(key, lang = 'en') {
  return (TRANSLATIONS[lang] && TRANSLATIONS[lang][key]) || TRANSLATIONS.en[key] || key;
}

export function applyDesignTokensToDocument(cfg = getPlatformConfig()) {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;
  const isLightAtelier = document.body?.classList?.contains('light-atelier');

  if (isLightAtelier) {
    root.style.setProperty('--bg', '#FAF8F5');
    root.style.setProperty('--surface', '#FFFFFF');
    root.style.setProperty('--surface-2', '#F3EEE8');
    root.style.setProperty('--text', '#1A1416');
    root.style.setProperty('--text-muted', '#6E6266');
    root.style.setProperty('--brand', '#6E1826');
    root.style.setProperty('--gold', '#9E7B34');
    root.style.setProperty('--accent-blue', '#9E7B34');
    root.style.setProperty('--border', '#E6DDD4');
  } else {
    root.style.setProperty('--bg', cfg.background || '#0B0B0D');
    root.style.setProperty('--surface', cfg.card || '#141418');
    root.style.setProperty('--surface-2', cfg.secondarySurface || '#1C1B20');
    root.style.setProperty('--text', cfg.text || '#F5F1E8');
    root.style.setProperty('--text-muted', cfg.secondaryText || '#A8A095');
    root.style.setProperty('--brand', cfg.primary || '#6E1826');
    root.style.setProperty('--gold', cfg.accentGold || '#C9A45C');
    root.style.setProperty('--accent-blue', cfg.accentBlue || '#C9A45C');
    root.style.setProperty('--border', cfg.border || '#2B2528');
  }

  const radiusMap = { square: '4px', rounded: '10px', pill: '999px' };
  root.style.setProperty('--btn-radius', radiusMap[cfg.buttonShape] || '10px');

  let customStyleEl = document.getElementById('ln-admin-custom-css');
  if (!customStyleEl) {
    customStyleEl = document.createElement('style');
    customStyleEl.id = 'ln-admin-custom-css';
    document.head.appendChild(customStyleEl);
  }
  // Strip any closing style tags to prevent injection
  customStyleEl.textContent = String(cfg.customCss || '').replace(/<\/style/gi, '');
}
