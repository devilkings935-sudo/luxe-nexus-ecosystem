/**
 * LUXE NEXUS Advanced Affiliate Marketing Service (PART 8 + Eligibility, 10 Rules & 4-Tier Level System)
 * Includes 72h account age & profile verification gates, 10 enforceable program rules,
 * 4-tier Affiliate Level progression (Bronze, Silver, Gold, Diamond) with auto upgrade/downgrade,
 * 7-day (168h) server-reference link expiry, anti-fraud guards, holds/suspensions/bans,
 * commission lifecycle, and atomic withdrawal balance reservation.
 */

import { appServices, assertPermission, assertFeatureEnabled, recordAuditLog } from '../adapters/backend-adapter.js';
import { validateAffiliateApplication, validateWithdrawalRequest, validatePhone } from '../shared/validators.js';
import { DEFAULT_CONFIG } from '../shared/configuration.js';
import { generateId, roundMoney, sanitizeUrl } from '../shared/utilities.js';
import { ROLES } from '../shared/permissions.js';
import { getPlatformConfig } from './settings-service.js';
import { pushNotification } from './notification-service.js';

const CLOCK_WATERMARK_KEY = 'affiliate_server_clock_ms';
const ACTIVE_ATTRIBUTION_KEY = 'active_affiliate_attribution';

export const AFFILIATE_PROGRAM_RULES = [
  {
    id: 1,
    code: 'NO_SELF_REFERRAL',
    title: 'নিজের রেফারেল লিংকে নিজের অর্ডার নিষিদ্ধ',
    description: 'Affiliates cannot earn commissions on orders placed from their own account, email, or phone number.',
  },
  {
    id: 2,
    code: 'NO_MULTIPLE_ACCOUNTS',
    title: 'একাধিক বা ভুয়া অ্যাকাউন্ট খোলা যাবে না',
    description: 'Each creator may hold only one verified affiliate account. Duplicate phone numbers or channels are blocked.',
  },
  {
    id: 3,
    code: 'NO_FAKE_ORDERS_TRAFFIC',
    title: 'ভুয়া অর্ডার, ভুয়া ট্রাফিক বা প্রতারণামূলক প্রচারণা নিষিদ্ধ',
    description: 'Automated clicks, bot traffic, fake orders, or manipulated conversions result in immediate cancellation and ban.',
  },
  {
    id: 4,
    code: 'NO_SPAM_MISLEADING',
    title: 'স্প্যাম, বিভ্রান্তিকর বিজ্ঞাপন বা মিথ্যা তথ্য দিয়ে প্রচারণা নিষিদ্ধ',
    description: 'Do not use spam messages, deceptive discounts, or false product claims when promoting LUXE NEXUS items.',
  },
  {
    id: 5,
    code: 'CANCELLED_REFUNDED_NO_COMM',
    title: 'অর্ডার Cancel বা Refund হলে কোনো কমিশন পাওয়া যাবে না',
    description: 'Commissions are automatically reversed if an attributed order is cancelled, rejected, or refunded.',
  },
  {
    id: 6,
    code: 'ADMIN_COMMISSION_WITHDRAWAL_RULES',
    title: 'কমিশন ও উত্তোলনের নিয়ম Admin সেটিংস অনুযায়ী প্রযোজ্য হবে',
    description: 'Payout thresholds, link validity hours, level rates, and supported payout rails follow live Admin configuration.',
  },
  {
    id: 7,
    code: 'SUSPICIOUS_ACTIVITY_HOLD',
    title: 'সন্দেহজনক কার্যকলাপ দেখলে কমিশন বা উত্তোলন সাময়িকভাবে Hold করা হতে পারে',
    description: 'Admin may place a temporary Hold on commissions or withdrawals while verifying traffic quality or order authenticity.',
  },
  {
    id: 8,
    code: 'VIOLATION_SUSPEND_BAN',
    title: 'নিয়ম ভঙ্গ করলে অ্যাকাউন্ট Suspend বা Ban করা হতে পারে',
    description: 'Breaching affiliate policies can trigger temporary account suspension or permanent affiliate program ban.',
  },
  {
    id: 9,
    code: 'ADMIN_VERIFICATION_CONTROL',
    title: 'আবেদন ও কমিশন যাচাই-বাছাইয়ের পূর্ণ ক্ষমতা Admin-এর থাকবে',
    description: 'Every application, level adjustment, referral commission, and payout request is subject to Admin review.',
  },
  {
    id: 10,
    code: 'ADMIN_SETTINGS_AUTHORITY',
    title: 'Admin যেকোনো সময় Affiliate Program-এর নিয়ম ও সেটিংস পরিবর্তন করতে পারবে',
    description: 'Admin controls eligibility requirements, tier targets, commission percentages, cooldowns, and program availability.',
  },
];

/**
 * Monotonic server-reference timestamp guard:
 * Prevents mobile clock rollbacks from extending expired 168-hour links.
 */
export function getTrustedServerTimestamp(overrideNowMs = null) {
  if (typeof overrideNowMs === 'number' && Number.isFinite(overrideNowMs)) {
    return overrideNowMs;
  }
  const now = Date.now();
  const stored = Number(appServices.storage.getCollection(CLOCK_WATERMARK_KEY, 0));
  const trusted = Math.max(now, Number.isFinite(stored) ? stored : 0);
  appServices.storage.setCollection(CLOCK_WATERMARK_KEY, trusted);
  return trusted;
}

export function getAffiliateLevels(config = getPlatformConfig()) {
  const configured = config?.affiliateConfig?.levels;
  const fallback = DEFAULT_CONFIG.affiliateConfig.levels;
  const source = Array.isArray(configured) && configured.length ? configured : fallback;
  return [...source]
    .map((lvl, idx) => ({
      id: String(lvl.id || `tier-${idx + 1}`).toLowerCase(),
      name: String(lvl.name || `Tier ${idx + 1}`),
      subtitle: String(lvl.subtitle || ''),
      order: Number(lvl.order ?? idx + 1),
      commissionRate: Number(lvl.commissionRate ?? 8),
      minOrders: Math.max(0, Number(lvl.minOrders ?? 0)),
      minSales: Math.max(0, Number(lvl.minSales ?? 0)),
      retainOrdersInWindow: Math.max(0, Number(lvl.retainOrdersInWindow ?? 0)),
      retainSalesInWindow: Math.max(0, Number(lvl.retainSalesInWindow ?? 0)),
      badgeColor: String(lvl.badgeColor || '#CD7F32'),
      benefits: Array.isArray(lvl.benefits) ? lvl.benefits : [],
    }))
    .sort((a, b) => a.order - b.order);
}

export function getAffiliateLevelConfig(levelId = 'bronze', config = getPlatformConfig()) {
  const levels = getAffiliateLevels(config);
  const key = String(levelId || 'bronze').toLowerCase();
  return levels.find((l) => l.id === key) || levels[0];
}

export function computeUserAge(user, fallbackAge = null, nowOverrideMs = null) {
  const nowMs = getTrustedServerTimestamp(nowOverrideMs);
  if (user?.dateOfBirth) {
    const dobMs = Date.parse(user.dateOfBirth);
    if (Number.isFinite(dobMs) && dobMs < nowMs) {
      const nowDate = new Date(nowMs);
      const dobDate = new Date(dobMs);
      let years = nowDate.getUTCFullYear() - dobDate.getUTCFullYear();
      const mDiff = nowDate.getUTCMonth() - dobDate.getUTCMonth();
      if (mDiff < 0 || (mDiff === 0 && nowDate.getUTCDate() < dobDate.getUTCDate())) {
        years -= 1;
      }
      if (years >= 0) return years;
    }
  }
  const raw = fallbackAge !== null && fallbackAge !== undefined && fallbackAge !== '' ? fallbackAge : user?.age;
  const parsed = Number(raw);
  return Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : null;
}

/**
 * Evaluates all Admin-configurable eligibility criteria before a user can submit an affiliate application.
 * @param {any} user
 * @param {any} [existingAff]
 * @param {any} [config]
 * @param {number | null} [nowOverrideMs]
 * @param {any} [overrides]
 */
export function evaluateAffiliateEligibility(
  user,
  existingAff = null,
  config = getPlatformConfig(),
  nowOverrideMs = null,
  overrides = {}
) {
  const affCfg = config?.affiliateConfig || {};
  const minAccountAgeHours = Math.max(0, Number(affCfg.minAccountAgeHours ?? 72));
  const minApplicantAge = Math.max(13, Number(affCfg.minApplicantAge ?? 18));
  const requireEmailVerification = affCfg.requireEmailVerification !== false;
  const requirePhoneVerification = affCfg.requirePhoneVerification !== false;
  const requireCompleteProfile = affCfg.requireCompleteProfile !== false;
  const requireSocialOrWebsite = affCfg.requireSocialOrWebsite !== false;
  const reapplyCooldownHours = Math.max(0, Number(affCfg.reapplyCooldownHours ?? 168));
  const nowMs = getTrustedServerTimestamp(nowOverrideMs);

  const checks = [];
  let banned = false;
  let cooldownBlocked = false;
  let cooldownRemainingHours = 0;

  if (!user) {
    return {
      eligible: false,
      banned: false,
      cooldownBlocked: false,
      cooldownRemainingHours: 0,
      accountAgeHours: 0,
      remainingAccountHours: minAccountAgeHours,
      age: null,
      checks: [{ key: 'auth', label: 'Signed-in User Account', passed: false, detail: 'Please sign in first.' }],
      blockingReason: 'Please sign in to your LUXE NEXUS account first.',
    };
  }

  if (existingAff?.status === 'banned') {
    banned = true;
    checks.push({
      key: 'ban',
      label: 'Account Standing',
      passed: false,
      detail: `Permanently banned${existingAff.rejectionReason ? `: ${existingAff.rejectionReason}` : '.'}`,
    });
  }

  if (existingAff?.status === 'rejected') {
    const rejectedAt = Number(existingAff.rejectedAtMs || Date.parse(existingAff.updatedAt || '') || 0);
    const reapplyAfter = Number(
      existingAff.reapplyAfterMs || (rejectedAt ? rejectedAt + reapplyCooldownHours * 3600000 : 0)
    );
    if (reapplyAfter > nowMs) {
      cooldownBlocked = true;
      cooldownRemainingHours = Math.ceil((reapplyAfter - nowMs) / 3600000);
      checks.push({
        key: 'cooldown',
        label: 'Reapplication Cooldown',
        passed: false,
        detail: `Wait ${cooldownRemainingHours}h before reapplying after rejection.`,
      });
    } else {
      checks.push({
        key: 'cooldown',
        label: 'Reapplication Cooldown',
        passed: true,
        detail: 'Cooldown period completed — eligible to reapply.',
      });
    }
  }

  // 1. Account age >= 72h (configurable)
  const createdMs = Date.parse(user.createdAt || '') || nowMs;
  const elapsedMs = Math.max(0, nowMs - createdMs);
  const accountAgeHours = Math.floor(elapsedMs / 3600000);
  const remainingAccountHours = Math.max(0, Math.ceil((minAccountAgeHours * 3600000 - elapsedMs) / 3600000));
  const accountAgePassed = elapsedMs >= minAccountAgeHours * 3600000;
  checks.push({
    key: 'accountAge',
    label: `Account Age (${minAccountAgeHours}h / ${Math.round(minAccountAgeHours / 24)} Days)`,
    passed: accountAgePassed,
    detail: accountAgePassed
      ? `${accountAgeHours}h completed`
      : `${accountAgeHours}h / ${minAccountAgeHours}h (${remainingAccountHours}h remaining)`,
  });

  // 2. Age >= 18 (configurable)
  const age = computeUserAge(user, overrides.age ?? null, nowMs);
  const agePassed = age !== null && age >= minApplicantAge;
  checks.push({
    key: 'age',
    label: `Minimum Age (${minApplicantAge}+ Years)`,
    passed: agePassed,
    detail: age !== null ? `Age ${age} ${agePassed ? 'verified' : `(must be ${minApplicantAge}+)`}` : 'Add Date of Birth or Age in Profile',
  });

  // 3. Email verification
  const emailVerified = Boolean(user.emailVerified);
  const emailPassed = !requireEmailVerification || (Boolean(user.email) && emailVerified);
  checks.push({
    key: 'emailVerified',
    label: 'Verified Email Address',
    passed: emailPassed,
    detail: emailPassed ? `${user.email} verified` : 'Verify your email in My Account',
  });

  // 4. Phone verification
  const activePhone = overrides.phone ?? user.phone;
  const phoneVerified = Boolean(user.phoneVerified) && validatePhone(activePhone);
  const phonePassed = !requirePhoneVerification || phoneVerified;
  checks.push({
    key: 'phoneVerified',
    label: 'Verified Mobile Number',
    passed: phonePassed,
    detail: phonePassed ? `${activePhone} verified` : 'Add & verify mobile number in My Account',
  });

  // 5. Complete Profile
  const effName = String(overrides.name ?? user.name ?? '').trim();
  const effCity = String(overrides.city ?? user.city ?? '').trim() || (user.addresses?.length ? user.addresses[0]?.district || 'Saved' : '');
  const profileComplete =
    effName.length >= 2 &&
    Boolean(user.email) &&
    validatePhone(activePhone) &&
    agePassed &&
    Boolean(effCity);
  const profilePassed = !requireCompleteProfile || profileComplete;
  checks.push({
    key: 'profileComplete',
    label: 'Complete Profile Details',
    passed: profilePassed,
    detail: profilePassed
      ? 'Name, contact, age & city/address complete'
      : 'Complete Full Name, Mobile, Age/DOB & City/Address in My Account',
  });

  // 6. At least one Social Media Account or Website
  const rawSocial = String(overrides.socialLink ?? user.socialUrl ?? '').trim();
  const cleanSocial = rawSocial ? sanitizeUrl(rawSocial, false) : '';
  const socialPassed = !requireSocialOrWebsite || Boolean(cleanSocial);
  checks.push({
    key: 'socialOrWebsite',
    label: 'Social Media Account or Website',
    passed: socialPassed,
    detail: socialPassed ? (cleanSocial || 'Provided') : 'Add a valid Facebook/YouTube/Instagram/TikTok or Website URL',
  });

  const firstFailure = checks.find((c) => !c.passed);
  const eligible = checks.every((c) => c.passed);

  return {
    eligible,
    banned,
    cooldownBlocked,
    cooldownRemainingHours,
    accountAgeHours,
    remainingAccountHours,
    minAccountAgeHours,
    minApplicantAge,
    age,
    checks,
    blockingReason: firstFailure ? `${firstFailure.label}: ${firstFailure.detail}` : '',
  };
}

export function getAffiliateByUserId(userId) {
  if (!userId) return null;
  const list = appServices.affiliates.affiliates.list();
  return list.find((a) => a.userId === userId) || null;
}

export function getAffiliateById(affiliateId) {
  return appServices.affiliates.affiliates.getById(affiliateId);
}

export function listAffiliates() {
  return appServices.affiliates.affiliates.list();
}

/**
 * @param {any} payload
 * @param {number | null} [nowOverrideMs]
 */
export function applyForAffiliate(payload, nowOverrideMs = null) {
  assertFeatureEnabled('affiliateProgram', 'customer');
  const cfg = getPlatformConfig();
  const affCfg = cfg.affiliateConfig || {};
  const nowMs = getTrustedServerTimestamp(nowOverrideMs);

  const user = appServices.storage.getDoc('users', payload?.userId, null);
  if (!user) {
    throw new Error('Please sign in with a valid LUXE NEXUS account before applying.');
  }

  const existing = getAffiliateByUserId(payload.userId);
  if (existing?.status === 'banned') {
    throw new Error(`Your affiliate access is permanently banned${existing.rejectionReason ? `: ${existing.rejectionReason}` : '.'}`);
  }
  if (existing && existing.status !== 'rejected') {
    throw new Error(`Affiliate account already exists with status: ${existing.status}.`);
  }

  // Enforce Eligibility Rules (72h account age, 18+ age, email/phone verified, complete profile, social URL, cooldown)
  const elig = evaluateAffiliateEligibility(user, existing, cfg, nowMs, {
    name: payload?.name,
    phone: payload?.phone,
    age: payload?.age,
    city: payload?.city,
    socialLink: payload?.socialLink,
  });
  if (!elig.eligible) {
    throw new Error(`Application requirements not met — ${elig.blockingReason}`);
  }

  const validation = validateAffiliateApplication(
    {
      ...payload,
      age: payload?.age ?? elig.age,
    },
    affCfg
  );
  if (!validation.valid) {
    throw new Error(validation.errors[0]);
  }

  // Rule #2: Anti-fraud guard against multiple/fake accounts sharing phone, email, or social URL
  const normPhone = String(payload.phone).replace(/[\s\-()]/g, '');
  const normEmail = String(payload.email).trim().toLowerCase();
  const normSocial = String(validation.cleanSocial || '').trim().toLowerCase().replace(/\/+$/, '');
  const duplicateAff = appServices.affiliates.affiliates.list().find(
    (a) =>
      a.userId !== user.uid &&
      a.status !== 'rejected' &&
      (String(a.phone || '').replace(/[\s\-()]/g, '') === normPhone ||
        String(a.email || '').trim().toLowerCase() === normEmail ||
        (normSocial && String(a.socialLink || '').trim().toLowerCase().replace(/\/+$/, '') === normSocial))
  );
  if (duplicateAff) {
    appServices.affiliates.auditLogs.upsert(generateId('AFA'), {
      id: generateId('AFA'),
      type: 'DUPLICATE_ACCOUNT_BLOCKED',
      userId: user.uid,
      matchedAffiliateId: duplicateAff.id,
      createdAt: new Date(nowMs).toISOString(),
    });
    throw new Error('Rule #2 Violation: An affiliate account with this email, mobile number, or social channel already exists.');
  }

  const bronze = getAffiliateLevelConfig('bronze', cfg);
  const nowIso = new Date(nowMs).toISOString();
  const record = {
    id: existing?.id || generateId('AFF'),
    affiliateCode: existing?.affiliateCode || `LN${Math.random().toString(36).slice(2, 7).toUpperCase()}`,
    userId: payload.userId,
    name: String(payload.name).trim(),
    phone: String(payload.phone).trim(),
    email: normEmail,
    age: elig.age,
    socialLink: validation.cleanSocial,
    followerCount: validation.followerCount,
    promotionMedium: String(payload.promotionMedium).trim(),
    marketingPlan: String(payload.marketingPlan).trim(),
    bio: String(payload.bio || payload.marketingPlan || '').trim(),
    status: 'pending',
    rejectionReason: '',
    rejectedAtMs: null,
    reapplyAfterMs: null,
    commissionHold: false,
    withdrawalHold: false,
    holdReason: '',
    level: bronze.id,
    levelAssignedAtMs: nowMs,
    manualLevelLocked: false,
    levelHistory: existing?.levelHistory || [{ level: bronze.id, at: nowIso, reason: 'Initial Tier' }],
    termsAccepted: true,
    rulesAcceptedAt: nowIso,
    createdAt: existing?.createdAt || nowIso,
    updatedAt: nowIso,
  };

  // Sync verified social/age onto user profile if missing
  if (!user.socialUrl && validation.cleanSocial) {
    appServices.storage.upsertDoc('users', user.uid, {
      ...user,
      socialUrl: validation.cleanSocial,
      age: user.age ?? elig.age,
      updatedAt: nowIso,
    });
  }

  appServices.affiliates.affiliates.upsert(record.id, record);
  pushNotification({
    audience: 'user',
    userId: record.userId,
    category: 'Affiliates',
    title: 'Affiliate Application Submitted',
    message: 'Your Affiliate Program application is pending Admin verification. Tools will unlock after approval.',
  });
  pushNotification({
    audience: 'admin',
    category: 'Affiliates',
    title: 'New Affiliate Application',
    message: `${record.name} (${record.promotionMedium}, ${record.followerCount} followers) applied to join the Affiliate Program.`,
  });

  return record;
}

/**
 * @param {string} affiliateId
 * @param {string} nextStatus
 * @param {any} actor
 * @param {string} [reason]
 * @param {number | null} [nowOverrideMs]
 */
export function updateAffiliateStatus(affiliateId, nextStatus, actor, reason = '', nowOverrideMs = null) {
  assertPermission(actor.role, nextStatus === 'approved' ? 'approve' : 'reject');
  const aff = appServices.affiliates.affiliates.getById(affiliateId);
  if (!aff) throw new Error('Affiliate profile not found.');

  if (!['approved', 'rejected', 'suspended', 'banned', 'pending'].includes(nextStatus)) {
    throw new Error('Invalid affiliate status.');
  }

  const cfg = getPlatformConfig();
  const nowMs = getTrustedServerTimestamp(nowOverrideMs);
  const nowIso = new Date(nowMs).toISOString();
  const cooldownHours = Math.max(0, Number(cfg.affiliateConfig?.reapplyCooldownHours ?? 168));
  const needsReason = ['rejected', 'suspended', 'banned'].includes(nextStatus);

  const updated = {
    ...aff,
    status: nextStatus,
    level: aff.level || 'bronze',
    levelAssignedAtMs: aff.levelAssignedAtMs || nowMs,
    rejectionReason: needsReason ? String(reason || 'Policy review') : '',
    rejectedAtMs: nextStatus === 'rejected' ? nowMs : aff.rejectedAtMs || null,
    reapplyAfterMs: nextStatus === 'rejected' ? nowMs + cooldownHours * 3600000 : aff.reapplyAfterMs || null,
    approvedAt: nextStatus === 'approved' ? nowIso : aff.approvedAt || null,
    bannedAt: nextStatus === 'banned' ? nowIso : nextStatus === 'approved' ? null : aff.bannedAt || null,
    updatedAt: nowIso,
  };
  appServices.affiliates.affiliates.upsert(affiliateId, updated);

  // If suspended or banned, disable any currently active links immediately
  if (nextStatus === 'suspended' || nextStatus === 'banned') {
    const links = appServices.affiliates.links.list();
    const nextLinks = links.map((l) =>
      l.affiliateId === affiliateId && l.status === 'active' ? { ...l, status: 'disabled' } : l
    );
    appServices.affiliates.links.saveAll(nextLinks);
  }

  // Sync user record flag cleanly
  const userDoc = appServices.storage.getDoc('users', aff.userId, null);
  if (userDoc) {
    appServices.storage.upsertDoc('users', aff.userId, {
      ...userDoc,
      affiliateId: updated.id,
      affiliateStatus: nextStatus,
      affiliateLevel: updated.level,
    });
  }

  const titleMap = {
    approved: 'Affiliate Application Approved',
    rejected: 'Affiliate Application Rejected',
    suspended: 'Affiliate Account Suspended',
    banned: 'Affiliate Account Banned',
    pending: 'Affiliate Status Updated',
  };
  pushNotification({
    audience: 'affiliate',
    userId: aff.userId,
    category: 'Affiliates',
    title: titleMap[nextStatus],
    message:
      nextStatus === 'approved'
        ? `Welcome ${aff.name}! Your Affiliate ID is ${aff.affiliateCode} (${getAffiliateLevelConfig(updated.level, cfg).name} Level).`
        : `Status changed to ${nextStatus}${updated.rejectionReason ? `: ${updated.rejectionReason}` : ''}.`,
  });

  recordAuditLog({
    actorId: actor.uid,
    actorRole: actor.role,
    action: `AFFILIATE_${nextStatus.toUpperCase()}`,
    targetCollection: 'affiliates',
    targetId: affiliateId,
    details: updated.rejectionReason || aff.email,
  });

  return updated;
}

export function adminUpdateAffiliateHolds(
  affiliateId,
  { commissionHold = false, withdrawalHold = false, holdReason = '' },
  actor
) {
  assertPermission(actor.role, 'manage_payments');
  const aff = appServices.affiliates.affiliates.getById(affiliateId);
  if (!aff) throw new Error('Affiliate profile not found.');

  const updated = {
    ...aff,
    commissionHold: Boolean(commissionHold),
    withdrawalHold: Boolean(withdrawalHold),
    holdReason: commissionHold || withdrawalHold ? String(holdReason || 'Suspicious activity verification hold') : '',
    updatedAt: new Date().toISOString(),
  };
  appServices.affiliates.affiliates.upsert(affiliateId, updated);

  pushNotification({
    audience: 'affiliate',
    userId: aff.userId,
    category: 'Affiliates',
    title: updated.commissionHold || updated.withdrawalHold ? 'Affiliate Hold Notice' : 'Affiliate Hold Released',
    message:
      updated.commissionHold || updated.withdrawalHold
        ? `Rule #7 Review: ${updated.holdReason}`
        : 'Your commission & withdrawal holds have been cleared by Admin.',
  });

  recordAuditLog({
    actorId: actor.uid,
    actorRole: actor.role,
    action: 'AFFILIATE_HOLD_UPDATE',
    targetCollection: 'affiliates',
    targetId: affiliateId,
    details: `commHold=${updated.commissionHold}, wHold=${updated.withdrawalHold}, reason=${updated.holdReason}`,
  });

  return updated;
}

/**
 * Evaluates automatic tier upgrades & performance-retention downgrades for an affiliate.
 * @param {string} affiliateId
 * @param {number | null} [nowOverrideMs]
 * @param {{ respectManualLock?: boolean }} [options]
 */
export function evaluateAffiliateLevel(affiliateId, nowOverrideMs = null, options = { respectManualLock: true }) {
  const aff = appServices.affiliates.affiliates.getById(affiliateId);
  if (!aff) return null;

  const cfg = getPlatformConfig();
  const affCfg = cfg.affiliateConfig || {};
  const levels = getAffiliateLevels(cfg);
  const currentTier = getAffiliateLevelConfig(aff.level || levels[0].id, cfg);
  const nowMs = getTrustedServerTimestamp(nowOverrideMs);
  const windowDays = Math.max(1, Number(affCfg.downgradeWindowDays ?? 30));
  const windowMs = windowDays * 86400000;

  const comms = appServices.affiliates.commissions
    .list()
    .filter((c) => c.affiliateId === affiliateId && ['approved', 'paid'].includes(c.status));

  const lifetimeOrders = comms.length;
  const lifetimeSales = roundMoney(comms.reduce((s, c) => s + Number(c.orderTotal || 0), 0));

  const recentComms = comms.filter((c) => {
    const ts = Number(c.createdAtMs || Date.parse(c.createdAt || '') || 0);
    return ts >= nowMs - windowMs && ts <= nowMs;
  });
  const recentOrders = recentComms.length;
  const recentSales = roundMoney(recentComms.reduce((s, c) => s + Number(c.orderTotal || 0), 0));

  let targetTier = currentTier;
  let changeReason = '';

  if (!(options?.respectManualLock && aff.manualLevelLocked)) {
    // 1. Auto-upgrade check based on cumulative delivered/paid performance
    if (affCfg.autoUpgradeEnabled !== false) {
      const highestUpgrade = [...levels]
        .reverse()
        .find((l) => lifetimeOrders >= l.minOrders && lifetimeSales >= l.minSales);
      if (highestUpgrade && highestUpgrade.order > currentTier.order) {
        targetTier = highestUpgrade;
        changeReason = `Auto-upgraded to ${highestUpgrade.name} (${lifetimeOrders} orders, ${lifetimeSales} sales)`;
      }
    }

    // 2. Auto-downgrade check if affiliate did not upgrade and falls below tier retention threshold
    if (
      targetTier.id === currentTier.id &&
      affCfg.autoDowngradeEnabled !== false &&
      currentTier.order > 1
    ) {
      const assignedAt = Number(aff.levelAssignedAtMs || Date.parse(aff.approvedAt || aff.createdAt || '') || nowMs);
      const windowElapsed = nowMs - assignedAt >= windowMs;
      const belowLifetimeReq = lifetimeOrders < currentTier.minOrders || lifetimeSales < currentTier.minSales;
      const belowRecentRetention =
        recentOrders < currentTier.retainOrdersInWindow || recentSales < currentTier.retainSalesInWindow;

      if (belowLifetimeReq || (windowElapsed && belowRecentRetention)) {
        // Step down to the highest tier whose retention/requirement the affiliate satisfies
        const retained = [...levels]
          .filter((l) => l.order < currentTier.order)
          .reverse()
          .find(
            (l) =>
              l.order === 1 ||
              (lifetimeOrders >= l.minOrders &&
                lifetimeSales >= l.minSales &&
                recentOrders >= l.retainOrdersInWindow &&
                recentSales >= l.retainSalesInWindow)
          );
        targetTier = retained || levels[0];
        changeReason = belowLifetimeReq
          ? `Downgraded to ${targetTier.name} due to cancelled/reversed orders below tier minimum`
          : `Downgraded to ${targetTier.name} (${windowDays}-day activity below ${currentTier.name} retention threshold)`;
      }
    }
  }

  let updatedAff = aff;
  if (targetTier.id !== currentTier.id) {
    const promoted = targetTier.order > currentTier.order;
    const nowIso = new Date(nowMs).toISOString();
    updatedAff = {
      ...aff,
      level: targetTier.id,
      levelAssignedAtMs: nowMs,
      levelHistory: [
        { level: targetTier.id, from: currentTier.id, at: nowIso, reason: changeReason },
        ...(aff.levelHistory || []),
      ].slice(0, 30),
      updatedAt: nowIso,
    };
    appServices.affiliates.affiliates.upsert(affiliateId, updatedAff);

    pushNotification({
      audience: 'affiliate',
      userId: aff.userId,
      category: 'Affiliate Level',
      title: promoted ? `Level Up: ${targetTier.name} Tier!` : `Level Adjusted: ${targetTier.name} Tier`,
      message: promoted
        ? `Congratulations! You reached ${targetTier.name} Level (${targetTier.commissionRate}% commission rate).`
        : `${changeReason}. Complete orders to climb back up!`,
    });
  }

  const nextTier = levels.find((l) => l.order > targetTier.order) || null;
  const ordersProgress = nextTier
    ? nextTier.minOrders > 0
      ? Math.min(100, Math.round((lifetimeOrders / nextTier.minOrders) * 100))
      : 100
    : 100;
  const salesProgress = nextTier
    ? nextTier.minSales > 0
      ? Math.min(100, Math.round((lifetimeSales / nextTier.minSales) * 100))
      : 100
    : 100;

  return {
    affiliate: updatedAff,
    currentTier: targetTier,
    nextTier,
    levels,
    stats: {
      lifetimeOrders,
      lifetimeSales,
      recentOrders,
      recentSales,
      windowDays,
      ordersProgress,
      salesProgress,
      ordersRemaining: nextTier ? Math.max(0, nextTier.minOrders - lifetimeOrders) : 0,
      salesRemaining: nextTier ? Math.max(0, roundMoney(nextTier.minSales - lifetimeSales)) : 0,
    },
  };
}

/**
 * @param {string} affiliateId
 * @param {string} levelId
 * @param {any} actor
 * @param {{ lockManual?: boolean, reason?: string }} [options]
 * @param {number | null} [nowOverrideMs]
 */
export function adminSetAffiliateLevel(affiliateId, levelId, actor, { lockManual = true, reason = 'Admin level update' } = {}, nowOverrideMs = null) {
  assertPermission(actor.role, 'approve');
  const aff = appServices.affiliates.affiliates.getById(affiliateId);
  if (!aff) throw new Error('Affiliate profile not found.');

  const cfg = getPlatformConfig();
  const levels = getAffiliateLevels(cfg);
  const targetTier = levels.find((l) => l.id === String(levelId).toLowerCase());
  if (!targetTier) throw new Error('Invalid affiliate level selected.');

  const nowMs = getTrustedServerTimestamp(nowOverrideMs);
  const nowIso = new Date(nowMs).toISOString();
  const updated = {
    ...aff,
    level: targetTier.id,
    levelAssignedAtMs: nowMs,
    manualLevelLocked: Boolean(lockManual),
    levelHistory: [
      { level: targetTier.id, from: aff.level || 'bronze', at: nowIso, reason, actorId: actor.uid },
      ...(aff.levelHistory || []),
    ].slice(0, 30),
    updatedAt: nowIso,
  };
  appServices.affiliates.affiliates.upsert(affiliateId, updated);

  pushNotification({
    audience: 'affiliate',
    userId: aff.userId,
    category: 'Affiliate Level',
    title: `Affiliate Level Set to ${targetTier.name}`,
    message: `Admin assigned your partner tier to ${targetTier.name} (${targetTier.commissionRate}% rate).`,
  });

  recordAuditLog({
    actorId: actor.uid,
    actorRole: actor.role,
    action: 'AFFILIATE_SET_LEVEL',
    targetCollection: 'affiliates',
    targetId: affiliateId,
    details: `level=${targetTier.id}, lock=${Boolean(lockManual)}, reason=${reason}`,
  });

  return updated;
}

export function updateAffiliateProfile(affiliateId, { name, phone, bio, socialLink, promotionMedium, marketingPlan }, actorUserId) {
  const aff = appServices.affiliates.affiliates.getById(affiliateId);
  if (!aff) throw new Error('Affiliate not found.');
  if (aff.userId !== actorUserId) throw new Error('Access denied: affiliate data isolation enforced.');
  const cleanSocial = socialLink !== undefined ? sanitizeUrl(socialLink, false) : aff.socialLink;
  if (socialLink !== undefined && String(socialLink).trim() && !cleanSocial) {
    throw new Error('Social Media / Website URL must begin with http:// or https://.');
  }
  const updated = {
    ...aff,
    name: name ? String(name).trim() : aff.name,
    phone: phone ? String(phone).trim() : aff.phone,
    bio: bio !== undefined ? String(bio).trim() : aff.bio,
    socialLink: cleanSocial || aff.socialLink || '',
    promotionMedium: promotionMedium ? String(promotionMedium).trim() : aff.promotionMedium || '',
    marketingPlan: marketingPlan !== undefined ? String(marketingPlan).trim() : aff.marketingPlan || '',
    updatedAt: new Date().toISOString(),
  };
  appServices.affiliates.affiliates.upsert(affiliateId, updated);
  return updated;
}

/**
 * @param {{ affiliateId: string, type?: string, targetId?: string, targetName?: string, label?: string }} payload
 * @param {number | null} [nowOverrideMs]
 */
export function createAffiliateLink(
  { affiliateId, type = 'store', targetId = '', targetName = '', label = '' },
  nowOverrideMs = null
) {
  assertFeatureEnabled('affiliateProgram', ROLES.AFFILIATE);
  const aff = appServices.affiliates.affiliates.getById(affiliateId);
  if (!aff) throw new Error('Affiliate profile not found.');
  if (aff.status === 'banned') {
    throw new Error('Your affiliate account is permanently banned from creating links.');
  }
  if (aff.status === 'suspended') {
    throw new Error('Your affiliate account is currently suspended.');
  }
  if (aff.status !== 'approved') {
    throw new Error('Admin approval is required before creating affiliate links.');
  }

  const cfg = getPlatformConfig();
  const expiryHours = Number(cfg.affiliateConfig?.linkExpiryHours || 168);
  const serverCreatedMs = getTrustedServerTimestamp(nowOverrideMs);
  const expiresAtMs = serverCreatedMs + expiryHours * 3600 * 1000;
  const code = `${aff.affiliateCode}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;

  const queryParts = [`ref=${encodeURIComponent(code)}`];
  if (type === 'product' && targetId) queryParts.push(`product=${encodeURIComponent(targetId)}`);
  if (type === 'category' && targetId) queryParts.push(`cat=${encodeURIComponent(targetId)}`);

  const record = {
    id: generateId('AFL'),
    code,
    affiliateId: aff.id,
    affiliateUserId: aff.userId,
    type, // 'store' | 'product' | 'category'
    targetId: String(targetId || ''),
    targetName: String(targetName || (type === 'store' ? 'LUXE NEXUS Store' : targetId)),
    label: String(label || targetName || `${type} link`).trim(),
    urlQuery: `?${queryParts.join('&')}`,
    serverCreatedMs,
    expiresAtMs,
    createdAt: new Date(serverCreatedMs).toISOString(),
    expiresAt: new Date(expiresAtMs).toISOString(),
    status: 'active', // 'active' | 'sold' | 'expired' | 'disabled'
    clicks: 0,
    uniqueClicks: 0,
    orders: 0,
    sales: 0,
    commission: 0,
  };

  appServices.affiliates.links.upsert(record.id, record);
  return record;
}

/**
 * @param {any} link
 * @param {number | null} [nowOverrideMs]
 */
export function evaluateLinkStatus(link, nowOverrideMs = null) {
  if (!link) return 'expired';
  if (link.status === 'disabled') return 'disabled';
  if (link.status === 'sold') return 'sold';
  const nowMs = getTrustedServerTimestamp(nowOverrideMs);
  if (nowMs >= Number(link.expiresAtMs || 0)) {
    return 'expired';
  }
  return 'active';
}

export function syncExpiredLinks(nowOverrideMs = null) {
  const links = appServices.affiliates.links.list();
  let changed = false;
  const next = links.map((l) => {
    const computed = evaluateLinkStatus(l, nowOverrideMs);
    if (computed === 'expired' && l.status === 'active') {
      changed = true;
      pushNotification({
        audience: 'affiliate',
        userId: l.affiliateUserId,
        category: 'Affiliates',
        title: 'Affiliate Link Expired',
        message: `Your 7-day link "${l.label}" (${l.code}) has expired without a sale.`,
      });
      return { ...l, status: 'expired' };
    }
    return l;
  });
  if (changed) appServices.affiliates.links.saveAll(next);
  return next;
}

export function setAffiliateLinkState(linkId, state, actorUserId, isAdmin = false) {
  const link = appServices.affiliates.links.getById(linkId);
  if (!link) throw new Error('Affiliate link not found.');
  if (!isAdmin && link.affiliateUserId !== actorUserId) {
    throw new Error('Access denied: affiliate data isolation enforced.');
  }
  if (state === 'delete') {
    return appServices.affiliates.links.remove(linkId);
  }
  const updated = { ...link, status: state };
  appServices.affiliates.links.upsert(linkId, updated);
  return updated;
}

export function listAffiliateLinks(affiliateId = null) {
  const links = syncExpiredLinks();
  return affiliateId ? links.filter((l) => l.affiliateId === affiliateId) : links;
}

/**
 * @param {{ code: string, visitorId?: string, source?: string, buyerUserId?: string | null }} payload
 * @param {number | null} [nowOverrideMs]
 */
export function trackReferralClick(
  { code, visitorId = 'visitor-default', source = 'direct', buyerUserId = null },
  nowOverrideMs = null
) {
  const cfg = getPlatformConfig();
  if (cfg.affiliateConfig?.enabled === false || cfg.platformFlags?.affiliateProgramEnabled === false) {
    return { attributed: false, reason: 'Affiliate program disabled.' };
  }

  const links = syncExpiredLinks(nowOverrideMs);
  const link = links.find((l) => l.code === code);
  if (!link) return { attributed: false, reason: 'Invalid referral code.' };

  const aff = appServices.affiliates.affiliates.getById(link.affiliateId);
  if (!aff || aff.status !== 'approved') {
    return { attributed: false, reason: 'Affiliate is not active.' };
  }

  const status = evaluateLinkStatus(link, nowOverrideMs);
  if (status === 'expired' || status === 'disabled') {
    return { attributed: false, reason: `Referral link is ${status}.` };
  }

  // Rule #1: Prevent self-referral attribution at click stage if user is signed in
  if (buyerUserId && buyerUserId === aff.userId) {
    return { attributed: false, reason: 'Self-referral is not permitted.' };
  }

  const clicks = appServices.affiliates.clicks.list();
  const alreadyVisited = clicks.some((c) => c.linkId === link.id && c.visitorId === visitorId);

  const clickRecord = {
    id: generateId('CLK'),
    linkId: link.id,
    code: link.code,
    affiliateId: aff.id,
    visitorId,
    unique: !alreadyVisited,
    source,
    createdAtMs: getTrustedServerTimestamp(nowOverrideMs),
    createdAt: new Date(getTrustedServerTimestamp(nowOverrideMs)).toISOString(),
  };
  clicks.unshift(clickRecord);
  appServices.affiliates.clicks.saveAll(clicks.slice(0, 1000));

  const updatedLink = {
    ...link,
    clicks: Number(link.clicks || 0) + 1,
    uniqueClicks: Number(link.uniqueClicks || 0) + (alreadyVisited ? 0 : 1),
  };
  appServices.affiliates.links.upsert(link.id, updatedLink);

  // Store active customer attribution (last valid non-expired referral)
  const attribution = {
    linkId: link.id,
    code: link.code,
    affiliateId: aff.id,
    affiliateUserId: aff.userId,
    type: link.type,
    targetId: link.targetId,
    expiresAtMs: link.expiresAtMs,
    source,
    attributedAtMs: clickRecord.createdAtMs,
  };
  appServices.storage.setCollection(ACTIVE_ATTRIBUTION_KEY, attribution);

  pushNotification({
    audience: 'affiliate',
    userId: aff.userId,
    category: 'Affiliates',
    title: 'New Referral Visit',
    message: `New click recorded on "${link.label}" (${link.code}).`,
  });

  return { attributed: true, attribution, link: updatedLink };
}

export function getActiveReferralAttribution(nowOverrideMs = null) {
  const attr = appServices.storage.getCollection(ACTIVE_ATTRIBUTION_KEY, null);
  if (!attr || !attr.linkId) return null;
  const link = appServices.affiliates.links.getById(attr.linkId);
  if (!link) return null;
  const status = evaluateLinkStatus(link, nowOverrideMs);
  if (status === 'expired' || status === 'disabled') {
    appServices.storage.setCollection(ACTIVE_ATTRIBUTION_KEY, null);
    return null;
  }
  return attr;
}

export function calculateCommissionAmount(orderItems, config = getPlatformConfig(), affiliate = null) {
  const affCfg = config.affiliateConfig || {};
  const tier = affiliate ? getAffiliateLevelConfig(affiliate.level || 'bronze', config) : null;
  const baseRate = tier ? Number(tier.commissionRate) : Number(affCfg.defaultRate ?? 8);
  const defaultType = affCfg.rateType || 'percentage';
  const catRates = affCfg.categoryRates || {};
  const prodRates = affCfg.productRates || {};

  let totalCommission = 0;
  for (const item of orderItems) {
    const lineTotal = roundMoney(Number(item.unitPrice || 0) * Number(item.qty || 1));
    const prodRule = prodRates[item.productId];
    const catRule = catRates[item.category];
    let rule = { type: defaultType, value: baseRate };

    if (prodRule) {
      rule =
        prodRule.type === 'percentage' && defaultType === 'percentage'
          ? { type: 'percentage', value: Math.max(Number(prodRule.value || 0), baseRate) }
          : prodRule;
    } else if (catRule) {
      rule =
        catRule.type === 'percentage' && defaultType === 'percentage'
          ? { type: 'percentage', value: Math.max(Number(catRule.value || 0), baseRate) }
          : catRule;
    }

    if (rule.type === 'fixed') {
      totalCommission = roundMoney(totalCommission + roundMoney(Number(rule.value || 0) * Number(item.qty || 1)));
    } else {
      totalCommission = roundMoney(totalCommission + roundMoney((lineTotal * Number(rule.value || 0)) / 100));
    }
  }
  return totalCommission;
}

export function recordAffiliateConversion(order, buyerUser = null, explicitCode = null, nowOverrideMs = null) {
  const cfg = getPlatformConfig();
  if (cfg.affiliateConfig?.enabled === false || cfg.platformFlags?.affiliateProgramEnabled === false) {
    return null;
  }

  const nowMs = getTrustedServerTimestamp(nowOverrideMs);
  let link = null;
  if (explicitCode) {
    link = appServices.affiliates.links.list().find((l) => l.code === explicitCode) || null;
  } else {
    const attr = getActiveReferralAttribution(nowMs);
    if (attr) link = appServices.affiliates.links.getById(attr.linkId);
  }
  if (!link) return null;

  const aff = appServices.affiliates.affiliates.getById(link.affiliateId);
  if (!aff || aff.status !== 'approved') return null;

  const status = evaluateLinkStatus(link, nowMs);
  if (status === 'expired' || status === 'disabled') {
    return null;
  }

  // Rule #1: Self-referral prevention (User ID, email, or phone match)
  const buyerEmail = String(buyerUser?.email || order.customer?.email || '').toLowerCase();
  const buyerPhone = String(buyerUser?.phone || order.customer?.phone || '').replace(/\s+/g, '');
  const affPhone = String(aff.phone || '').replace(/\s+/g, '');
  if (
    (buyerUser?.uid && buyerUser.uid === aff.userId) ||
    (buyerEmail && buyerEmail === aff.email.toLowerCase()) ||
    (buyerPhone && affPhone && buyerPhone === affPhone)
  ) {
    appServices.affiliates.auditLogs.upsert(generateId('AFA'), {
      id: generateId('AFA'),
      type: 'SELF_REFERRAL_BLOCKED',
      affiliateId: aff.id,
      orderId: order.id,
      createdAt: new Date(nowMs).toISOString(),
    });
    return null;
  }

  // Duplicate conversion prevention for the same order
  const existingComms = appServices.affiliates.commissions.list();
  if (existingComms.some((c) => c.orderId === order.id)) {
    return null;
  }

  // Product / category scope validation
  let eligibleItems = order.items || [];
  if (link.type === 'product' && link.targetId) {
    eligibleItems = eligibleItems.filter((i) => i.productId === link.targetId);
  } else if (link.type === 'category' && link.targetId) {
    eligibleItems = eligibleItems.filter(
      (i) => String(i.category || '').toLowerCase() === String(link.targetId).toLowerCase()
    );
  }
  if (!eligibleItems.length) return null;

  const eligibleSales = roundMoney(
    eligibleItems.reduce((sum, i) => sum + roundMoney(Number(i.unitPrice) * Number(i.qty)), 0)
  );
  const levelCfg = getAffiliateLevelConfig(aff.level || 'bronze', cfg);
  const commissionAmount = calculateCommissionAmount(eligibleItems, cfg, aff);
  if (commissionAmount <= 0) return null;

  const initialStatus = aff.commissionHold ? 'held' : 'pending';
  const commissionRecord = {
    id: generateId('COM'),
    orderId: order.id,
    affiliateId: aff.id,
    affiliateUserId: aff.userId,
    affiliateName: aff.name,
    affiliateLevel: levelCfg.id,
    commissionRateApplied: levelCfg.commissionRate,
    linkId: link.id,
    linkCode: link.code,
    buyerUserId: buyerUser?.uid || 'guest',
    orderTotal: eligibleSales,
    commissionAmount,
    status: initialStatus, // pending | held | approved | paid | rejected | reversed
    reason: aff.commissionHold ? aff.holdReason || 'Account commission hold active' : '',
    createdAtMs: nowMs,
    createdAt: new Date(nowMs).toISOString(),
    updatedAt: new Date(nowMs).toISOString(),
  };

  appServices.affiliates.commissions.upsert(commissionRecord.id, commissionRecord);

  // Record referral conversion & mark link as sold (preserving relationship!)
  appServices.affiliates.referrals.upsert(generateId('REF'), {
    id: generateId('REF'),
    orderId: order.id,
    affiliateId: aff.id,
    linkId: link.id,
    salesAmount: eligibleSales,
    commissionAmount,
    createdAt: new Date(nowMs).toISOString(),
  });

  appServices.affiliates.links.upsert(link.id, {
    ...link,
    status: 'sold',
    orders: Number(link.orders || 0) + 1,
    sales: roundMoney(Number(link.sales || 0) + eligibleSales),
    commission: roundMoney(Number(link.commission || 0) + commissionAmount),
  });

  pushNotification({
    audience: 'affiliate',
    userId: aff.userId,
    category: 'Commission',
    title: initialStatus === 'held' ? 'Commission Held for Review' : 'New Referral Order & Pending Commission',
    message:
      initialStatus === 'held'
        ? `Order #${order.id} generated ${commissionAmount}, currently on Admin Hold.`
        : `Order #${order.id} generated ${commissionAmount} pending commission (${levelCfg.name} Tier).`,
  });

  return commissionRecord;
}

export function syncCommissionOnOrderStatusChange(
  orderId,
  orderStatus,
  actor = { uid: 'system', role: 'admin' },
  nowOverrideMs = null
) {
  const comms = appServices.affiliates.commissions.list();
  const target = comms.find((c) => c.orderId === orderId);
  if (!target) return null;

  const aff = appServices.affiliates.affiliates.getById(target.affiliateId);
  let nextStatus = target.status;

  if (orderStatus === 'Delivered' && (target.status === 'pending' || target.status === 'held')) {
    nextStatus = aff?.commissionHold ? 'held' : 'approved';
  } else if (['Cancelled', 'Refunded'].includes(orderStatus) && target.status !== 'paid') {
    // Rule #5: Cancelled or refunded orders receive no commission
    nextStatus = 'reversed';
  } else {
    return target;
  }

  const nowMs = getTrustedServerTimestamp(nowOverrideMs);
  const updated = {
    ...target,
    status: nextStatus,
    verifiedBy: actor.uid,
    reason: nextStatus === 'held' ? aff?.holdReason || 'Account commission hold active' : target.reason || '',
    updatedAt: new Date(nowMs).toISOString(),
  };
  appServices.affiliates.commissions.upsert(target.id, updated);

  // Re-evaluate affiliate tier progression whenever commission becomes approved or reversed
  evaluateAffiliateLevel(target.affiliateId, nowMs);

  pushNotification({
    audience: 'affiliate',
    userId: target.affiliateUserId,
    category: 'Commission',
    title:
      nextStatus === 'approved'
        ? 'Commission Approved'
        : nextStatus === 'held'
          ? 'Commission Placed On Hold'
          : 'Commission Reversed',
    message:
      nextStatus === 'approved'
        ? `Order #${orderId} was delivered. Commission of ${target.commissionAmount} is now available for withdrawal.`
        : nextStatus === 'held'
          ? `Order #${orderId} delivered, but commission of ${target.commissionAmount} is on temporary Admin Hold.`
          : `Commission for Order #${orderId} was reversed due to order status: ${orderStatus}.`,
  });

  return updated;
}

/**
 * @param {string} commissionId
 * @param {string} nextStatus
 * @param {any} actor
 * @param {string} [reason]
 * @param {number | null} [nowOverrideMs]
 */
export function adminOverrideCommissionStatus(commissionId, nextStatus, actor, reason = '', nowOverrideMs = null) {
  assertPermission(actor.role, nextStatus === 'approved' || nextStatus === 'paid' ? 'approve' : 'reject');
  const comm = appServices.affiliates.commissions.getById(commissionId);
  if (!comm) throw new Error('Commission record not found.');
  if (!['pending', 'held', 'approved', 'paid', 'rejected', 'reversed'].includes(nextStatus)) {
    throw new Error('Invalid commission status.');
  }
  const nowMs = getTrustedServerTimestamp(nowOverrideMs);
  const updated = {
    ...comm,
    status: nextStatus,
    reason,
    updatedBy: actor.uid,
    updatedAt: new Date(nowMs).toISOString(),
  };
  appServices.affiliates.commissions.upsert(commissionId, updated);
  evaluateAffiliateLevel(comm.affiliateId, nowMs);
  recordAuditLog({
    actorId: actor.uid,
    actorRole: actor.role,
    action: `COMMISSION_${nextStatus.toUpperCase()}`,
    targetCollection: 'affiliateCommissions',
    targetId: commissionId,
    details: reason || comm.orderId,
  });
  return updated;
}

/**
 * @param {string} affiliateId
 * @param {number | null} [nowOverrideMs]
 */
export function getAffiliateDashboardMetrics(affiliateId, nowOverrideMs = null) {
  const links = listAffiliateLinks(affiliateId);
  const clicks = appServices.affiliates.clicks.list().filter((c) => c.affiliateId === affiliateId);
  const referrals = appServices.affiliates.referrals.list().filter((r) => r.affiliateId === affiliateId);
  const comms = appServices.affiliates.commissions.list().filter((c) => c.affiliateId === affiliateId);
  const withdrawals = appServices.affiliates.withdrawals.list().filter((w) => w.affiliateId === affiliateId);

  const totalClicks = clicks.length;
  const uniqueClicks = clicks.filter((c) => c.unique).length;
  const totalReferrals = referrals.length;
  const totalOrders = comms.length;
  const successfulConversions = comms.filter((c) => c.status === 'approved' || c.status === 'paid').length;
  const conversionRate = totalClicks > 0 ? roundMoney((totalOrders * 100) / totalClicks) : 0;

  const totalSales = roundMoney(
    comms.filter((c) => c.status !== 'rejected' && c.status !== 'reversed').reduce((s, c) => s + Number(c.orderTotal || 0), 0)
  );
  const pendingCommission = roundMoney(comms.filter((c) => c.status === 'pending').reduce((s, c) => s + Number(c.commissionAmount || 0), 0));
  const heldCommission = roundMoney(comms.filter((c) => c.status === 'held').reduce((s, c) => s + Number(c.commissionAmount || 0), 0));
  const approvedCommission = roundMoney(comms.filter((c) => c.status === 'approved').reduce((s, c) => s + Number(c.commissionAmount || 0), 0));
  const paidCommission = roundMoney(comms.filter((c) => c.status === 'paid').reduce((s, c) => s + Number(c.commissionAmount || 0), 0));
  const rejectedCommission = roundMoney(
    comms.filter((c) => c.status === 'rejected' || c.status === 'reversed').reduce((s, c) => s + Number(c.commissionAmount || 0), 0)
  );
  const totalCommission = roundMoney(pendingCommission + heldCommission + approvedCommission + paidCommission);

  const withdrawnAmount = roundMoney(
    withdrawals.filter((w) => w.status === 'paid').reduce((s, w) => s + Number(w.amount || 0), 0)
  );
  const pendingWithdrawal = roundMoney(
    withdrawals
      .filter((w) => ['pending', 'held', 'approved', 'processing'].includes(w.status))
      .reduce((s, w) => s + Number(w.amount || 0), 0)
  );

  // Available balance = Approved + Paid commissions minus already paid withdrawals minus reserved pending/held/approved withdrawals
  const lifetimeEarnedApproved = roundMoney(approvedCommission + paidCommission);
  const availableBalance = Math.max(0, roundMoney(lifetimeEarnedApproved - withdrawnAmount - pendingWithdrawal));

  const nowMs = getTrustedServerTimestamp(nowOverrideMs);
  const dayMs = 24 * 3600 * 1000;
  const validEarnings = comms.filter((c) => ['approved', 'paid'].includes(c.status));
  const todayEarnings = roundMoney(
    validEarnings.filter((c) => nowMs - new Date(c.createdAt).getTime() <= dayMs).reduce((s, c) => s + Number(c.commissionAmount || 0), 0)
  );
  const weeklyEarnings = roundMoney(
    validEarnings.filter((c) => nowMs - new Date(c.createdAt).getTime() <= 7 * dayMs).reduce((s, c) => s + Number(c.commissionAmount || 0), 0)
  );
  const monthlyEarnings = roundMoney(
    validEarnings.filter((c) => nowMs - new Date(c.createdAt).getTime() <= 30 * dayMs).reduce((s, c) => s + Number(c.commissionAmount || 0), 0)
  );

  return {
    totalLinks: links.length,
    totalClicks,
    uniqueClicks,
    totalReferrals,
    totalOrders,
    successfulConversions,
    conversionRate,
    totalSales,
    totalCommission,
    pendingCommission,
    heldCommission,
    approvedCommission,
    paidCommission,
    rejectedCommission,
    availableBalance,
    withdrawnAmount,
    pendingWithdrawal,
    todayEarnings,
    weeklyEarnings,
    monthlyEarnings,
    lifetimeEarnings: lifetimeEarnedApproved,
  };
}

export function requestAffiliateWithdrawal(affiliateId, payload, actorUserId) {
  const aff = appServices.affiliates.affiliates.getById(affiliateId);
  if (!aff) throw new Error('Affiliate account not found.');
  if (aff.userId !== actorUserId) throw new Error('Access denied.');
  if (aff.status === 'banned') throw new Error('Banned affiliate accounts cannot request withdrawals.');
  if (aff.status === 'suspended') throw new Error('Suspended affiliate accounts cannot request withdrawals.');
  if (aff.status !== 'approved') throw new Error('Only approved affiliates can request withdrawals.');
  if (aff.withdrawalHold || aff.commissionHold) {
    throw new Error(`Withdrawals are temporarily on Admin Hold${aff.holdReason ? `: ${aff.holdReason}` : '.'}`);
  }

  const cfg = getPlatformConfig();
  const minW = Number(cfg.affiliateConfig?.minWithdrawal || 500);
  const metrics = getAffiliateDashboardMetrics(affiliateId);
  const validation = validateWithdrawalRequest(payload, metrics.availableBalance, minW);
  if (!validation.valid) {
    throw new Error(validation.errors[0]);
  }

  const withdrawal = {
    id: generateId('WDR'),
    affiliateId: aff.id,
    affiliateUserId: aff.userId,
    affiliateName: aff.name,
    amount: validation.amount,
    method: payload.method,
    accountHolder: String(payload.accountHolder).trim(),
    accountNumber: String(payload.accountNumber).trim(),
    status: 'pending', // pending | held | approved | processing | paid | rejected
    transactionId: '',
    paymentReference: '',
    rejectionReason: '',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  appServices.affiliates.withdrawals.upsert(withdrawal.id, withdrawal);

  pushNotification({
    audience: 'affiliate',
    userId: aff.userId,
    category: 'Withdrawals',
    title: 'Withdrawal Requested',
    message: `Your ${withdrawal.method} withdrawal request of ${withdrawal.amount} is pending Admin review.`,
  });
  pushNotification({
    audience: 'admin',
    category: 'Withdrawals',
    title: 'New Affiliate Withdrawal Request',
    message: `${aff.name} requested ${withdrawal.amount} via ${withdrawal.method}.`,
  });

  return withdrawal;
}

export function adminProcessWithdrawal(
  withdrawalId,
  { status, transactionId = '', paymentReference = '', rejectionReason = '' },
  actor
) {
  assertPermission(actor.role, 'manage_payments');
  const w = appServices.affiliates.withdrawals.getById(withdrawalId);
  if (!w) throw new Error('Withdrawal request not found.');
  if (w.status === 'paid') throw new Error('This withdrawal has already been paid.');
  if (status === 'paid' && !String(transactionId).trim()) {
    throw new Error('Transaction ID is required to mark withdrawal as Paid.');
  }

  const updated = {
    ...w,
    status,
    transactionId: String(transactionId || w.transactionId || '').trim(),
    paymentReference: String(paymentReference || w.paymentReference || '').trim(),
    rejectionReason: status === 'rejected' || status === 'held' ? String(rejectionReason || 'Admin review') : '',
    processedBy: actor.uid,
    updatedAt: new Date().toISOString(),
  };
  appServices.affiliates.withdrawals.upsert(withdrawalId, updated);

  if (status === 'paid') {
    // Reconcile approved commissions up to paid amount
    let remainingToSettle = roundMoney(w.amount);
    const comms = appServices.affiliates.commissions
      .list()
      .filter((c) => c.affiliateId === w.affiliateId && c.status === 'approved');
    for (const c of comms) {
      if (remainingToSettle <= 0) break;
      if (Number(c.commissionAmount) <= remainingToSettle) {
        appServices.affiliates.commissions.upsert(c.id, {
          ...c,
          status: 'paid',
          withdrawalId: w.id,
          updatedAt: new Date().toISOString(),
        });
        remainingToSettle = roundMoney(remainingToSettle - Number(c.commissionAmount));
      }
    }
  }

  pushNotification({
    audience: 'affiliate',
    userId: w.affiliateUserId,
    category: 'Withdrawals',
    title: `Withdrawal ${status.toUpperCase()}`,
    message:
      status === 'paid'
        ? `Payout of ${w.amount} completed via ${w.method}. TxID: ${updated.transactionId}`
        : status === 'held'
          ? `Withdrawal #${w.id} is temporarily on Hold: ${updated.rejectionReason}`
          : `Withdrawal #${w.id} is now ${status}.`,
  });

  recordAuditLog({
    actorId: actor.uid,
    actorRole: actor.role,
    action: `WITHDRAWAL_${status.toUpperCase()}`,
    targetCollection: 'affiliateWithdrawals',
    targetId: withdrawalId,
    details: `amount=${w.amount}, tx=${updated.transactionId}`,
  });

  return updated;
}

/**
 * @param {string} [period]
 * @param {number | null} [nowOverrideMs]
 */
export function getAffiliateLeaderboard(period = 'monthly', nowOverrideMs = null) {
  const cfg = getPlatformConfig();
  const affiliates = appServices.affiliates.affiliates.list().filter((a) => a.status === 'approved');
  const comms = appServices.affiliates.commissions.list();
  const clicks = appServices.affiliates.clicks.list();
  const nowMs = getTrustedServerTimestamp(nowOverrideMs);
  const windowMs = period === 'weekly' ? 7 * 86400000 : period === 'monthly' ? 30 * 86400000 : Infinity;

  const ranked = affiliates.map((aff) => {
    const tier = getAffiliateLevelConfig(aff.level || 'bronze', cfg);
    const affComms = comms.filter(
      (c) =>
        c.affiliateId === aff.id &&
        c.status !== 'rejected' &&
        c.status !== 'reversed' &&
        nowMs - new Date(c.createdAt).getTime() <= windowMs
    );
    const affClicks = clicks.filter(
      (c) => c.affiliateId === aff.id && nowMs - Number(c.createdAtMs || 0) <= windowMs
    );
    const totalSales = roundMoney(affComms.reduce((s, c) => s + Number(c.orderTotal || 0), 0));
    const totalCommission = roundMoney(affComms.reduce((s, c) => s + Number(c.commissionAmount || 0), 0));
    const convRate = affClicks.length > 0 ? roundMoney((affComms.length * 100) / affClicks.length) : 0;

    return {
      affiliateId: aff.id,
      affiliateCode: aff.affiliateCode,
      name: aff.name,
      level: tier.id,
      levelName: tier.name,
      levelBadgeColor: tier.badgeColor,
      commissionRate: tier.commissionRate,
      orders: affComms.length,
      clicks: affClicks.length,
      conversionRate: convRate,
      totalSales,
      totalCommission,
    };
  });

  ranked.sort((a, b) => b.totalSales - a.totalSales || b.totalCommission - a.totalCommission);
  return ranked;
}
