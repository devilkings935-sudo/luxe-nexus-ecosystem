/**
 * LUXE NEXUS Payment & Gateway Abstraction Service (PART 10 & 12)
 */

import { roundMoney } from '../shared/utilities.js';
import { getPlatformConfig } from './settings-service.js';

export const PAYMENT_METHOD_CATALOG = [
  { id: 'COD', name: 'Cash on Delivery', region: 'All', feePercent: 0, gatewayRequired: false },
  { id: 'bKash', name: 'bKash Mobile Wallet', region: 'Bangladesh', feePercent: 1.5, gatewayRequired: true },
  { id: 'Nagad', name: 'Nagad Mobile Wallet', region: 'Bangladesh', feePercent: 1.2, gatewayRequired: true },
  { id: 'Card', name: 'International Card (Stripe/SSLCommerz)', region: 'International', feePercent: 2.5, gatewayRequired: true },
];

export function getAvailablePaymentMethods() {
  const cfg = getPlatformConfig();
  const c = cfg.checkout || {};
  return [
    { ...PAYMENT_METHOD_CATALOG[0], enabled: c.cod !== false },
    { ...PAYMENT_METHOD_CATALOG[1], enabled: !!c.bkash },
    { ...PAYMENT_METHOD_CATALOG[2], enabled: !!c.nagad },
    { ...PAYMENT_METHOD_CATALOG[3], enabled: !!c.card },
  ];
}

export function calculatePaymentFee(grandTotal, paymentMethod = 'COD') {
  const meta = PAYMENT_METHOD_CATALOG.find((m) => m.id === paymentMethod) || PAYMENT_METHOD_CATALOG[0];
  if (!meta.feePercent) return 0;
  return roundMoney((roundMoney(grandTotal) * meta.feePercent) / 100);
}

export function authorizePaymentIntent({ orderId, amount, method }) {
  const methods = getAvailablePaymentMethods();
  const target = methods.find((m) => m.id === method);
  if (!target || !target.enabled) {
    throw new Error(`Payment method "${method}" is currently disabled.`);
  }
  return {
    intentId: `PAY-${Date.now().toString(36).toUpperCase()}`,
    orderId,
    method,
    amount: roundMoney(amount),
    fee: calculatePaymentFee(amount, method),
    status: method === 'COD' ? 'cod_pending_collection' : 'authorized_prototype',
    createdAt: new Date().toISOString(),
  };
}
