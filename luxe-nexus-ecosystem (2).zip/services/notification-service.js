/**
 * LUXE NEXUS Notification Service (PART 13 & 8.9)
 * Handles User, Admin, Seller, and Affiliate notifications across all 11 categories.
 */

import { appServices } from '../adapters/backend-adapter.js';
import { generateId } from '../shared/utilities.js';

export const NOTIFICATION_CATEGORIES = [
  'Orders',
  'Payments',
  'Products',
  'Sellers',
  'Affiliates',
  'Commission',
  'Withdrawals',
  'Accounts',
  'Promotions',
  'App Updates',
  'Security',
];

export function pushNotification({
  audience = 'user', // 'user' | 'admin' | 'seller' | 'affiliate'
  userId = '',
  category = 'Orders',
  title,
  message,
  link = '',
}) {
  const item = {
    id: generateId('NTF'),
    audience,
    userId,
    category: NOTIFICATION_CATEGORIES.includes(category) ? category : 'Orders',
    title: String(title || 'Notification'),
    message: String(message || ''),
    link,
    read: false,
    createdAt: new Date().toISOString(),
  };
  const list = appServices.notifications.list();
  list.unshift(item);
  appServices.notifications.saveAll(list.slice(0, 300));
  return item;
}

export function getNotificationsForScope(audience = 'user', userId = '') {
  const list = appServices.notifications.list();
  return list.filter((n) => {
    if (n.audience !== audience) return false;
    if (userId && n.userId && n.userId !== userId) return false;
    return true;
  });
}

export function getUnreadCount(audience = 'user', userId = '') {
  return getNotificationsForScope(audience, userId).filter((n) => !n.read).length;
}

export function markNotificationRead(id) {
  const list = appServices.notifications.list();
  const next = list.map((n) => (n.id === id ? { ...n, read: true } : n));
  appServices.notifications.saveAll(next);
}

export function markAllNotificationsRead(audience = 'user', userId = '') {
  const list = appServices.notifications.list();
  const next = list.map((n) => {
    const matchAudience = n.audience === audience;
    const matchUser = !userId || !n.userId || n.userId === userId;
    return matchAudience && matchUser ? { ...n, read: true } : n;
  });
  appServices.notifications.saveAll(next);
}

export function deleteNotification(id) {
  return appServices.notifications.remove(id);
}

export function getNotificationPreferences(userId) {
  const all = appServices.storage.getCollection('notificationPreferences', {});
  return (
    all[userId || 'guest'] || {
      Orders: true,
      Payments: true,
      Products: true,
      Affiliates: true,
      Commission: true,
      Withdrawals: true,
      Promotions: true,
      'App Updates': true,
      Security: true,
    }
  );
}

export function saveNotificationPreferences(userId, prefs) {
  const all = appServices.storage.getCollection('notificationPreferences', {});
  all[userId || 'guest'] = { ...(all[userId || 'guest'] || {}), ...prefs };
  appServices.storage.setCollection('notificationPreferences', all);
  return all[userId || 'guest'];
}
