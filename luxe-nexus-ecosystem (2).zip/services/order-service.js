/**
 * LUXE NEXUS Cart, Unified Order Validation, Tracking & Financial Ledger Service
 */

import { appServices, assertPermission, assertFeatureEnabled, recordAuditLog } from '../adapters/backend-adapter.js';
import { validateCheckoutInput } from '../shared/validators.js';
import { generateId, roundMoney } from '../shared/utilities.js';
import { isAdminRole, ROLES } from '../shared/permissions.js';
import { getPlatformConfig } from './settings-service.js';
import { updateProductStock } from './product-service.js';
import { authorizePaymentIntent, calculatePaymentFee } from './payment-service.js';
import { recordAffiliateConversion, syncCommissionOnOrderStatusChange } from './affiliate-service.js';
import { pushNotification } from './notification-service.js';
import { buildProductColorOptions, resolveVariantStock } from './variant-service.js';

export const ORDER_STATUSES = [
  'Placed',
  'Confirmed',
  'Processing',
  'Packed',
  'Shipped',
  'Out for Delivery',
  'Delivered',
  'Cancelled',
  'Return Requested',
  'Refunded',
];

const CART_KEY = 'shopping_cart';
const IDEMPOTENCY_CACHE_KEY = 'order_idempotency_keys';

export function getCart() {
  return appServices.storage.getCollection(CART_KEY, []);
}

export function getCartCount() {
  return getCart().reduce((sum, item) => sum + Number(item.qty || 0), 0);
}

export function addToCart(product, { qty = 1, size = '', color = '', image = '' } = {}) {
  assertFeatureEnabled('cart', 'customer');
  if (!product || !product.id) throw new Error('Invalid product.');
  const stock = size || color ? resolveVariantStock(product, { size, color }) : Number(product.stock ?? 0);
  if (stock <= 0) throw new Error('This product is currently out of stock.');

  const cart = getCart();
  const variantKey = `${product.id}::${size}::${color}`;
  const idx = cart.findIndex((c) => c.variantKey === variantKey);
  const addQty = Math.max(1, Math.floor(Number(qty || 1)));
  const colorImg = color
    ? buildProductColorOptions(product).find((c) => c.name.toLowerCase() === String(color).toLowerCase())?.image
    : '';
  const resolvedImage = image || colorImg || product.image || (product.images && product.images[0]) || '';

  if (idx >= 0) {
    const nextQty = Math.min(stock, cart[idx].qty + addQty);
    cart[idx] = { ...cart[idx], qty: nextQty, image: resolvedImage || cart[idx].image };
  } else {
    cart.push({
      variantKey,
      productId: product.id,
      name: product.name,
      category: product.cat || '',
      sellerId: product.sellerId || 'seller-admin',
      sellerName: product.sellerName || 'LUXE NEXUS',
      unitPrice: roundMoney(product.offerPrice || product.price),
      regularPrice: roundMoney(product.price),
      image: resolvedImage,
      size,
      color,
      qty: Math.min(stock, addQty),
    });
  }
  appServices.storage.setCollection(CART_KEY, cart);
  return cart;
}

export function updateCartItemQty(variantKey, delta) {
  const cart = getCart();
  const next = cart
    .map((item) => {
      if (item.variantKey !== variantKey) return item;
      const product = appServices.products.getById(item.productId);
      const maxStock = product ? Math.max(1, Number(product.stock || 99)) : 99;
      const nextQty = Math.min(maxStock, item.qty + delta);
      return nextQty > 0 ? { ...item, qty: nextQty } : null;
    })
    .filter(Boolean);
  appServices.storage.setCollection(CART_KEY, next);
  return next;
}

export function removeFromCart(variantKey) {
  const next = getCart().filter((item) => item.variantKey !== variantKey);
  appServices.storage.setCollection(CART_KEY, next);
  return next;
}

export function clearCart() {
  appServices.storage.setCollection(CART_KEY, []);
}

export function evaluateCouponDiscount(couponCode, subtotal) {
  const cfg = getPlatformConfig();
  if (!couponCode) return { valid: false, discount: 0, message: '' };
  if (cfg.featureFlags?.coupons?.enabled === false) {
    return { valid: false, discount: 0, message: 'Coupons are currently disabled.' };
  }
  const clean = String(couponCode).trim().toUpperCase();
  const coupon = (cfg.coupons || []).find((c) => c.code.toUpperCase() === clean && c.active !== false);
  if (!coupon) return { valid: false, discount: 0, message: 'Invalid or expired coupon code.' };
  if (roundMoney(subtotal) < roundMoney(coupon.minOrder || 0)) {
    return { valid: false, discount: 0, message: `Minimum order of ${coupon.minOrder} required.` };
  }
  const discount =
    coupon.type === 'percentage'
      ? roundMoney((roundMoney(subtotal) * Number(coupon.value || 0)) / 100)
      : roundMoney(Math.min(subtotal, Number(coupon.value || 0)));
  return { valid: true, discount, code: coupon.code, message: `Coupon ${coupon.code} applied.` };
}

export function calculateOrderTotals({ items, area = 'dhaka', couponCode = '', payment = 'COD' }) {
  const cfg = getPlatformConfig();
  const subtotal = roundMoney(
    items.reduce((sum, item) => sum + roundMoney(Number(item.unitPrice) * Number(item.qty)), 0)
  );
  const couponResult = evaluateCouponDiscount(couponCode, subtotal);
  const discount = couponResult.valid ? couponResult.discount : 0;
  const deliveryCharge = area === 'outside' ? roundMoney(cfg.checkout.outFee || 120) : roundMoney(cfg.checkout.dhakaFee || 60);
  const preFeeTotal = Math.max(0, roundMoney(subtotal - discount + deliveryCharge));
  const paymentFee = calculatePaymentFee(preFeeTotal, payment);
  const grandTotal = roundMoney(preFeeTotal + paymentFee);
  return {
    subtotal,
    discount,
    couponCode: couponResult.valid ? couponResult.code : '',
    couponMessage: couponResult.message,
    deliveryCharge,
    paymentFee,
    grandTotal,
  };
}

/**
 * Unified Order Validation & Creation Pipeline
 * Shared by both Cart Checkout and Buy Now to prevent duplicate orders or validation bypass.
 * @param {{ items: any[], customer: any, area?: string, payment?: string, couponCode?: string, source?: string, user?: any, idempotencyKey?: string, referralCode?: string | null, nowOverrideMs?: number | null }} params
 */
export function createValidatedOrder({
  items,
  customer,
  area = 'dhaka',
  payment = 'COD',
  couponCode = '',
  source = 'cart', // 'cart' | 'buy_now'
  user = null,
  idempotencyKey = '',
  referralCode = null,
  nowOverrideMs = null,
}) {
  const cfg = getPlatformConfig();
  if (source === 'buy_now') assertFeatureEnabled('buyNow', user?.role || 'customer');
  if (source === 'cart') assertFeatureEnabled('cart', user?.role || 'customer');

  if (cfg.checkout?.loginRequired && !user) {
    throw new Error('Please sign in before placing an order.');
  }

  // Prevent duplicate submission with the same idempotency key
  const usedKeys = appServices.storage.getCollection(IDEMPOTENCY_CACHE_KEY, []);
  if (idempotencyKey && usedKeys.includes(idempotencyKey)) {
    throw new Error('Duplicate order submission prevented. Your order has already been placed.');
  }

  const normalizedItems = items.map((item) => {
    const prod = appServices.products.getById(item.productId);
    if (!prod || prod.active === false || !prod.approved) {
      throw new Error(`Product "${item.name || item.productId}" is no longer available.`);
    }
    const qty = Math.max(1, Math.floor(Number(item.qty || 1)));
    const availableStock = item.size || item.color
      ? resolveVariantStock(prod, { size: item.size || '', color: item.color || '' })
      : Number(prod.stock || 0);
    if (Number(prod.stock || 0) < qty || availableStock < qty) {
      throw new Error(`Insufficient stock for "${prod.name}". Available: ${Math.min(Number(prod.stock || 0), availableStock)}.`);
    }
    const colorImg = item.color
      ? buildProductColorOptions(prod).find((c) => c.name.toLowerCase() === String(item.color).toLowerCase())?.image
      : '';
    return {
      productId: prod.id,
      name: prod.name,
      category: prod.cat,
      sellerId: prod.sellerId,
      sellerName: prod.sellerName,
      image: item.image || colorImg || prod.image,
      size: item.size || '',
      color: item.color || '',
      qty,
      unitPrice: roundMoney(prod.offerPrice || prod.price),
      lineTotal: roundMoney((prod.offerPrice || prod.price) * qty),
    };
  });

  const validation = validateCheckoutInput(
    { items: normalizedItems, customer, area, payment },
    cfg
  );
  if (!validation.valid) {
    throw new Error(validation.errors[0]);
  }

  const totals = calculateOrderTotals({
    items: normalizedItems,
    area: validation.area,
    couponCode,
    payment: validation.payment,
  });

  const orderId = `LN${Date.now().toString().slice(-8)}${Math.random().toString(36).slice(2, 4).toUpperCase()}`;
  const paymentIntent = authorizePaymentIntent({
    orderId,
    amount: totals.grandTotal,
    method: validation.payment,
  });

  const nowIso = new Date().toISOString();
  const sellerIds = [...new Set(normalizedItems.map((i) => i.sellerId))];

  const order = {
    id: orderId,
    createdAtMs: Date.now(),
    createdAt: nowIso,
    date: new Date().toLocaleString(),
    userId: user?.uid || 'guest',
    customerEmail: user?.email || customer.email || '',
    customer: {
      name: String(customer.name).trim(),
      phone: String(customer.phone).trim(),
      email: String(customer.email || user?.email || '').trim(),
      district: String(customer.district).trim(),
      upazila: String(customer.upazila).trim(),
      address: String(customer.address).trim(),
    },
    items: normalizedItems,
    sellerIds,
    // Compatibility summary fields for quick list views
    product:
      normalizedItems.length === 1
        ? normalizedItems[0].name
        : `${normalizedItems[0].name} (+${normalizedItems.length - 1} more)`,
    image: normalizedItems[0].image,
    price: totals.subtotal,
    discount: totals.discount,
    couponCode: totals.couponCode,
    delivery: totals.deliveryCharge,
    paymentFee: totals.paymentFee,
    total: totals.grandTotal,
    area: validation.area,
    payment: validation.payment,
    paymentIntentId: paymentIntent.intentId,
    source,
    status: 'Placed',
    statusHistory: [
      { status: 'Placed', timestamp: nowIso, actorId: user?.uid || 'guest', note: 'Order confirmed by customer' },
    ],
    affiliateCommissionId: null,
    affiliateId: null,
  };

  // Deduct stock atomically
  for (const item of normalizedItems) {
    updateProductStock(item.productId, -item.qty, null);
  }

  // Record affiliate conversion if valid non-expired attribution exists
  const commission = recordAffiliateConversion(order, user, referralCode, nowOverrideMs);
  if (commission) {
    order.affiliateCommissionId = commission.id;
    order.affiliateId = commission.affiliateId;
  }

  appServices.orders.upsert(order.id, order);

  if (idempotencyKey) {
    usedKeys.unshift(idempotencyKey);
    appServices.storage.setCollection(IDEMPOTENCY_CACHE_KEY, usedKeys.slice(0, 100));
  }
  if (source === 'cart') {
    clearCart();
  }

  // Notifications
  pushNotification({
    audience: 'user',
    userId: order.userId,
    category: 'Orders',
    title: `Order #${order.id} Placed`,
    message: `Your order totaling ${order.total} has been confirmed.`,
  });
  pushNotification({
    audience: 'admin',
    category: 'Orders',
    title: `New Order #${order.id}`,
    message: `${order.customer.name} placed an order for ${order.total}.`,
  });
  for (const sid of sellerIds) {
    pushNotification({
      audience: 'seller',
      userId: sid,
      category: 'Orders',
      title: `New Store Order #${order.id}`,
      message: `Contains items from your store. Ready for processing.`,
    });
  }

  return order;
}

export function listOrdersForUser(user) {
  const all = appServices.orders.list();
  if (!user) return [];
  return all.filter((o) => o.userId === user.uid || (user.email && o.customerEmail === user.email));
}

export function listOrdersForSeller(sellerId) {
  if (!sellerId) return [];
  return appServices.orders
    .list()
    .filter((o) => (o.sellerIds || []).includes(sellerId) || (o.items || []).some((i) => i.sellerId === sellerId))
    .map((o) => {
      // Seller Data Isolation: expose only this seller's items and read-only affiliate indicator
      const sellerItems = (o.items || []).filter((i) => i.sellerId === sellerId);
      const sellerSubtotal = roundMoney(sellerItems.reduce((s, i) => s + Number(i.lineTotal || 0), 0));
      return {
        ...o,
        items: sellerItems,
        sellerSubtotal,
        hasAffiliateReferral: !!o.affiliateId,
      };
    });
}

export function updateOrderDeliveryDetails(orderId, details, user) {
  const order = appServices.orders.getById(orderId);
  if (!order) throw new Error('Order not found.');
  if (user && order.userId !== user.uid) throw new Error('Access denied.');
  const elapsed = Date.now() - Number(order.createdAtMs || 0);
  if (elapsed >= 300000) {
    throw new Error('The 5-minute edit window has expired.');
  }
  const updated = {
    ...order,
    customer: {
      ...order.customer,
      name: String(details.name || '').trim(),
      phone: String(details.phone || '').trim(),
      district: String(details.district || '').trim(),
      upazila: String(details.upazila || '').trim(),
      address: String(details.address || '').trim(),
    },
  };
  appServices.orders.upsert(orderId, updated);
  return updated;
}

export function updateOrderStatus(orderId, nextStatus, actor, note = '') {
  if (!ORDER_STATUSES.includes(nextStatus)) {
    throw new Error(`Invalid order status: ${nextStatus}`);
  }
  const order = appServices.orders.getById(orderId);
  if (!order) throw new Error('Order not found.');

  const isAdmin = isAdminRole(actor.role);
  if (!isAdmin) {
    if (actor.role === ROLES.SELLER) {
      assertFeatureEnabled('sellerOrderManagement', ROLES.SELLER);
      const ownsItem = (order.sellerIds || []).includes(actor.uid) || (order.items || []).some((i) => i.sellerId === actor.uid);
      if (!ownsItem) throw new Error('Access denied: seller data isolation enforced.');
      if (['Refunded'].includes(nextStatus)) {
        throw new Error('Only Finance/Admin can mark orders as Refunded.');
      }
    } else if (actor.role === ROLES.CUSTOMER) {
      if (order.userId !== actor.uid) throw new Error('Access denied.');
      if (!['Cancelled', 'Return Requested'].includes(nextStatus)) {
        throw new Error('Customers may only request cancellation or return.');
      }
    } else {
      assertPermission(actor.role, 'manage_orders');
    }
  } else {
    assertPermission(actor.role, 'manage_orders');
  }

  const prevStatus = order.status;
  if (prevStatus === nextStatus) return order;

  // Restore stock if cancelled/refunded from an active status
  if (['Cancelled', 'Refunded'].includes(nextStatus) && !['Cancelled', 'Refunded'].includes(prevStatus)) {
    for (const item of order.items || []) {
      updateProductStock(item.productId, item.qty, null);
    }
  }

  const updated = {
    ...order,
    status: nextStatus,
    statusHistory: [
      ...(order.statusHistory || []),
      {
        status: nextStatus,
        timestamp: new Date().toISOString(),
        actorId: actor.uid,
        note: note || `Updated from ${prevStatus} to ${nextStatus}`,
      },
    ],
  };

  appServices.orders.upsert(orderId, updated);

  // Sync affiliate commission lifecycle
  syncCommissionOnOrderStatusChange(orderId, nextStatus, actor);

  pushNotification({
    audience: 'user',
    userId: order.userId,
    category: 'Orders',
    title: `Order #${order.id} — ${nextStatus}`,
    message: `Your order status is now ${nextStatus}.`,
  });

  if (isAdmin) {
    recordAuditLog({
      actorId: actor.uid,
      actorRole: actor.role,
      action: 'UPDATE_ORDER_STATUS',
      targetCollection: 'orders',
      targetId: orderId,
      details: `${prevStatus} -> ${nextStatus}`,
    });
  }

  return updated;
}

export function computeFinancialSummary(orders = appServices.orders.list()) {
  const cfg = getPlatformConfig();
  const platformFeePct = Number(cfg.checkout?.platformFeePercent ?? 10);
  const commissions = appServices.affiliates.commissions.list();

  let totalSales = 0;
  let grossRevenue = 0;
  let refunds = 0;
  let discounts = 0;
  let deliveryCharges = 0;
  let paymentFees = 0;

  for (const o of orders) {
    if (o.status === 'Cancelled') continue;
    if (o.status === 'Refunded') {
      refunds = roundMoney(refunds + Number(o.total || 0));
      continue;
    }
    totalSales = roundMoney(totalSales + Number(o.price || 0));
    grossRevenue = roundMoney(grossRevenue + Number(o.total || 0));
    discounts = roundMoney(discounts + Number(o.discount || 0));
    deliveryCharges = roundMoney(deliveryCharges + Number(o.delivery || 0));
    paymentFees = roundMoney(paymentFees + Number(o.paymentFee || 0));
  }

  const affiliateCommission = roundMoney(
    commissions
      .filter((c) => c.status === 'approved' || c.status === 'paid')
      .reduce((s, c) => s + Number(c.commissionAmount || 0), 0)
  );

  const netProductSales = Math.max(0, roundMoney(totalSales - discounts));
  const platformFeeGross = roundMoney((netProductSales * platformFeePct) / 100);
  const sellerPayout = Math.max(0, roundMoney(netProductSales - platformFeeGross));
  const platformEarnings = roundMoney(platformFeeGross - affiliateCommission);
  const netRevenue = roundMoney(grossRevenue - refunds - deliveryCharges - paymentFees - affiliateCommission);

  return {
    orderCount: orders.length,
    pendingOrders: orders.filter((o) => ['Placed', 'Confirmed', 'Processing', 'Packed', 'Shipped', 'Out for Delivery'].includes(o.status)).length,
    deliveredOrders: orders.filter((o) => o.status === 'Delivered').length,
    cancelledOrders: orders.filter((o) => o.status === 'Cancelled').length,
    totalSales,
    grossRevenue,
    netRevenue,
    sellerPayout,
    affiliateCommission,
    refunds,
    discounts,
    deliveryCharges,
    paymentFees,
    platformEarnings,
  };
}
