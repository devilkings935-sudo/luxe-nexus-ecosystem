/**
 * LUXE NEXUS App Update & Release Delivery Service (PART 6)
 * Manages semantic versions, release manifests, SHA-256 asset integrity verification,
 * compatibility checks, mandatory vs optional updates, and rollback recovery.
 */

import { appServices, assertPermission, recordAuditLog } from '../adapters/backend-adapter.js';
import { APP_VERSION, APP_VERSION_CODE } from '../shared/configuration.js';
import { compareSemver, isVersionSupported, sha256Hex } from '../shared/utilities.js';
import { ensureEcosystemSeeded } from './settings-service.js';
import { pushNotification } from './notification-service.js';

const CLIENT_INSTALLED_VERSION_KEY = 'installed_client_version';
const SKIPPED_VERSION_KEY = 'skipped_update_version';
const UPDATE_SNAPSHOT_KEY = 'previous_stable_version';

export function getCurrentInstalledVersion() {
  return appServices.storage.getCollection(CLIENT_INSTALLED_VERSION_KEY, APP_VERSION);
}

export function listReleases() {
  ensureEcosystemSeeded();
  const list = appServices.versions.list();
  return [...list].sort((a, b) => Number(b.versionCode || 0) - Number(a.versionCode || 0));
}

export function getLatestRelease() {
  const releases = listReleases().filter((r) => r.status !== 'rolled_back');
  return releases[0] || {
    version: APP_VERSION,
    versionCode: APP_VERSION_CODE,
    releaseDate: '2026-11-20',
    releaseNotes: 'Initial ecosystem baseline.',
    whatsNew: [],
    minSupportedVersion: '1.0.0',
    mandatory: false,
    manifestUrl: '/releases/manifest.json',
    checksum: '',
    status: 'active',
  };
}

export async function publishRelease(payload, actor) {
  assertPermission(actor.role, 'manage_settings');
  const version = String(payload?.version ?? '').trim();
  if (!/^\d+\.\d+\.\d+$/.test(version)) {
    throw new Error('Version must follow semantic versioning (e.g. 2.1.0).');
  }
  const latest = getLatestRelease();
  if (compareSemver(version, latest.version) <= 0) {
    throw new Error(`New version (${version}) must be higher than current latest (${latest.version}).`);
  }

  const whatsNew = Array.isArray(payload.whatsNew)
    ? payload.whatsNew
    : String(payload.whatsNew || '').split('\n').map((s) => s.trim()).filter(Boolean);

  const manifestPayload = JSON.stringify({
    version,
    releaseDate: payload.releaseDate || new Date().toISOString().slice(0, 10),
    whatsNew,
    minSupportedVersion: payload.minSupportedVersion || '1.0.0',
  });
  const checksum = await sha256Hex(manifestPayload);

  const release = {
    id: version,
    version,
    versionCode: Number(payload.versionCode || (latest.versionCode || 200) + 10),
    releaseDate: payload.releaseDate || new Date().toISOString().slice(0, 10),
    releaseNotes: String(payload.releaseNotes || '').trim(),
    whatsNew,
    minSupportedVersion: String(payload.minSupportedVersion || '1.0.0').trim(),
    mandatory: !!payload.mandatory,
    manifestUrl: payload.manifestUrl || '/releases/manifest.json',
    checksum,
    status: 'active',
    publishedBy: actor.uid,
    publishedAt: new Date().toISOString(),
  };

  appServices.versions.upsert(version, release);

  pushNotification({
    audience: 'user',
    category: 'App Updates',
    title: `Update ${version} Available`,
    message: whatsNew[0] || release.releaseNotes || 'New features and improvements are ready.',
  });

  recordAuditLog({
    actorId: actor.uid,
    actorRole: actor.role,
    action: 'PUBLISH_APP_RELEASE',
    targetCollection: 'appVersions',
    targetId: version,
    details: `mandatory=${release.mandatory}, checksum=${checksum.slice(0, 12)}`,
  });

  return release;
}

export function checkUpdateStatus(currentVersion = getCurrentInstalledVersion()) {
  const latest = getLatestRelease();
  const hasUpdate = compareSemver(latest.version, currentVersion) > 0;
  const supported = isVersionSupported(currentVersion, latest.minSupportedVersion);
  const mandatory = hasUpdate && (latest.mandatory || !supported);
  const skippedVersion = appServices.storage.getCollection(SKIPPED_VERSION_KEY, '');

  return {
    currentVersion,
    latestVersion: latest.version,
    hasUpdate,
    mandatory,
    supported,
    shouldPrompt: hasUpdate && (mandatory || skippedVersion !== latest.version),
    release: latest,
  };
}

export async function applyAppUpdate(release) {
  const current = getCurrentInstalledVersion();
  // Verify manifest integrity if checksum is present
  if (release.checksum) {
    const recomputed = await sha256Hex(
      JSON.stringify({
        version: release.version,
        releaseDate: release.releaseDate,
        whatsNew: release.whatsNew || [],
        minSupportedVersion: release.minSupportedVersion || '1.0.0',
      })
    );
    if (recomputed !== release.checksum) {
      throw new Error('Update integrity verification failed. Rollback preserved.');
    }
  }
  // Compatibility validation
  if (!isVersionSupported(release.version, release.minSupportedVersion)) {
    throw new Error('Target release failed compatibility validation.');
  }

  appServices.storage.setCollection(UPDATE_SNAPSHOT_KEY, current);
  appServices.storage.setCollection(CLIENT_INSTALLED_VERSION_KEY, release.version);
  appServices.storage.setCollection(SKIPPED_VERSION_KEY, '');

  return {
    success: true,
    previousVersion: current,
    installedVersion: release.version,
    verifiedAt: new Date().toISOString(),
  };
}

export function skipAppUpdate(version) {
  const status = checkUpdateStatus();
  if (status.mandatory) {
    throw new Error('This update is mandatory and cannot be skipped.');
  }
  appServices.storage.setCollection(SKIPPED_VERSION_KEY, version);
}

export function rollbackRelease(targetVersion, actor) {
  assertPermission(actor.role, 'manage_settings');
  const releases = listReleases();
  const target = releases.find((r) => r.version === targetVersion);
  if (!target) throw new Error('Target rollback version not found.');

  for (const r of releases) {
    if (compareSemver(r.version, targetVersion) > 0) {
      appServices.versions.upsert(r.version, { ...r, status: 'rolled_back' });
    }
  }
  appServices.versions.upsert(target.version, { ...target, status: 'active' });
  appServices.storage.setCollection(CLIENT_INSTALLED_VERSION_KEY, targetVersion);

  recordAuditLog({
    actorId: actor.uid,
    actorRole: actor.role,
    action: 'ROLLBACK_APP_RELEASE',
    targetCollection: 'appVersions',
    targetId: targetVersion,
    details: `Rolled back active release to ${targetVersion}`,
  });

  return target;
}
