/**
 * LUXE NEXUS Authentication & User Management Service
 */

import { appServices, assertPermission, recordAuditLog } from '../adapters/backend-adapter.js';
import { validateEmail, validatePhone, evaluatePasswordStrength } from '../shared/validators.js';
import { ROLES } from '../shared/permissions.js';
import { getPlatformConfig } from './settings-service.js';
import { pushNotification } from './notification-service.js';

export async function signupAccount(payload) {
  const cfg = getPlatformConfig();
  const role = payload?.role || ROLES.CUSTOMER;

  if (role === ROLES.CUSTOMER && cfg.platformFlags?.registrationEnabled === false) {
    throw new Error('New customer registration is currently disabled by Admin.');
  }
  if (role === ROLES.SELLER && cfg.platformFlags?.sellerRegistrationEnabled === false) {
    throw new Error('New seller registration is currently disabled by Admin.');
  }

  const name = String(payload?.name ?? '').trim();
  const email = String(payload?.email ?? '').trim();
  const phone = String(payload?.phone ?? '').trim();
  const password = String(payload?.password ?? '');
  const confirmPassword = payload?.confirmPassword !== undefined ? String(payload.confirmPassword) : password;

  if (!name || name.length < 2) throw new Error('Full name is required.');
  if (!validateEmail(email)) throw new Error('Please enter a valid email address.');
  if (phone && !validatePhone(phone)) throw new Error('Please enter a valid phone number.');

  const strength = evaluatePasswordStrength(password);
  if (!strength.valid) throw new Error('Password must be at least 6 characters.');
  if (password !== confirmPassword) throw new Error('Password and Confirm Password do not match.');

  if (role === ROLES.SELLER && !String(payload?.storeName ?? '').trim()) {
    throw new Error('Store name is required for seller registration.');
  }

  const username = String(payload?.username ?? '').trim();
  const created = await appServices.auth.registerUser({
    name,
    username,
    email,
    phone,
    password,
    role,
    storeName: payload?.storeName || '',
    storeDesc: payload?.storeDesc || '',
    dateOfBirth: payload?.dateOfBirth || '',
    age: payload?.age ?? null,
    city: payload?.city || '',
    socialUrl: payload?.socialUrl || '',
    bio: payload?.bio || '',
  });

  if (role === ROLES.SELLER) {
    const sellerRecord = {
      id: created.uid,
      uid: created.uid,
      name: created.name,
      email: created.email,
      phone: created.phone,
      storeName: created.storeName,
      storeDesc: created.storeDesc,
      status: 'pending',
      approved: false,
      createdAt: created.createdAt,
    };
    appServices.sellers.upsert(created.uid, sellerRecord);
    pushNotification({
      audience: 'admin',
      category: 'Sellers',
      title: 'New Seller Application',
      message: `${created.storeName} (${created.email}) is awaiting approval.`,
    });
  } else {
    pushNotification({
      audience: 'admin',
      category: 'Accounts',
      title: 'New Account Registered',
      message: `${created.name} joined as ${created.role}.`,
    });
  }

  return created;
}

export async function loginAccount({ email, password, appScope = 'user', rememberMe = true }) {
  if (!validateEmail(email)) throw new Error('Please enter a valid email address.');
  if (!password) throw new Error('Password is required.');
  return appServices.auth.authenticateUser({ email, password, appScope, rememberMe });
}

export function getActiveUser(appScope = 'user') {
  return appServices.auth.getCurrentSessionUser(appScope);
}

export function logoutAccount(appScope = 'user') {
  appServices.auth.logoutSession(appScope);
}

export async function resetPassword({ contact, newPassword, confirmPassword }) {
  if (!String(contact ?? '').trim()) throw new Error('Enter your registered email or phone number.');
  if (String(newPassword ?? '').length < 6) throw new Error('New password must be at least 6 characters.');
  if (confirmPassword !== undefined && newPassword !== confirmPassword) {
    throw new Error('Passwords do not match.');
  }
  return appServices.auth.resetUserPassword({ contact, newPassword });
}

export function updateAccountProfile(uid, updates) {
  if (updates?.email !== undefined && !validateEmail(updates.email)) {
    throw new Error('Please enter a valid email address.');
  }
  if (updates?.phone !== undefined && String(updates.phone).trim() && !validatePhone(updates.phone)) {
    throw new Error('Please enter a valid mobile number (10–15 digits).');
  }
  return appServices.auth.updateUserProfile(uid, updates);
}

export function verifyAccountContact(uid, channel) {
  const updated = appServices.auth.verifyUserContact(uid, channel);
  pushNotification({
    audience: 'user',
    userId: uid,
    category: 'Account',
    title: channel === 'email' ? 'Email Verified' : 'Mobile Number Verified',
    message:
      channel === 'email'
        ? `Your email (${updated.email}) is now verified.`
        : `Your mobile number (${updated.phone}) is now verified.`,
  });
  return updated;
}

export function listAllUsers(actor) {
  assertPermission(actor.role, 'manage_users');
  const users = appServices.storage.getCollection('users', []);
  return users.map(({ passwordHash: _p, salt: _s, ...safe }) => safe);
}

export function adminUpdateUserRoleOrStatus(targetUid, { role, status }, actor) {
  assertPermission(actor.role, 'manage_users');
  const users = appServices.storage.getCollection('users', []);
  const target = users.find((u) => u.uid === targetUid);
  if (!target) throw new Error('Target user not found.');
  if (target.role === ROLES.SUPER_ADMIN && actor.role !== ROLES.SUPER_ADMIN) {
    throw new Error('Only Super Admin can modify a Super Admin account.');
  }

  const next = {
    ...target,
    role: role || target.role,
    status: status || target.status,
    approved: (status || target.status) === 'active' || (status || target.status) === 'approved',
    updatedAt: new Date().toISOString(),
  };
  appServices.storage.upsertDoc('users', targetUid, next);
  recordAuditLog({
    actorId: actor.uid,
    actorRole: actor.role,
    action: 'UPDATE_USER_ACCESS',
    targetCollection: 'users',
    targetId: targetUid,
    details: `role=${next.role}, status=${next.status}`,
  });
  return next;
}

export function approveSellerAccount(sellerId, approved, actor, reason = '') {
  assertPermission(actor.role, 'approve');
  const seller = appServices.sellers.getById(sellerId);
  if (!seller) throw new Error('Seller record not found.');

  const status = approved ? 'approved' : 'rejected';
  const updatedSeller = {
    ...seller,
    approved: !!approved,
    status,
    rejectionReason: approved ? '' : String(reason || 'Rejected by Admin'),
    approvedAt: approved ? new Date().toISOString() : null,
  };
  appServices.sellers.upsert(sellerId, updatedSeller);

  const users = appServices.storage.getCollection('users', []);
  const userIdx = users.findIndex((u) => u.uid === sellerId || u.email === seller.email);
  if (userIdx >= 0) {
    users[userIdx] = {
      ...users[userIdx],
      approved: !!approved,
      status: approved ? 'approved' : 'rejected',
    };
    appServices.storage.setCollection('users', users);
  }

  pushNotification({
    audience: 'seller',
    userId: sellerId,
    category: 'Sellers',
    title: approved ? 'Seller Store Approved' : 'Seller Application Rejected',
    message: approved
      ? 'Your LUXE NEXUS Seller Studio is now active. You may begin adding products.'
      : `Your application was not approved: ${updatedSeller.rejectionReason}`,
  });

  recordAuditLog({
    actorId: actor.uid,
    actorRole: actor.role,
    action: approved ? 'APPROVE_SELLER' : 'REJECT_SELLER',
    targetCollection: 'sellers',
    targetId: sellerId,
    details: updatedSeller.storeName,
  });

  return updatedSeller;
}
