/**
 * LUXE NEXUS Product, Category, Inventory, Review & Q&A Service
 * Enforces Seller Data Isolation and Feature Flag rules.
 */

import { appServices, assertPermission, assertFeatureEnabled, recordAuditLog } from '../adapters/backend-adapter.js';
import { validateProductInput } from '../shared/validators.js';
import { generateId, roundMoney, sanitizeUrl, slugify } from '../shared/utilities.js';
import { isAdminRole, ROLES } from '../shared/permissions.js';
import { getPlatformConfig, ensureEcosystemSeeded } from './settings-service.js';
import { pushNotification } from './notification-service.js';

export function listAllProducts() {
  ensureEcosystemSeeded();
  return appServices.products.list();
}

export function listPublishedProducts(filters = {}) {
  const all = listAllProducts();
  let result = all.filter((p) => p.approved === true && p.active !== false);

  if (filters.category && filters.category !== 'All') {
    const catLower = filters.category.toLowerCase();
    result = result.filter((p) => String(p.cat || '').toLowerCase() === catLower);
  }
  if (filters.subcategory) {
    const subLower = filters.subcategory.toLowerCase();
    result = result.filter((p) => String(p.subcat || '').toLowerCase() === subLower);
  }
  if (filters.brand && filters.brand !== 'All') {
    const bLower = filters.brand.toLowerCase();
    result = result.filter((p) => String(p.brand || '').toLowerCase() === bLower);
  }
  if (filters.search) {
    const q = filters.search.toLowerCase().trim();
    result = result.filter((p) =>
      `${p.name} ${p.brand || ''} ${p.cat || ''} ${p.subcat || ''} ${p.desc || ''}`.toLowerCase().includes(q)
    );
  }
  if (filters.inStockOnly) {
    result = result.filter((p) => Number(p.stock ?? 0) > 0);
  }
  if (filters.minPrice !== undefined && filters.minPrice !== '') {
    const min = Number(filters.minPrice);
    if (Number.isFinite(min)) result = result.filter((p) => Number(p.offerPrice || p.price) >= min);
  }
  if (filters.maxPrice !== undefined && filters.maxPrice !== '') {
    const max = Number(filters.maxPrice);
    if (Number.isFinite(max)) result = result.filter((p) => Number(p.offerPrice || p.price) <= max);
  }
  if (filters.sectionType) {
    if (filters.sectionType === 'featured') result = result.filter((p) => p.featured);
    if (filters.sectionType === 'trending') result = result.filter((p) => p.trending);
    if (filters.sectionType === 'newArrivals') result = result.filter((p) => p.newArrival);
    if (filters.sectionType === 'bestSellers') result = result.filter((p) => p.bestSeller);
  }

  const sort = filters.sort || 'featured';
  if (sort === 'price_asc') {
    result.sort((a, b) => Number(a.offerPrice || a.price) - Number(b.offerPrice || b.price));
  } else if (sort === 'price_desc') {
    result.sort((a, b) => Number(b.offerPrice || b.price) - Number(a.offerPrice || a.price));
  } else if (sort === 'rating') {
    result.sort((a, b) => Number(b.rating || 0) - Number(a.rating || 0));
  } else if (sort === 'newest') {
    result.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
  }

  return result;
}

export function listSellerProducts(sellerId) {
  if (!sellerId) return [];
  return listAllProducts().filter((p) => p.sellerId === sellerId);
}

export function saveProduct(input, actor) {
  if (!actor) throw new Error('Authentication required.');
  const isAdmin = isAdminRole(actor.role);
  if (!isAdmin && actor.role !== ROLES.SELLER) {
    throw new Error('Only approved Sellers or Admins can manage products.');
  }
  if (actor.role === ROLES.SELLER) {
    assertFeatureEnabled('productUpload', actor.role);
  } else {
    assertPermission(actor.role, input.id ? 'edit' : 'create');
  }

  const validation = validateProductInput(input);
  if (!validation.valid) {
    throw new Error(validation.errors[0]);
  }

  const cfg = getPlatformConfig();
  const existing = input.id ? appServices.products.getById(input.id) : null;

  // Strict Seller Data Isolation
  if (existing && !isAdmin && existing.sellerId !== actor.uid) {
    throw new Error('Access denied: you may only edit your own store products.');
  }

  const discountPercent = Math.max(
    0,
    Math.round(((validation.price - validation.offerPrice) * 100) / validation.price)
  );

  const needsApproval = !isAdmin && cfg.platformFlags?.productApprovalRequired !== false;
  const approved = isAdmin
    ? input.approved !== undefined
      ? !!input.approved
      : true
    : needsApproval
    ? false
    : true;

  const record = {
    id: existing?.id || generateId('LN-PROD'),
    name: String(input.name).trim(),
    brand: String(input.brand || '').trim() || actor.storeName || 'LUXE NEXUS',
    sku: String(input.sku || '').trim() || generateId('SKU'),
    cat: String(input.cat || input.category).trim(),
    subcat: String(input.subcat || '').trim(),
    price: validation.price,
    offerPrice: validation.offerPrice,
    discountPercent,
    stock: validation.stock,
    rating: existing?.rating || 4.8,
    featured: !!input.featured,
    trending: !!input.trending,
    newArrival: input.newArrival !== undefined ? !!input.newArrival : !existing,
    bestSeller: !!input.bestSeller,
    flashSale: !!input.flashSale,
    active: input.active !== false,
    approved,
    status: approved ? 'Published' : 'Pending Review',
    sellerId: existing?.sellerId || (isAdmin ? input.sellerId || 'seller-admin' : actor.uid),
    sellerName: existing?.sellerName || (isAdmin ? input.sellerName || 'LUXE NEXUS Official' : actor.storeName || actor.name),
    images: validation.cleanImages,
    image: validation.cleanImages[0],
    video: sanitizeUrl(input.video || ''),
    sizes: String(input.sizes || '').trim(),
    colors: String(input.colors || '').trim(),
    material: String(input.material || '').trim(),
    weight: String(input.weight || '').trim(),
    dimensions: String(input.dimensions || '').trim(),
    warranty: String(input.warranty || '').trim(),
    included: String(input.included || '').trim(),
    delivery: String(input.delivery || '').trim(),
    return: String(input.return || '').trim(),
    highlights: String(input.highlights || '').trim(),
    desc: String(input.desc || '').trim(),
    specs: String(input.specs || '').trim(),
    extra: String(input.extra || '').trim(),
    createdAt: existing?.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  appServices.products.upsert(record.id, record);

  if (!isAdmin && needsApproval) {
    pushNotification({
      audience: 'admin',
      category: 'Products',
      title: 'Product Awaiting Approval',
      message: `${record.name} submitted by ${record.sellerName}.`,
    });
  }

  return record;
}

export function deleteProduct(productId, actor) {
  const existing = appServices.products.getById(productId);
  if (!existing) return false;
  const isAdmin = isAdminRole(actor.role);
  if (!isAdmin && existing.sellerId !== actor.uid) {
    throw new Error('Access denied: you may only delete your own products.');
  }
  assertPermission(actor.role, 'delete');
  return appServices.products.remove(productId);
}

export function setProductApproval(productId, approved, actor) {
  assertPermission(actor.role, 'approve');
  const existing = appServices.products.getById(productId);
  if (!existing) throw new Error('Product not found.');
  const updated = {
    ...existing,
    approved: !!approved,
    status: approved ? 'Published' : 'Rejected',
    updatedAt: new Date().toISOString(),
  };
  appServices.products.upsert(productId, updated);
  pushNotification({
    audience: 'seller',
    userId: existing.sellerId,
    category: 'Products',
    title: approved ? 'Product Published' : 'Product Rejected',
    message: `${existing.name} is now ${updated.status}.`,
  });
  recordAuditLog({
    actorId: actor.uid,
    actorRole: actor.role,
    action: approved ? 'APPROVE_PRODUCT' : 'REJECT_PRODUCT',
    targetCollection: 'products',
    targetId: productId,
    details: existing.name,
  });
  return updated;
}

export function updateProductStock(productId, delta, actor) {
  const existing = appServices.products.getById(productId);
  if (!existing) throw new Error('Product not found.');
  if (actor && !isAdminRole(actor.role) && existing.sellerId !== actor.uid) {
    throw new Error('Access denied: seller data isolation enforced.');
  }
  const nextStock = Math.max(0, Math.floor(Number(existing.stock || 0) + Number(delta || 0)));
  const updated = { ...existing, stock: nextStock, updatedAt: new Date().toISOString() };
  appServices.products.upsert(productId, updated);
  return updated;
}

export function listCategories() {
  ensureEcosystemSeeded();
  return appServices.categories.list();
}

export function saveCategory({ name, image = '', icon = '🛍️', subcategories = [] }, actor) {
  assertPermission(actor.role, 'create');
  const cleanName = String(name || '').trim();
  if (!cleanName) throw new Error('Category name is required.');
  const record = {
    id: `cat-${slugify(cleanName)}`,
    name: cleanName,
    icon,
    image: sanitizeUrl(image, true),
    subcategories: Array.isArray(subcategories) ? subcategories : [],
  };
  appServices.categories.upsert(record.id, record);
  return record;
}

export function deleteCategory(id, actor) {
  assertPermission(actor.role, 'delete');
  return appServices.categories.remove(id);
}

export function listProductReviews(productId) {
  const all = appServices.storage.getCollection('reviews', {});
  return Array.isArray(all[productId]) ? all[productId] : [];
}

export function submitProductReview(productId, { rating, text }, user) {
  assertFeatureEnabled('productReviews', user?.role || 'customer');
  if (!user) throw new Error('Please sign in to submit a review.');
  const cleanText = String(text ?? '').trim();
  if (!cleanText) throw new Error('Review text cannot be empty.');
  const r = Math.min(5, Math.max(1, Math.round(Number(rating || 5))));

  const all = appServices.storage.getCollection('reviews', {});
  const list = Array.isArray(all[productId]) ? all[productId] : [];
  const entry = {
    id: generateId('REV'),
    productId,
    userId: user.uid,
    name: user.name,
    rating: r,
    text: cleanText,
    createdAt: new Date().toISOString(),
  };
  list.unshift(entry);
  all[productId] = list;
  appServices.storage.setCollection('reviews', all);

  // Recalculate product rating
  const product = appServices.products.getById(productId);
  if (product) {
    const avg = roundMoney(list.reduce((sum, x) => sum + Number(x.rating || 5), 0) / list.length);
    appServices.products.upsert(productId, { ...product, rating: Math.min(5, Math.max(1, avg)) });
  }
  return entry;
}

export function listProductQuestions(productId) {
  const all = appServices.storage.getCollection('productQuestions', {});
  return Array.isArray(all[productId]) ? all[productId] : [];
}

export function submitProductQuestion(productId, questionText, user) {
  assertFeatureEnabled('productQuestions', user?.role || 'customer');
  if (!user) throw new Error('Please sign in to ask a question.');
  const q = String(questionText ?? '').trim();
  if (!q) throw new Error('Please enter your question.');
  const all = appServices.storage.getCollection('productQuestions', {});
  const list = Array.isArray(all[productId]) ? all[productId] : [];
  const entry = {
    id: generateId('QNA'),
    productId,
    userId: user.uid,
    name: user.name,
    question: q,
    answer: '',
    createdAt: new Date().toISOString(),
  };
  list.unshift(entry);
  all[productId] = list;
  appServices.storage.setCollection('productQuestions', all);
  return entry;
}
