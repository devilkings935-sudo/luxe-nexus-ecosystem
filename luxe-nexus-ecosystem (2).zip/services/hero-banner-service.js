/**
 * LUXE NEXUS Hero Banner / Slider Pure Logic & Persistence Service
 * Decoupled from DOM for fast unit testing and cross-app real-time sync.
 */

import { DEFAULT_CONFIG, DEFAULT_HERO_SLIDER_SETTINGS } from '../shared/configuration.js';
import { sanitizeUrl, generateId } from '../shared/utilities.js';
import { getPlatformConfig, updatePlatformConfig } from './settings-service.js';

export const HEIGHT_PRESETS = {
  compact: { desktopHeight: 220, mobileHeight: 185 },
  standard: { desktopHeight: 290, mobileHeight: 235 },
  editorial: { desktopHeight: 370, mobileHeight: 290 },
  showcase: { desktopHeight: 450, mobileHeight: 340 },
};

export const DESKTOP_SIZE_PRESETS = {
  compact: { desktopMaxWidth: 880 },
  container: { desktopMaxWidth: 1120 },
  wide: { desktopMaxWidth: 1440 },
};

export const MOBILE_SIZE_PRESETS = {
  compact: { mobileHeight: 190 },
  standard: { mobileHeight: 235 },
  tall: { mobileHeight: 310 },
};

export const VALID_ANIMATIONS = new Set([
  'fade',
  'slide-horizontal',
  'slide-vertical',
  'zoom',
  'fade-zoom',
  'none',
]);

export const VALID_IMAGE_FITS = new Set(['cover', 'contain']);
export const VALID_IMAGE_POSITIONS = new Set(['center', 'left', 'right', 'top', 'bottom']);
export const VALID_INTENSITIES = new Set(['subtle', 'balanced', 'dramatic']);

function clampNum(val, min, max, fallback) {
  const n = Number(val);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

export function normalizeHeroSlide(raw = {}, index = 0) {
  const subtitle = String(raw.subtitle ?? raw.eyebrow ?? '').trim();
  const desktopImg = sanitizeUrl(raw.image || '', true);
  const mobileImg = sanitizeUrl(raw.mobileImage || '', true);

  return {
    id: String(raw.id || `SLD-${index + 1}`),
    enabled: raw.enabled !== false,
    eyebrow: subtitle,
    subtitle,
    title: String(raw.title || '').trim(),
    desc: String(raw.desc || '').trim(),
    image: desktopImg,
    mobileImage: mobileImg,
    button: String(raw.button || '').trim(),
    link: String(raw.link || 'category:all').trim() || 'category:all',
  };
}

export function normalizeHeroSliderConfig(raw = {}) {
  const d = DEFAULT_HERO_SLIDER_SETTINGS;
  const src = raw && typeof raw === 'object' ? raw : {};

  const minHeight = clampNum(src.minHeight, 120, 900, d.minHeight);
  const maxHeight = clampNum(src.maxHeight, minHeight, 1200, Math.max(minHeight, d.maxHeight));
  const desktopHeight = clampNum(src.desktopHeight, minHeight, maxHeight, clampNum(d.desktopHeight, minHeight, maxHeight, 290));
  const mobileHeight = clampNum(src.mobileHeight, 120, maxHeight, clampNum(d.mobileHeight, 120, maxHeight, 235));

  const animationType = VALID_ANIMATIONS.has(src.animationType) ? src.animationType : d.animationType;
  const imageFit = VALID_IMAGE_FITS.has(src.imageFit) ? src.imageFit : d.imageFit;
  const imagePosition = VALID_IMAGE_POSITIONS.has(src.imagePosition) ? src.imagePosition : d.imagePosition;
  const animationIntensity = VALID_INTENSITIES.has(src.animationIntensity) ? src.animationIntensity : d.animationIntensity;

  return {
    heightPreset: String(src.heightPreset || d.heightPreset),
    desktopHeight,
    mobileHeight,
    minHeight,
    maxHeight,
    aspectRatio: String(src.aspectRatio || d.aspectRatio),
    customAspectRatio: String(src.customAspectRatio || d.customAspectRatio).trim() || '16/7',
    desktopSizePreset: String(src.desktopSizePreset || d.desktopSizePreset),
    desktopMaxWidth: clampNum(src.desktopMaxWidth, 480, 2400, d.desktopMaxWidth),
    mobileSizePreset: String(src.mobileSizePreset || d.mobileSizePreset),
    imageFit,
    imagePosition,
    borderRadiusPreset: String(src.borderRadiusPreset || d.borderRadiusPreset),
    borderRadius: clampNum(src.borderRadius, 0, 64, d.borderRadius),
    spacingPreset: String(src.spacingPreset || d.spacingPreset),
    bannerSpacing: clampNum(src.bannerSpacing, 0, 64, d.bannerSpacing),

    animationType,
    animationDurationMs: clampNum(src.animationDurationMs, 0, 3000, d.animationDurationMs),
    transitionEasing: String(src.transitionEasing || d.transitionEasing),
    animationIntensity,

    autoSlide: src.autoSlide !== false,
    autoSlideIntervalSec: clampNum(src.autoSlideIntervalSec, 1, 60, d.autoSlideIntervalSec),
    pauseOnHover: src.pauseOnHover !== false,
    pauseOnInteraction: src.pauseOnInteraction !== false,
    showArrows: src.showArrows !== false,
    showDots: src.showDots !== false,
    loop: src.loop !== false,
  };
}

export function getActiveHeroSlides(cfg = {}) {
  const list = Array.isArray(cfg.bannerSlides) ? cfg.bannerSlides : [];
  return list
    .map((s, idx) => normalizeHeroSlide(s, idx))
    .filter((s) => s.enabled !== false);
}

export function reorderHeroSlides(slides = [], fromIndex, toIndex) {
  const list = Array.isArray(slides) ? [...slides] : [];
  if (
    fromIndex < 0 ||
    toIndex < 0 ||
    fromIndex >= list.length ||
    toIndex >= list.length ||
    fromIndex === toIndex
  ) {
    return list;
  }
  const [moved] = list.splice(fromIndex, 1);
  list.splice(toIndex, 0, moved);
  return list;
}

export function createEmptyHeroSlide() {
  return normalizeHeroSlide(
    {
      id: generateId('SLD'),
      enabled: true,
      subtitle: 'NEW COLLECTION',
      title: 'Curated Seasonal Highlights',
      desc: 'Explore signature releases crafted with enduring materials.',
      image: '/src/assets/images/hero_luxe_collection_1795240520616.jpg',
      mobileImage: '',
      button: 'Explore Now',
      link: 'category:all',
    },
    0
  );
}

export function resolveHeroSlideImage(slide, viewportWidth = 1280) {
  const s = normalizeHeroSlide(slide, 0);
  if (Number(viewportWidth) < 760 && s.mobileImage) {
    return s.mobileImage;
  }
  return s.image || s.mobileImage || '';
}

export function resolveAspectRatioValue(heroCfg) {
  const raw = heroCfg.aspectRatio === 'custom' ? heroCfg.customAspectRatio : heroCfg.aspectRatio;
  if (!raw || raw === 'auto') return 'auto';
  const cleaned = String(raw).trim().replace(/\s+/g, '');
  return /^\d+(\.\d+)?\/\d+(\.\d+)?$/.test(cleaned) ? cleaned : 'auto';
}

export function computeHeroLayoutStyles(rawCfg, viewportWidth = 1280) {
  const cfg = normalizeHeroSliderConfig(rawCfg);
  const isMobile = Number(viewportWidth) < 760;
  const heightPx = isMobile ? cfg.mobileHeight : cfg.desktopHeight;
  const aspectRatio = resolveAspectRatioValue(cfg);
  const durationMs = cfg.animationType === 'none' ? 0 : cfg.animationDurationMs;
  const zoomScale =
    cfg.animationIntensity === 'subtle' ? 1.035 : cfg.animationIntensity === 'dramatic' ? 1.12 : 1.07;

  return {
    isMobile,
    heightCss: aspectRatio !== 'auto' ? 'auto' : `${heightPx}px`,
    minHeightCss: `${cfg.minHeight}px`,
    maxHeightCss: `${cfg.maxHeight}px`,
    aspectRatio,
    maxWidthCss: isMobile
      ? '100%'
      : cfg.desktopSizePreset === 'wide'
      ? '100%'
      : `${cfg.desktopMaxWidth}px`,
    borderRadiusCss: `${cfg.borderRadius}px`,
    marginCss: `${cfg.bannerSpacing}px auto`,
    marginHorizontalCss: isMobile ? `${Math.min(cfg.bannerSpacing, 16)}px` : 'auto',
    objectFit: cfg.imageFit,
    objectPosition: cfg.imagePosition,
    durationMs,
    easing: cfg.transitionEasing,
    zoomScale,
    animationType: cfg.animationType,
  };
}

export function saveHeroBannerConfig({ bannerSlides, heroSlider }, actor = { uid: 'admin', role: 'super_admin' }) {
  const current = getPlatformConfig();
  const normalizedSlides = Array.isArray(bannerSlides)
    ? bannerSlides.map((s, idx) => normalizeHeroSlide(s, idx))
    : (current.bannerSlides || []).map((s, idx) => normalizeHeroSlide(s, idx));

  const normalizedSlider = normalizeHeroSliderConfig(heroSlider || current.heroSlider || DEFAULT_HERO_SLIDER_SETTINGS);
  const primarySlide = normalizedSlides.find((s) => s.enabled !== false) || normalizedSlides[0];

  return updatePlatformConfig(
    {
      bannerSlides: normalizedSlides,
      heroSlider: normalizedSlider,
      ...(primarySlide
        ? {
            eyebrow: primarySlide.subtitle || current.eyebrow,
            heroTitle: primarySlide.title || current.heroTitle,
            heroDesc: primarySlide.desc || current.heroDesc,
            heroImage: primarySlide.image || current.heroImage,
            heroButton: primarySlide.button || current.heroButton,
            heroLink: primarySlide.link || current.heroLink,
          }
        : {}),
    },
    actor
  );
}

export function resetHeroBannerConfig(actor = { uid: 'admin', role: 'super_admin' }) {
  return updatePlatformConfig(
    {
      bannerSlides: structuredClone(DEFAULT_CONFIG.bannerSlides),
      heroSlider: structuredClone(DEFAULT_HERO_SLIDER_SETTINGS),
      eyebrow: DEFAULT_CONFIG.eyebrow,
      heroTitle: DEFAULT_CONFIG.heroTitle,
      heroDesc: DEFAULT_CONFIG.heroDesc,
      heroImage: DEFAULT_CONFIG.heroImage,
      heroButton: DEFAULT_CONFIG.heroButton,
      heroLink: DEFAULT_CONFIG.heroLink,
    },
    actor
  );
}
