import test from 'node:test';
import assert from 'node:assert/strict';

import { resetMemoryStore } from '../adapters/storage-adapter.js';
import {
  roundMoney,
  formatMoney,
  sanitizeUrl,
  compareSemver,
  isVersionSupported,
  toCsv,
  generateQrMatrix,
  getDisplayUserName,
  buildProductShareUrl,
  buildProductShareTargets,
} from '../shared/utilities.js';
import {
  validateProductInput,
  validateCheckoutInput,
  validateWithdrawalRequest,
  evaluatePasswordStrength,
} from '../shared/validators.js';
import { ROLES, hasPermission, canModifyRoleMatrix } from '../shared/permissions.js';
import { DEFAULT_CONFIG, OFFICIAL_LOGO_URL } from '../shared/configuration.js';
import { appServices } from '../adapters/backend-adapter.js';
import { ensureEcosystemSeeded, getPlatformConfig, getActiveHomepageSections, updatePlatformConfig, t } from '../services/settings-service.js';
import {
  signupAccount,
  loginAccount,
  approveSellerAccount,
  updateAccountProfile,
  verifyAccountContact,
} from '../services/auth-service.js';
import {
  saveProduct,
  deleteProduct,
  listSellerProducts,
  setProductApproval,
} from '../services/product-service.js';
import {
  addToCart,
  getCart,
  getCartCount,
  calculateOrderTotals,
  createValidatedOrder,
  updateOrderStatus,
  computeFinancialSummary,
  clearCart,
} from '../services/order-service.js';
import {
  AFFILIATE_PROGRAM_RULES,
  applyForAffiliate,
  updateAffiliateStatus,
  createAffiliateLink,
  trackReferralClick,
  evaluateLinkStatus,
  getAffiliateDashboardMetrics,
  requestAffiliateWithdrawal,
  adminProcessWithdrawal,
  getAffiliateLeaderboard,
  evaluateAffiliateEligibility,
  evaluateAffiliateLevel,
  adminSetAffiliateLevel,
  adminUpdateAffiliateHolds,
  adminOverrideCommissionStatus,
  getAffiliateLevelConfig,
} from '../services/affiliate-service.js';
import {
  publishRelease,
  checkUpdateStatus,
  applyAppUpdate,
  skipAppUpdate,
  rollbackRelease,
} from '../services/update-service.js';
import {
  normalizeHeroSlide,
  normalizeHeroSliderConfig,
  getActiveHeroSlides,
  reorderHeroSlides,
  resolveHeroSlideImage,
  computeHeroLayoutStyles,
  saveHeroBannerConfig,
  resetHeroBannerConfig,
} from '../services/hero-banner-service.js';
import {
  buildProductColorOptions,
  buildProductSizeOptions,
  resolveVariantStock,
  clampVariantQty,
  resolveDefaultVariantSelection,
  validateBuyNowSelection,
} from '../services/variant-service.js';

test('Utilities: decimal-safe money math, URL sanitization, semver, CSV, and QR matrix', () => {
  assert.equal(roundMoney(0.1 + 0.2), 0.3);
  assert.equal(roundMoney(1999.995), 2000);
  assert.equal(formatMoney(1000, 'USD', { USD: 0.01 }), '$10.00');
  assert.equal(sanitizeUrl('javascript:alert(1)'), '');
  assert.equal(sanitizeUrl('https://luxenexus.example/img.jpg'), 'https://luxenexus.example/img.jpg');
  assert.equal(sanitizeUrl('/src/assets/images/test.jpg'), '/src/assets/images/test.jpg');
  assert.equal(compareSemver('2.1.0', '2.0.0'), 1);
  assert.equal(compareSemver('1.9.9', '2.0.0'), -1);
  assert.equal(isVersionSupported('1.5.0', '2.0.0'), false);
  assert.equal(toCsv(['A', 'B'], [['hello, world', 'x']]), 'A,B\n"hello, world",x');
  const qr = generateQrMatrix('https://luxe.test/?ref=LN123');
  assert.equal(qr.length, 21);
  assert.equal(qr[0][0], 1);
});

test('Validators & RBAC: product, checkout, withdrawal, and Super Admin protection', () => {
  assert.equal(evaluatePasswordStrength('123').valid, false);
  assert.equal(evaluatePasswordStrength('Strong#2026').score >= 3, true);

  const badProd = validateProductInput({ name: 'X', cat: '', price: 100, offerPrice: 150, images: [] });
  assert.equal(badProd.valid, false);
  assert.ok(badProd.errors.length >= 2);

  const badCheckout = validateCheckoutInput(
    { items: [{ productId: 'P1', qty: 1, unitPrice: 100 }], customer: { name: '', phone: '123', district: '', upazila: '', address: '' }, payment: 'bKash' },
    { checkout: { cod: true, bkash: false, nagad: false } }
  );
  assert.equal(badCheckout.valid, false);

  const badWithdraw = validateWithdrawalRequest(
    { method: 'bKash', accountHolder: 'A', accountNumber: '01711111111', amount: 300 },
    1000,
    500
  );
  assert.equal(badWithdraw.valid, false);

  assert.equal(hasPermission(ROLES.SUPER_ADMIN, 'manage_payments'), true);
  assert.equal(hasPermission(ROLES.CUSTOMER, 'manage_payments'), false);
  assert.equal(canModifyRoleMatrix(ROLES.ADMIN, ROLES.SELLER), false);
  assert.equal(canModifyRoleMatrix(ROLES.SUPER_ADMIN, ROLES.SUPER_ADMIN), false);
  assert.equal(canModifyRoleMatrix(ROLES.SUPER_ADMIN, ROLES.ORDER_MANAGER), true);
});

test('Auth, Seller Approval Gate, and Seller Data Isolation', async () => {
  resetMemoryStore();
  ensureEcosystemSeeded();

  // First admin bootstraps as Super Admin without any hardcoded password
  const admin = await signupAccount({
    name: 'Platform Owner',
    email: 'owner@luxenexus.test',
    password: 'OwnerPass#2026',
    role: ROLES.ADMIN,
  });
  assert.equal(admin.role, ROLES.SUPER_ADMIN);

  // Register two sellers
  const sellerA = await signupAccount({
    name: 'Seller A',
    email: 'sellera@test.com',
    phone: '01700000001',
    password: 'Password#1',
    role: ROLES.SELLER,
    storeName: 'House A',
  });
  const sellerB = await signupAccount({
    name: 'Seller B',
    email: 'sellerb@test.com',
    phone: '01700000002',
    password: 'Password#1',
    role: ROLES.SELLER,
    storeName: 'House B',
  });

  // Pending seller cannot login
  await assert.rejects(
    loginAccount({ email: 'sellera@test.com', password: 'Password#1', appScope: 'seller' }),
    /pending Admin approval/
  );

  // Admin approves both
  approveSellerAccount(sellerA.uid, true, admin);
  approveSellerAccount(sellerB.uid, true, admin);

  const loggedA = await loginAccount({ email: 'sellera@test.com', password: 'Password#1', appScope: 'seller' });
  const loggedB = await loginAccount({ email: 'sellerb@test.com', password: 'Password#1', appScope: 'seller' });

  const prodA = saveProduct(
    { name: 'Silk Scarf', cat: 'Fashion', price: 1500, offerPrice: 1200, stock: 10, images: ['/src/assets/images/prod_tailored_shirt_1795240519571.jpg'] },
    loggedA
  );
  assert.equal(prodA.approved, false);
  assert.equal(listSellerProducts(loggedB.uid).length, 0);

  // Seller B cannot edit or delete Seller A's product
  assert.throws(
    () => saveProduct({ id: prodA.id, name: 'Hijacked', cat: 'Fashion', price: 100, images: ['/src/assets/images/prod_tailored_shirt_1795240519571.jpg'] }, loggedB),
    /Access denied/
  );
  assert.throws(() => deleteProduct(prodA.id, loggedB), /Access denied/);

  setProductApproval(prodA.id, true, admin);
  assert.equal(listSellerProducts(loggedA.uid)[0].status, 'Published');
});

test('Cart, Unified Order Validation, Duplicate Prevention, Stock & Financial Ledger', async () => {
  resetMemoryStore();
  ensureEcosystemSeeded();

  const buyer = await signupAccount({
    name: 'Ayesha Rahman',
    email: 'ayesha@test.com',
    phone: '01712345678',
    password: 'BuyerPass#1',
    role: ROLES.CUSTOMER,
  });

  const admin = await signupAccount({
    name: 'Admin User',
    email: 'admin2@test.com',
    password: 'AdminPass#1',
    role: ROLES.ADMIN,
  });

  clearCart();
  addToCart({ id: 'LN-PROD-101', name: 'Tailored Organic Cotton Shirt', cat: 'Fashion', sellerId: 'seller-atelier-nord', sellerName: 'Atelier Nord', offerPrice: 1790, price: 2290, stock: 28, image: '/src/assets/images/prod_tailored_shirt_1795240519571.jpg' }, { qty: 2, size: 'M' });
  assert.equal(getCartCount(), 2);

  const totals = calculateOrderTotals({ items: getCart(), area: 'dhaka', couponCode: 'LUXE100', payment: 'COD' });
  assert.equal(totals.subtotal, 3580);
  assert.equal(totals.discount, 100);
  assert.equal(totals.deliveryCharge, 60);
  assert.equal(totals.grandTotal, 3540);

  const order = createValidatedOrder({
    items: getCart(),
    customer: { name: 'Ayesha Rahman', phone: '01712345678', district: 'Dhaka', upazila: 'Banani', address: 'Road 11, House 24' },
    area: 'dhaka',
    payment: 'COD',
    couponCode: 'LUXE100',
    source: 'cart',
    user: buyer,
    idempotencyKey: 'idem-001',
  });

  assert.equal(order.status, 'Placed');
  assert.equal(getCartCount(), 0);

  // Duplicate order submission blocked
  assert.throws(
    () =>
      createValidatedOrder({
        items: [{ productId: 'LN-PROD-101', qty: 1 }],
        customer: { name: 'Ayesha Rahman', phone: '01712345678', district: 'Dhaka', upazila: 'Banani', address: 'Road 11, House 24' },
        user: buyer,
        idempotencyKey: 'idem-001',
      }),
    /Duplicate order submission prevented/
  );

  // Progress order to Delivered and check financial summary
  updateOrderStatus(order.id, 'Confirmed', admin);
  updateOrderStatus(order.id, 'Delivered', admin);
  const fin = computeFinancialSummary();
  assert.equal(fin.deliveredOrders, 1);
  assert.equal(fin.totalSales, 3580);
  assert.equal(fin.discounts, 100);
});

test('Affiliate System: Approval Gate, 168h Expiry, Self-Referral Guard, Commissions & Atomic Withdrawals', async () => {
  resetMemoryStore();
  ensureEcosystemSeeded();

  const admin = await signupAccount({
    name: 'Super Admin',
    email: 'affadmin@test.com',
    password: 'AdminPass#1',
    role: ROLES.ADMIN,
  });
  const creator = await signupAccount({
    name: 'Rafiq Creator',
    email: 'rafiq@test.com',
    phone: '01811112222',
    password: 'CreatorPass#1',
    role: ROLES.CUSTOMER,
    age: 24,
    city: 'Dhaka',
    socialUrl: 'https://youtube.com/@rafiqstyle',
  });
  verifyAccountContact(creator.uid, 'email');
  verifyAccountContact(creator.uid, 'phone');

  const customer = await signupAccount({
    name: 'Samira Buyer',
    email: 'samira@test.com',
    phone: '01922223333',
    password: 'BuyerPass#1',
    role: ROLES.CUSTOMER,
  });

  const baseTime = Date.now() + 73 * 3600 * 1000;
  const aff = applyForAffiliate(
    {
      name: creator.name,
      userId: creator.uid,
      phone: creator.phone,
      email: creator.email,
      age: 24,
      socialLink: 'https://youtube.com/@rafiqstyle',
      followerCount: 15000,
      promotionMedium: 'YouTube',
      marketingPlan: 'Curated unboxing videos and editorial watch reviews on YouTube.',
      termsAccepted: true,
    },
    baseTime
  );
  assert.equal(aff.status, 'pending');
  assert.equal(aff.level, 'bronze');

  // Cannot create link before Admin approval
  assert.throws(() => createAffiliateLink({ affiliateId: aff.id, type: 'store' }, baseTime), /Admin approval is required/);

  // Approve affiliate
  const approvedAff = updateAffiliateStatus(aff.id, 'approved', admin, '', baseTime);
  assert.equal(approvedAff.status, 'approved');

  const link = createAffiliateLink(
    { affiliateId: aff.id, type: 'product', targetId: 'LN-PROD-102', targetName: 'Meridian Watch', label: 'Watch Campaign' },
    baseTime
  );
  assert.equal(evaluateLinkStatus(link, baseTime + 1000), 'active');
  // 169 hours later -> expired
  assert.equal(evaluateLinkStatus(link, baseTime + 169 * 3600 * 1000), 'expired');

  // Self-referral click is blocked
  const selfClick = trackReferralClick({ code: link.code, visitorId: 'v-self', buyerUserId: creator.uid }, baseTime + 5000);
  assert.equal(selfClick.attributed, false);

  // Valid customer click
  const clickRes = trackReferralClick({ code: link.code, visitorId: 'v-samira', buyerUserId: customer.uid }, baseTime + 6000);
  assert.equal(clickRes.attributed, true);

  // Customer purchases the watch
  const order = createValidatedOrder({
    items: [{ productId: 'LN-PROD-102', qty: 1 }],
    customer: { name: customer.name, phone: customer.phone, district: 'Dhaka', upazila: 'Gulshan', address: 'House 12 Road 5' },
    area: 'dhaka',
    payment: 'COD',
    source: 'buy_now',
    user: customer,
    referralCode: link.code,
    nowOverrideMs: baseTime + 8000,
  });
  assert.ok(order.affiliateCommissionId);

  // Watches category has 10% rate on 4490 = 449
  let metrics = getAffiliateDashboardMetrics(aff.id, baseTime + 10000);
  assert.equal(metrics.pendingCommission, 449);
  assert.equal(metrics.availableBalance, 0);

  // Deliver order -> commission becomes Approved!
  updateOrderStatus(order.id, 'Delivered', admin);
  metrics = getAffiliateDashboardMetrics(aff.id, baseTime + 15000);
  assert.equal(metrics.approvedCommission, 449);
  assert.equal(metrics.availableBalance, 449);

  // Lower minWithdrawal to 300 via Admin config and test withdrawal + double withdrawal block
  const prevAffCfg = getPlatformConfig().affiliateConfig;
  updatePlatformConfig(
    { affiliateConfig: { ...prevAffCfg, minWithdrawal: 300 } },
    admin
  );

  const w1 = requestAffiliateWithdrawal(
    aff.id,
    { method: 'bKash', accountHolder: 'Rafiq Creator', accountNumber: '01811112222', amount: 400 },
    creator.uid
  );
  assert.equal(w1.status, 'pending');

  // Double withdrawal exceeding remaining 49 must be rejected
  assert.throws(
    () => requestAffiliateWithdrawal(aff.id, { method: 'bKash', accountHolder: 'Rafiq Creator', accountNumber: '01811112222', amount: 300 }, creator.uid),
    /exceeds available balance/
  );

  const paidW = adminProcessWithdrawal(w1.id, { status: 'paid', transactionId: 'BKASH-TX-9988', paymentReference: 'REF-1' }, admin);
  assert.equal(paidW.status, 'paid');

  const leaderboard = getAffiliateLeaderboard('monthly', baseTime + 20000);
  assert.equal(leaderboard.length, 1);
  assert.equal(leaderboard[0].totalSales, 4490);
});

test('Update Manager: Publish Release, Integrity Check, Skip & Rollback', async () => {
  resetMemoryStore();
  ensureEcosystemSeeded();

  const admin = await signupAccount({
    name: 'Release Admin',
    email: 'reladmin@test.com',
    password: 'AdminPass#1',
    role: ROLES.ADMIN,
  });

  const rel = await publishRelease(
    {
      version: '2.1.0',
      versionCode: 210,
      releaseNotes: 'Performance & affiliate analytics enhancements.',
      whatsNew: ['Faster checkout', 'QR matrix upgrades'],
      minSupportedVersion: '2.0.0',
      mandatory: false,
    },
    admin
  );

  let status = checkUpdateStatus('2.0.0');
  assert.equal(status.hasUpdate, true);
  assert.equal(status.mandatory, false);
  assert.equal(status.shouldPrompt, true);

  skipAppUpdate('2.1.0');
  status = checkUpdateStatus('2.0.0');
  assert.equal(status.shouldPrompt, false);

  const applied = await applyAppUpdate(rel);
  assert.equal(applied.installedVersion, '2.1.0');

  rollbackRelease('2.0.0', admin);
  const afterRollback = checkUpdateStatus('2.0.0');
  assert.equal(afterRollback.latestVersion, '2.0.0');
  assert.equal(afterRollback.hasUpdate, false);
});

test('Luxury Dark Theme, Official Logo, Legacy Config Migration & See More Translation', () => {
  resetMemoryStore();
  ensureEcosystemSeeded();

  assert.equal(DEFAULT_CONFIG.logo, OFFICIAL_LOGO_URL);
  assert.equal(DEFAULT_CONFIG.themeVersion, 'v2-luxe-dark');
  assert.equal(DEFAULT_CONFIG.background, '#0B0B0D');
  assert.equal(DEFAULT_CONFIG.primary, '#6E1826');
  assert.equal(DEFAULT_CONFIG.accentGold, '#C9A45C');
  assert.equal(t('seeMore', 'en'), 'See More');
  assert.equal(t('seeMore', 'bn'), 'আরও দেখুন');

  // Legacy light-theme cached config upgrades cleanly to v2-luxe-dark while preserving brand/checkout customizations
  appServices.settings.saveConfig({
    brand: 'LUXE NEXUS ATELIER',
    background: '#F7F8FA',
    primary: '#233B65',
    logo: '',
  });
  const migrated = getPlatformConfig();
  assert.equal(migrated.brand, 'LUXE NEXUS ATELIER');
  assert.equal(migrated.background, '#0B0B0D');
  assert.equal(migrated.primary, '#6E1826');
  assert.equal(migrated.logo, OFFICIAL_LOGO_URL);
});

test('Dynamic User Display Name & Guest Mode Fallback', async () => {
  resetMemoryStore();
  ensureEcosystemSeeded();

  // Guest Mode never exposes undefined, null, User, Users, or empty string
  assert.equal(getDisplayUserName(null), 'Luxe Nexus');
  assert.equal(getDisplayUserName(undefined), 'Luxe Nexus');
  assert.equal(getDisplayUserName({ name: '' }), 'Luxe Nexus');
  assert.equal(getDisplayUserName({ name: 'User' }), 'Luxe Nexus');
  assert.equal(getDisplayUserName({ name: 'Users' }), 'Luxe Nexus');
  assert.equal(getDisplayUserName({ username: 'undefined', name: 'null' }), 'Luxe Nexus');

  // Dynamic per-user precedence: username -> displayName -> name
  assert.equal(getDisplayUserName({ username: 'LN_Saikat', name: 'Saikat Rahman' }), 'LN_Saikat');
  assert.equal(getDisplayUserName({ username: 'Aria_Atelier', name: 'Aria Karim' }), 'Aria_Atelier');
  assert.equal(getDisplayUserName({ displayName: 'Nadia K.', name: 'Nadia Karim' }), 'Nadia K.');
  assert.equal(getDisplayUserName({ name: 'Tariq Hasan' }), 'Tariq Hasan');

  // End-to-end signup preserves optional username
  const created = await signupAccount({
    name: 'Saikat Chowdhury',
    username: 'LN_Saikat',
    email: 'saikat@test.com',
    phone: '01799998888',
    password: 'Password#123',
  });
  assert.equal(created.username, 'LN_Saikat');
  assert.equal(getDisplayUserName(created), 'LN_Saikat');
});

test('Hero Banner / Slider Service: Slides, Reorder, Responsive Imagery, Layout, Save & Reset', () => {
  resetMemoryStore();
  ensureEcosystemSeeded();

  const s1 = normalizeHeroSlide({
    id: 'S-1',
    subtitle: 'DROP ONE',
    title: 'Signature Watch',
    image: '/src/assets/images/prod_chronograph_watch_1795240520418.jpg',
    mobileImage: '/src/assets/images/prod_leather_bag_1795240519945.jpg',
    enabled: true,
    button: 'Explore',
    link: 'category:Watches',
  });
  const s2 = normalizeHeroSlide({
    id: 'S-2',
    subtitle: 'HIDDEN',
    title: 'Disabled Slide',
    image: '/src/assets/images/hero_luxe_collection_1795240520616.jpg',
    enabled: false,
  });
  const s3 = normalizeHeroSlide({
    id: 'S-3',
    subtitle: 'AUDIO',
    title: 'Studio Sound',
    image: '/src/assets/images/prod_studio_audio_1795240519980.jpg',
    enabled: true,
  });

  // Responsive mobile vs desktop image resolution
  assert.equal(resolveHeroSlideImage(s1, 1280), '/src/assets/images/prod_chronograph_watch_1795240520418.jpg');
  assert.equal(resolveHeroSlideImage(s1, 390), '/src/assets/images/prod_leather_bag_1795240519945.jpg');
  assert.equal(resolveHeroSlideImage(s3, 390), '/src/assets/images/prod_studio_audio_1795240519980.jpg');

  // Reordering
  const reordered = reorderHeroSlides([s1, s2, s3], 2, 0);
  assert.deepEqual(reordered.map((x) => x.id), ['S-3', 'S-1', 'S-2']);

  // Slider config normalization & layout style computation
  const normalizedCfg = normalizeHeroSliderConfig({
    desktopHeight: 380,
    mobileHeight: 260,
    minHeight: 210,
    maxHeight: 520,
    aspectRatio: '16/9',
    desktopSizePreset: 'custom',
    desktopMaxWidth: 1240,
    imageFit: 'contain',
    imagePosition: 'top',
    borderRadius: 22,
    bannerSpacing: 20,
    animationType: 'fade-zoom',
    animationDurationMs: 700,
    animationIntensity: 'dramatic',
    autoSlide: false,
    autoSlideIntervalSec: 8,
    showArrows: false,
    showDots: true,
    loop: false,
  });
  const desktopStyles = computeHeroLayoutStyles(normalizedCfg, 1280);
  assert.equal(desktopStyles.heightCss, 'auto');
  assert.equal(desktopStyles.aspectRatio, '16/9');
  assert.equal(desktopStyles.maxWidthCss, '1240px');
  assert.equal(desktopStyles.objectFit, 'contain');
  assert.equal(desktopStyles.objectPosition, 'top');
  assert.equal(desktopStyles.borderRadiusCss, '22px');
  assert.equal(desktopStyles.zoomScale, 1.12);
  assert.equal(desktopStyles.durationMs, 700);

  // Save & Active filtering persistence
  const saved = saveHeroBannerConfig({ bannerSlides: reordered, heroSlider: normalizedCfg });
  const active = getActiveHeroSlides(saved);
  assert.deepEqual(active.map((x: { id: string }) => x.id), ['S-3', 'S-1']);
  assert.equal(getPlatformConfig().heroSlider.animationType, 'fade-zoom');
  assert.equal(getPlatformConfig().heroSlider.autoSlide, false);

  // Reset to defaults
  const reset = resetHeroBannerConfig();
  assert.equal(reset.heroSlider.animationType, DEFAULT_CONFIG.heroSlider.animationType);
  assert.equal(reset.heroSlider.autoSlide, true);
  assert.equal(reset.bannerSlides.length, DEFAULT_CONFIG.bannerSlides.length);
});

test('Homepage Section Ordering: Browse Categories Positioned Directly Above Hero Showcase', () => {
  resetMemoryStore();
  ensureEcosystemSeeded();

  const defaultOrder = getActiveHomepageSections();
  assert.equal(defaultOrder[0].type, 'categories');
  assert.equal(defaultOrder[1].type, 'hero');

  // Legacy cached settings where hero came before categories migrate cleanly
  appServices.settings.saveConfig({
    ...DEFAULT_CONFIG,
    sectionsLayoutVersion: undefined,
    sections: [
      { id: 'sec-hero', type: 'hero', title: 'Hero Showcase', order: 1, visible: true, enabled: true },
      { id: 'sec-categories', type: 'categories', title: 'Browse Categories', order: 2, visible: true, enabled: true },
      { id: 'sec-featured', type: 'featured', title: 'Featured Products', order: 3, visible: true, enabled: true },
    ],
  });
  const migratedOrder = getActiveHomepageSections();
  assert.equal(migratedOrder[0].type, 'categories');
  assert.equal(migratedOrder[1].type, 'hero');
  assert.equal(migratedOrder[2].type, 'featured');
});

test('Product Variant Selector & Buy Now Validation: Color Family, Sizes, Stock Clamping & Order Persistence', async () => {
  resetMemoryStore();
  ensureEcosystemSeeded();

  const sampleProd = {
    id: 'LN-VAR-TEST',
    name: 'Tailored Silk Shirt',
    cat: 'Fashion',
    price: 2500,
    offerPrice: 2000,
    stock: 12,
    active: true,
    approved: true,
    colors: 'Ivory, Navy, Crimson',
    sizes: 'S, M, L',
    image: '/src/assets/images/prod_tailored_shirt_1795240519571.jpg',
    colorImages: {
      Ivory: '/src/assets/images/prod_tailored_shirt_1795240519571.jpg',
      Navy: '/src/assets/images/prod_leather_bag_1795240519945.jpg',
    },
    variants: [
      { color: 'Ivory', size: 'S', stock: 3 },
      { color: 'Ivory', size: 'M', stock: 5 },
      { color: 'Ivory', size: 'L', stock: 0 },
      { color: 'Navy', size: 'M', stock: 4 },
      { color: 'Navy', size: 'L', stock: 2 },
      { color: 'Crimson', size: 'S', stock: 0 },
    ],
  };

  const colorOpts = buildProductColorOptions(sampleProd);
  assert.equal(colorOpts.length, 3);
  assert.equal(colorOpts[0].available, true);
  assert.equal(colorOpts[1].image, '/src/assets/images/prod_leather_bag_1795240519945.jpg');
  assert.equal(colorOpts[2].available, false); // Crimson has 0 stock

  const navySizes = buildProductSizeOptions(sampleProd, 'Navy');
  assert.equal(navySizes.find((s) => s.name === 'S')?.available, false);
  assert.equal(navySizes.find((s) => s.name === 'L')?.available, true);
  assert.equal(navySizes.find((s) => s.name === 'L')?.stock, 2);

  assert.equal(resolveVariantStock(sampleProd, { color: 'Navy', size: 'L' }), 2);
  assert.equal(clampVariantQty(5, 2), 2);
  assert.equal(clampVariantQty(0, 2), 1);

  const defaults = resolveDefaultVariantSelection(sampleProd);
  assert.equal(defaults.color, 'Ivory');
  assert.equal(defaults.size, 'S');
  assert.equal(defaults.qty, 1);

  // Validation guards
  assert.equal(validateBuyNowSelection(sampleProd, { color: '', size: 'M', qty: 1 }).valid, false);
  assert.equal(validateBuyNowSelection(sampleProd, { color: 'Navy', size: '', qty: 1 }).valid, false);
  assert.equal(validateBuyNowSelection(sampleProd, { color: 'Crimson', size: 'S', qty: 1 }).valid, false);
  assert.equal(validateBuyNowSelection(sampleProd, { color: 'Navy', size: 'L', qty: 4 }).valid, false);

  const validRes = validateBuyNowSelection(sampleProd, { color: 'Navy', size: 'L', qty: 2 });
  assert.equal(validRes.valid, true);
  assert.ok(validRes.normalized);
  assert.equal(validRes.normalized.totalPrice, 4000);
  assert.equal(validRes.normalized.discountPercent, 20);
  assert.equal(validRes.normalized.image, '/src/assets/images/prod_leather_bag_1795240519945.jpg');

  // Product without sizes validates cleanly with color only
  const bagNoSize = {
    id: 'LN-BAG-NOSIZE',
    name: 'Atelier Tote',
    cat: 'Bags',
    price: 3000,
    offerPrice: 2700,
    stock: 4,
    active: true,
    approved: true,
    colors: 'Espresso',
    sizes: '',
    image: '/src/assets/images/prod_leather_bag_1795240519945.jpg',
  };
  assert.equal(buildProductSizeOptions(bagNoSize).length, 0);
  assert.equal(validateBuyNowSelection(bagNoSize, { color: 'Espresso', size: '', qty: 2 }).valid, true);

  // Save sampleProd and verify createValidatedOrder enforces variant stock & preserves selected variant image
  const buyer = await signupAccount({
    name: 'Nadia Buyer',
    email: 'nadia-var@test.com',
    phone: '01755556666',
    password: 'BuyerPass#1',
    role: ROLES.CUSTOMER,
  });
  appServices.products.upsert(sampleProd.id, { ...sampleProd, sellerId: 'seller-atelier-nord', sellerName: 'Atelier Nord' });

  assert.throws(
    () =>
      createValidatedOrder({
        items: [{ productId: 'LN-VAR-TEST', color: 'Navy', size: 'L', qty: 4 }],
        customer: { name: 'Nadia Buyer', phone: '01755556666', district: 'Dhaka', upazila: 'Banani', address: 'Road 4' },
        area: 'dhaka',
        payment: 'COD',
        source: 'buy_now',
        user: buyer,
        idempotencyKey: 'idem-var-fail',
      }),
    /Insufficient stock/
  );

  const okOrder = createValidatedOrder({
    items: [
      {
        productId: 'LN-VAR-TEST',
        color: 'Navy',
        size: 'L',
        qty: 2,
        image: '/src/assets/images/prod_leather_bag_1795240519945.jpg',
      },
    ],
    customer: { name: 'Nadia Buyer', phone: '01755556666', district: 'Dhaka', upazila: 'Banani', address: 'Road 4' },
    area: 'dhaka',
    payment: 'COD',
    source: 'buy_now',
    user: buyer,
    idempotencyKey: 'idem-var-ok',
  });
  assert.equal(okOrder.items[0].color, 'Navy');
  assert.equal(okOrder.items[0].size, 'L');
  assert.equal(okOrder.items[0].qty, 2);
  assert.equal(okOrder.items[0].image, '/src/assets/images/prod_leather_bag_1795240519945.jpg');
});

test('Affiliate Eligibility (72h, 18+, Verification, Social), 10 Rules (Holds/Bans/Cooldown/Dupe), & 4-Tier Level Progression', async () => {
  resetMemoryStore();
  ensureEcosystemSeeded();

  assert.equal(AFFILIATE_PROGRAM_RULES.length, 10);

  const admin = await signupAccount({
    name: 'Policy Admin',
    email: 'policyadmin@test.com',
    password: 'AdminPass#1',
    role: ROLES.ADMIN,
  });

  // 1. Fresh user cannot apply before 72h, before email/phone verification, before 18+, or without profile/social
  const youngUser = await signupAccount({
    name: 'Tariq Creator',
    email: 'tariq@test.com',
    phone: '01744445555',
    password: 'CreatorPass#1',
    role: ROLES.CUSTOMER,
    age: 16,
  });

  const t0 = Date.now();
  const basePayload = {
    name: youngUser.name,
    userId: youngUser.uid,
    phone: youngUser.phone,
    email: youngUser.email,
    age: 16,
    socialLink: 'https://instagram.com/tariq_luxe',
    followerCount: 8500,
    promotionMedium: 'Instagram',
    marketingPlan: 'Reels and lookbooks showcasing tailored essentials weekly.',
    termsAccepted: true,
  };

  // <72 hours rejected
  assert.throws(() => applyForAffiliate(basePayload, t0 + 24 * 3600 * 1000), /Account Age/);

  const after72h = t0 + 73 * 3600 * 1000;
  // Still underage (<18)
  assert.throws(() => applyForAffiliate(basePayload, after72h), /Minimum Age/);

  // Fix age to 21, still unverified email & phone + incomplete city
  updateAccountProfile(youngUser.uid, { age: 21 });
  assert.throws(() => applyForAffiliate({ ...basePayload, age: 21 }, after72h), /Verified Email/);

  verifyAccountContact(youngUser.uid, 'email');
  assert.throws(() => applyForAffiliate({ ...basePayload, age: 21 }, after72h), /Verified Mobile/);

  verifyAccountContact(youngUser.uid, 'phone');
  assert.throws(() => applyForAffiliate({ ...basePayload, age: 21 }, after72h), /Complete Profile/);

  updateAccountProfile(youngUser.uid, { city: 'Chattogram', socialUrl: 'https://instagram.com/tariq_luxe' });

  // Invalid social URL fails
  assert.throws(
    () => applyForAffiliate({ ...basePayload, age: 21, socialLink: 'javascript:alert(1)' }, after72h),
    /Social Media Account or Website/
  );

  // Eligibility passes cleanly now
  const eligPass = evaluateAffiliateEligibility(appServices.storage.getDoc('users', youngUser.uid), null, getPlatformConfig(), after72h);
  assert.equal(eligPass.eligible, true);

  // Missing marketing plan blocked
  assert.throws(
    () => applyForAffiliate({ ...basePayload, age: 21, marketingPlan: 'short' }, after72h),
    /marketing plan/
  );

  // Valid application succeeds cleanly
  const app1 = applyForAffiliate({ ...basePayload, age: 21 }, after72h);
  assert.equal(app1.status, 'pending');
  assert.equal(app1.level, 'bronze');

  // 2. Reject triggers cooldown blocking immediate reapplication, unlocks after cooldown
  updateAffiliateStatus(app1.id, 'rejected', admin, 'Need stronger audience bio', after72h + 1000);
  assert.throws(() => applyForAffiliate({ ...basePayload, age: 21 }, after72h + 12 * 3600 * 1000), /Reapplication Cooldown/);

  const afterCooldown = after72h + 170 * 3600 * 1000;
  const app2 = applyForAffiliate({ ...basePayload, age: 21 }, afterCooldown);
  assert.equal(app2.status, 'pending');
  updateAffiliateStatus(app2.id, 'approved', admin, '', afterCooldown);

  // 3. Anti-fraud Rule #2: Another account reusing the same phone or social link is blocked
  const dupeUser = await signupAccount({
    name: 'Clone Creator',
    email: 'clone@test.com',
    phone: '01744445555',
    password: 'CreatorPass#1',
    role: ROLES.CUSTOMER,
    age: 23,
    city: 'Dhaka',
    socialUrl: 'https://instagram.com/tariq_luxe',
  });
  verifyAccountContact(dupeUser.uid, 'email');
  verifyAccountContact(dupeUser.uid, 'phone');
  assert.throws(
    () =>
      applyForAffiliate(
        {
          ...basePayload,
          userId: dupeUser.uid,
          name: dupeUser.name,
          email: dupeUser.email,
          age: 23,
        },
        afterCooldown
      ),
    /Rule #2 Violation/
  );

  // 4. Rule #7 Hold on commissions & withdrawals
  adminUpdateAffiliateHolds(app2.id, { commissionHold: true, withdrawalHold: true, holdReason: 'Traffic spike review' }, admin);
  const buyer = await signupAccount({
    name: 'Mina Buyer',
    email: 'mina-aff@test.com',
    phone: '01677778888',
    password: 'BuyerPass#1',
    role: ROLES.CUSTOMER,
  });
  const linkHeld = createAffiliateLink({ affiliateId: app2.id, type: 'store', label: 'Held Test' }, afterCooldown + 1000);
  const ordHeld = createValidatedOrder({
    items: [{ productId: 'LN-PROD-101', qty: 1 }],
    customer: { name: buyer.name, phone: buyer.phone, district: 'Dhaka', upazila: 'Mirpur', address: 'Block C Road 2' },
    user: buyer,
    referralCode: linkHeld.code,
    nowOverrideMs: afterCooldown + 2000,
  });
  updateOrderStatus(ordHeld.id, 'Delivered', admin);
  const heldMetrics = getAffiliateDashboardMetrics(app2.id, afterCooldown + 3000);
  assert.ok(heldMetrics.heldCommission > 0);
  assert.equal(heldMetrics.availableBalance, 0);
  assert.throws(
    () => requestAffiliateWithdrawal(app2.id, { method: 'bKash', accountHolder: 'Tariq', accountNumber: '01744445555', amount: 100 }, youngUser.uid),
    /Admin Hold/
  );

  // Release hold & approve held commission -> becomes available
  adminUpdateAffiliateHolds(app2.id, { commissionHold: false, withdrawalHold: false }, admin);
  if (ordHeld.affiliateCommissionId) {
    adminOverrideCommissionStatus(ordHeld.affiliateCommissionId, 'approved', admin, 'Verified clean', afterCooldown + 4000);
  }

  // 5. Rule #5 Cancelled / Refunded order reverses commission
  const linkCancel = createAffiliateLink({ affiliateId: app2.id, type: 'store', label: 'Cancel Test' }, afterCooldown + 5000);
  const ordCancel = createValidatedOrder({
    items: [{ productId: 'LN-PROD-101', qty: 1 }],
    customer: { name: buyer.name, phone: buyer.phone, district: 'Dhaka', upazila: 'Mirpur', address: 'Block C Road 2' },
    user: buyer,
    referralCode: linkCancel.code,
    nowOverrideMs: afterCooldown + 6000,
  });
  updateOrderStatus(ordCancel.id, 'Cancelled', admin);
  const cancelledComm = appServices.affiliates.commissions.getById(ordCancel.affiliateCommissionId);
  assert.equal(cancelledComm.status, 'reversed');

  // 6. 4-Tier Level System: Bronze -> Silver -> Gold -> Diamond + Admin custom rates + Auto-downgrade on inactivity window
  const cfg = getPlatformConfig();
  const customLevels = [
    { ...getAffiliateLevelConfig('bronze', cfg), commissionRate: 8, minOrders: 0, minSales: 0, retainOrdersInWindow: 0, retainSalesInWindow: 0 },
    { ...getAffiliateLevelConfig('silver', cfg), commissionRate: 10, minOrders: 2, minSales: 3000, retainOrdersInWindow: 1, retainSalesInWindow: 1500 },
    { ...getAffiliateLevelConfig('gold', cfg), commissionRate: 12, minOrders: 3, minSales: 5000, retainOrdersInWindow: 2, retainSalesInWindow: 3000 },
    { ...getAffiliateLevelConfig('diamond', cfg), commissionRate: 15, minOrders: 4, minSales: 8000, retainOrdersInWindow: 3, retainSalesInWindow: 5000 },
  ];
  updatePlatformConfig(
    { affiliateConfig: { ...cfg.affiliateConfig, levels: customLevels, downgradeWindowDays: 30, autoUpgradeEnabled: true, autoDowngradeEnabled: true } },
    admin
  );

  // Deliver a 2nd & 3rd order to cross Silver (2 orders / 3000) -> Gold (3 orders / 5000)
  for (let i = 0; i < 2; i += 1) {
    const l = createAffiliateLink({ affiliateId: app2.id, type: 'store', label: `Tier Boost ${i}` }, afterCooldown + 10000 + i * 2000);
    const o = createValidatedOrder({
      items: [{ productId: 'LN-PROD-101', qty: 1 }], // Fashion, price 1790 each -> total 3 orders = 5370 > 5000
      customer: { name: buyer.name, phone: buyer.phone, district: 'Dhaka', upazila: 'Mirpur', address: 'Block C Road 2' },
      user: buyer,
      referralCode: l.code,
      nowOverrideMs: afterCooldown + 10500 + i * 2000,
    });
    updateOrderStatus(o.id, 'Delivered', admin);
  }
  const lvlAfterGold = evaluateAffiliateLevel(app2.id, afterCooldown + 20000);
  assert.equal(lvlAfterGold?.currentTier.id, 'gold');
  assert.equal(lvlAfterGold?.currentTier.commissionRate, 12);

  // Verify Gold commission rate (12%) is applied on next Fashion order (1790 * 12% = 214.80)
  const goldLink = createAffiliateLink({ affiliateId: app2.id, type: 'store', label: 'Gold Rate Check' }, afterCooldown + 25000);
  const goldOrder = createValidatedOrder({
    items: [{ productId: 'LN-PROD-101', qty: 1 }],
    customer: { name: buyer.name, phone: buyer.phone, district: 'Dhaka', upazila: 'Mirpur', address: 'Block C Road 2' },
    user: buyer,
    referralCode: goldLink.code,
    nowOverrideMs: afterCooldown + 26000,
  });
  const goldComm = appServices.affiliates.commissions.getById(goldOrder.affiliateCommissionId);
  assert.equal(goldComm.affiliateLevel, 'gold');
  assert.equal(goldComm.commissionRateApplied, 12);
  assert.equal(goldComm.commissionAmount, 214.8);

  // Admin manual level set to Diamond
  adminSetAffiliateLevel(app2.id, 'diamond', admin, { lockManual: false, reason: 'Spotlight reward' }, afterCooldown + 27000);
  assert.equal(appServices.affiliates.affiliates.getById(app2.id).level, 'diamond');

  // Performance drop after 35 days (0 recent orders in last 30d) -> automatically downgrades back to Bronze
  const after35Days = afterCooldown + 27000 + 35 * 86400000;
  const lvlDropped = evaluateAffiliateLevel(app2.id, after35Days);
  assert.equal(lvlDropped?.currentTier.id, 'bronze');

  // 7. Rule #8 Ban permanently locks links and blocks reapplication
  updateAffiliateStatus(app2.id, 'banned', admin, 'Confirmed fraudulent clicks', after35Days + 1000);
  assert.throws(() => createAffiliateLink({ affiliateId: app2.id, type: 'store' }, after35Days + 2000), /permanently banned/);
  assert.throws(() => applyForAffiliate({ ...basePayload, age: 21 }, after35Days + 999 * 3600 * 1000), /permanently banned/);
});

test('Product Share Helpers: canonical product link & social share targets', () => {
  const plainUrl = buildProductShareUrl({
    origin: 'https://luxenexus.example/',
    productId: 'LN-PROD-101',
  });
  assert.equal(plainUrl, 'https://luxenexus.example/?product=LN-PROD-101');

  const affUrl = buildProductShareUrl({
    origin: 'https://luxenexus.example',
    productId: 'LN-PROD-101',
    affiliateCode: 'REF99',
  });
  assert.equal(affUrl, 'https://luxenexus.example/?product=LN-PROD-101&ref=REF99');

  const targets = buildProductShareTargets({
    url: plainUrl,
    title: 'Atelier Watch',
    priceText: '৳1,790',
  });
  assert.ok(targets.whatsapp.startsWith('https://wa.me/?text='));
  assert.ok(targets.facebook.includes(encodeURIComponent(plainUrl)));
  assert.ok(targets.twitter.includes('Atelier%20Watch'));
  assert.ok(targets.telegram.includes(encodeURIComponent(plainUrl)));
});



