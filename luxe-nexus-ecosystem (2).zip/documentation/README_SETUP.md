# LUXE NEXUS — Setup, Local Development & Future Firebase Guide

## 1. Overview
LUXE NEXUS is a modular Vanilla HTML5 / CSS3 / ES-Module JavaScript e-commerce ecosystem uniting three independent yet cross-synchronized applications:
- **User App**: `/luxe-nexus-user-app.html` (`apps/user-app.js`)
- **Admin App (No-Code Control Center)**: `/luxe-nexus-admin-app.html` (`apps/admin-app.js`)
- **Seller App (Vendor Studio)**: `/luxe-nexus-seller-app.html` (`apps/seller-app.js`)
- **Ecosystem Launch Portal**: `/index.html`

## 2. Running Locally
1. Ensure dependencies are installed (`npm install`).
2. Start the development server on port `3000`:
   ```bash
   npm run dev
   ```
3. Build production bundle:
   ```bash
   npm run build
   ```
4. Run core automated unit & integration tests:
   ```bash
   npx --yes tsx --test tests/luxe-nexus-core.test.ts
   ```

> **Cross-App Sync**: Because all three apps share `/adapters/storage-adapter.js` backed by `localStorage` and `BroadcastChannel('luxe-nexus-sync-v2')`, actions taken in the Admin App (e.g., changing theme colors, toggling Feature Flags, approving a Seller or Affiliate, adding a Homepage Section, or publishing an App Update) immediately propagate to open User App and Seller App tabs.

## 3. First-Run Admin Account Bootstrap
No default or hardcoded Admin passwords exist in the codebase. When opening `/luxe-nexus-admin-app.html` for the first time, the system detects zero existing Admin accounts and prompts you to register the initial **Super Admin** account.

---

## 4. Future Firebase Connection Guide (Target Project: `fliex-price`)
The application has been built behind clean service & persistence adapters (`adapters/storage-adapter.js`, `adapters/auth-adapter.js`, `adapters/backend-adapter.js`) so connecting Firebase later requires **zero UI rewrites**.

Prepared Firebase assets already live in `/firebase/`:
- `/firebase/firestore.rules`
- `/firebase/storage.rules`
- `/firebase/firestore.indexes.json`
- `/firebase/functions/index.js` & `/firebase/functions/package.json`

### Step-by-Step Connection When Ready:
1. Create or select Firebase project `fliex-price` with Firestore database `(default)`, Authentication (Email/Password + Google Provider), and Cloud Storage.
2. Deploy security rules & indexes from `/firebase/`:
   ```bash
   firebase use fliex-price
   firebase deploy --only firestore:rules,firestore:indexes,storage,functions
   ```
3. Replace adapter internals:
   - Update `adapters/auth-adapter.js` to delegate `registerUser`, `authenticateUser`, and session listening to `firebase/auth`.
   - Update `adapters/storage-adapter.js` to swap `localStorage` collection reads/writes with `firebase/firestore` (`collection`, `doc`, `onSnapshot`, `setDoc`, `runTransaction`).
   - Point critical mutating calls in `services/order-service.js` and `services/affiliate-service.js` to the deployed `httpsCallable` Cloud Functions (`createOrder`, `trackAffiliateClick`, `requestAffiliateWithdrawal`, `verifyLinkExpiry`).

---

## 5. How to Add New Features Later (Extensibility Blueprint)
1. **Register Feature Flag**: Add a key in `DEFAULT_FEATURE_FLAGS` inside `/shared/configuration.js` (automatically appears in Admin -> Feature Control Center).
2. **Add Permission (if role-gated)**: Add the permission key in `/shared/permissions.js` (`PERMISSIONS` and `DEFAULT_ROLE_MATRIX`).
3. **Create Service Module**: Add a pure ES module in `/services/` importing `appServices` from `/adapters/backend-adapter.js` and gating entry points with `assertFeatureEnabled` / `assertPermission`.
4. **Hook View or Dynamic Homepage Section**:
   - For homepage widgets, add a renderer switch in `/apps/user-app.js` and a section template in `/services/settings-service.js`.
   - For navigation pages, add the route target in Admin -> Navigation Manager or in the app workspace renderer.
5. **Write Unit Tests**: Add a test block in `/tests/luxe-nexus-core.test.ts` and verify via `npx --yes tsx --test tests/luxe-nexus-core.test.ts`.
