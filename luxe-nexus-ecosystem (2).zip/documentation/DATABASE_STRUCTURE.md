# LUXE NEXUS — Database Structure (Local Adapter & Future Firestore `fliex-price`)

Target Future Firebase Project ID: `fliex-price`  
Target Firestore Database: `(default)`  
Current Stage: Local Persistence Adapter (`adapters/storage-adapter.js` backed by `localStorage` + `BroadcastChannel` cross-tab sync, zero hardcoded secrets).

---

## Collection Directory & Schema Specification

### 1. `users`
- **Fields**: `uid` (string, PK), `name` (string), `email` (string, unique lowercase), `phone` (string), `role` (enum: `ROLES.*`), `status` (`active` | `suspended`), `passwordHash` (string, salted SHA-256 in local adapter; Firebase Auth in production), `passwordSalt` (string), `sellerStatus`, `storeName`, `affiliateId`, `affiliateStatus`, `createdAt` (ISO), `updatedAt` (ISO).
- **Access**: Users read/update own safe fields; role escalation blocked; Super Admin immutable except by Super Admin.
- **Indexes**: `email`, `role`, `createdAt DESC`.

### 2. `admins`
- **Fields**: `id` (`role_matrix` or admin UID), `matrix` (Record<Role, Permission[]>), `updatedBy`, `updatedAt`.
- **Access**: Admin read only; `super_admin` write only; `super_admin` entry cannot be deleted or stripped of permissions.

### 3. `sellers`
- **Fields**: `id` / `ownerId` (string, FK -> `users.uid`), `storeName`, `email`, `phone`, `category`, `description`, `status` (`pending` | `approved` | `rejected` | `suspended`), `rejectionReason`, `commissionShare` (number), `createdAt`, `updatedAt`.
- **Relationships**: 1:1 with Seller `user`; 1:N with `products`.
- **Access**: Seller reads/updates own profile (except `status`); Admin approves/rejects/suspends; public reads approved storefront profile.

### 4. `products`
- **Fields (24-Field Seller Studio + Approval)**: `id` (PK), `sellerId` (FK -> `sellers.id`), `sellerName`, `name`, `cat`, `brand`, `sku`, `price` (number), `offerPrice` (number), `stock` (integer), `weight`, `dimensions`, `material`, `sizes` (string[]), `colors` (string[]), `warranty`, `returnPolicy`, `shippingNote`, `deliveryDays`, `tags` (string[]), `image` (URL/data), `images` (string[]), `videoUrl`, `shortDesc`, `desc`, `approved` (boolean), `active` (boolean), `featured` (boolean), `rating` (number), `reviewCount` (integer), `createdAt`, `updatedAt`.
- **Indexes**: `(approved ASC, active ASC, cat ASC, createdAt DESC)`, `(sellerId ASC, createdAt DESC)`.

### 5. `categories` & `brands`
- **Fields**: `id`, `name`, `slug`, `icon`, `description`, `active` (boolean), `order` (number).
- **Access**: Public read, Admin write.

### 6. `orders` & `orderItems`
- **Fields (`orders`)**: `id` (PK), `userId` (FK -> `users.uid`), `customerEmail`, `customer` (`{ name, phone, email, district, upazila, address }`), `items` (OrderItem[]), `sellerIds` (string[]), `price` (subtotal), `discount`, `couponCode`, `delivery`, `paymentFee`, `total`, `area` (`dhaka` | `outside`), `payment` (`COD` | `bKash` | `Nagad` | `Card`), `paymentIntentId`, `source` (`cart` | `buy_now`), `status` (10-stage enum), `statusHistory` (`{ status, timestamp, actorId, note }[]`), `affiliateCommissionId`, `affiliateId`, `createdAtMs` (number), `createdAt` (ISO).
- **Indexes**: `(userId ASC, createdAtMs DESC)`, `(sellerIds CONTAINS, createdAtMs DESC)`.
- **Security**: Created exclusively via unified validated order pipeline (or Cloud Function `createOrder`). Sellers only receive orders matching their `sellerId` with filtered `items`.

### 7. `reviews`, `wishlists`, `carts`, `addresses`
- **`reviews`**: `id`, `productId`, `userId`, `userName`, `rating` (1–5), `comment`, `verifiedPurchase` (boolean), `createdAt`.
- **`wishlists`**: `userId` (PK), `productIds` (string[]).
- **`carts`**: `userId` (PK), `items` (`{ variantKey, productId, qty, size, color, unitPrice }[]`).
- **`addresses`**: `id`, `userId`, `label`, `name`, `phone`, `district`, `upazila`, `address`, `isDefault`.

### 8. `payments` & `shipments`
- **`payments`**: `intentId` (PK), `orderId`, `method`, `amount`, `fee`, `status` (`authorized` | `cod_pending` | `captured` | `refunded`), `providerRef`, `createdAt`.
- **`shipments`**: `id`, `orderId`, `sellerId`, `courier`, `trackingCode`, `status`, `updatedAt`.

### 9. Affiliate Collections
- **`affiliates`**: `id`, `affiliateCode`, `userId`, `name`, `phone`, `email`, `bio`, `status` (`pending` | `approved` | `rejected` | `suspended`), `rejectionReason`, `termsAccepted`, `createdAt`, `updatedAt`.
- **`affiliateLinks`**: `id`, `code`, `affiliateId`, `affiliateUserId`, `type` (`store` | `product` | `category`), `targetId`, `targetName`, `label`, `urlQuery`, `serverCreatedMs`, `expiresAtMs` (+168h), `status` (`active` | `sold` | `expired` | `disabled`), `clicks`, `uniqueClicks`, `orders`, `sales`, `commission`.
- **`affiliateClicks`**: `id`, `linkId`, `code`, `affiliateId`, `visitorId`, `unique` (boolean), `source`, `createdAtMs`, `createdAt`.
- **`affiliateReferrals`**: `id`, `orderId`, `affiliateId`, `linkId`, `salesAmount`, `commissionAmount`, `createdAt`.
- **`affiliateCommissions`**: `id`, `orderId`, `affiliateId`, `affiliateUserId`, `linkId`, `orderTotal`, `commissionAmount`, `status` (`pending` | `approved` | `paid` | `rejected` | `reversed`), `withdrawalId`, `createdAtMs`, `createdAt`, `updatedAt`.
- **`affiliateWithdrawals`**: `id`, `affiliateId`, `affiliateUserId`, `amount`, `method` (`bKash` | `Nagad` | `Bank`), `accountHolder`, `accountNumber`, `status` (`pending` | `approved` | `processing` | `paid` | `rejected`), `transactionId`, `paymentReference`, `createdAt`, `updatedAt`.
- **`affiliateNotifications`**, **`affiliateReports`**, **`affiliateSettings`**, **`affiliateAuditLogs`**: Notification feed, aggregated metrics, rate overrides, and self-referral/fraud audit trail.

### 10. No-Code CMS & Platform Governance Collections
- **`platformSettings`**: Theme palette, typography, storefront branding, international settings (`language`, `currency`, `currencies`, `timezone`), checkout & tax fees, coupons, payment gateways.
- **`featureFlags`**: 27 centrally toggleable feature flags with `enabled`, `label`, `roles` allowlist.
- **`navigationSettings`**: Bottom nav items, order, icon, target view, guest/role visibility.
- **`homepageSections`**: Dynamic sections (`id`, `type`, `title`, `subtitle`, `visible`, `order`, `scheduleStart`, `scheduleEnd`, `config`).
- **`banners`** & **`announcements`**: Scheduled promotional popups/banners (`startAt`, `endAt`, `audience`).
- **`appVersions`** & **`appReleases`**: Release manifests (`version`, `minSupportedVersion`, `checksum`, `forceUpdate`, `changelog`, `active`, `rollbackTarget`).
- **`notifications`**: 11-category user/seller/admin/affiliate notification center.
- **`auditLogs`**: Immutable security & admin action history.
