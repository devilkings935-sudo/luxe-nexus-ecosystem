# LUXE NEXUS — Security & Access Control Documentation

## 1. Core Security Principles Enforced
1. **Zero Hardcoded Credentials or API Keys**: No hardcoded admin passwords, service secrets, or runtime Firebase keys appear anywhere in source files. First Admin registers as initial `super_admin`.
2. **Salted SHA-256 Credential Hashing (`adapters/auth-adapter.js`)**: Local passwords are never stored in plaintext; each account uses a unique cryptographic salt combined with `crypto.subtle.digest('SHA-256')` (with Node `crypto` fallback for unit tests).
3. **XSS Protection (`shared/utilities.js`)**: All dynamic user, product, review, affiliate, and CMS strings pass through `escapeHtml` / `escapeAttr` before DOM insertion. Links and media paths pass through `sanitizeUrl`, allowing only safe `http(s)`, relative `/`, `#`, and validated `data:image/*` values while rejecting `javascript:` and `data:text/html`.
4. **Role-Based Access Control (`shared/permissions.js`)**:
   - **11 Roles**: `super_admin`, `admin`, `manager`, `moderator`, `support_agent`, `finance_manager`, `affiliate_manager`, `content_editor`, `seller`, `affiliate`, `customer`.
   - **11 Permissions**: `read`, `create`, `edit`, `delete`, `approve`, `reject`, `manage_users`, `manage_orders`, `manage_payments`, `manage_settings`, `manage_updates`.
   - **Immutable Super Admin Guard**: `canModifyRoleMatrix` and `updateUserRole` reject any attempt to downgrade `super_admin` permissions or demote the `super_admin` role.
5. **Seller Data Isolation (`services/product-service.js`, `services/order-service.js`)**:
   - Unapproved sellers cannot sign into Seller Workspace or add products.
   - Sellers can only list, edit, or delete products where `product.sellerId === seller.uid`.
   - `listOrdersForSeller` strips other vendors' line items and exposes only a read-only `hasAffiliateReferral` boolean—sellers cannot view, alter, or pay affiliate commissions.
6. **Financial & Order Integrity**:
   - Decimal-safe `roundMoney` eliminates IEEE-754 floating-point drift.
   - Cart Checkout and Buy Now share `createValidatedOrder` (unified validation, stock check, idempotency key deduplication, and server-style recomputation of subtotal, discounts, delivery fee, and payment fee).
   - Affiliate payouts use atomic available-balance reservation to block double-withdrawal races.
7. **Future Production Rules (`/firebase/firestore.rules`, `/firebase/storage.rules`)**: Mirror all RBAC, Seller Isolation, Super Admin protection, and server-only financial write rules directly at the database boundary when connecting `fliex-price`.
