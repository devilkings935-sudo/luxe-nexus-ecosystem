# LUXE NEXUS — Advanced App Update & Rollback System Documentation

## 1. Architecture
The Update Manager (`services/update-service.js` + `/releases/manifest.json`) enables zero-downtime release announcements, integrity checks, version gating, and instant rollback across User App and Seller App from the Admin App.

## 2. Manifest Format (`/releases/manifest.json`)
```json
{
  "appName": "LUXE NEXUS",
  "version": "2.0.0",
  "minSupportedVersion": "1.9.0",
  "forceUpdate": false,
  "checksum": "...",
  "changelog": ["..."],
  "bundleUrl": "/luxe-nexus-user-app.html"
}
```

## 3. Semver Validation & Integrity Verification
- **`compareSemver(a, b)`** (`shared/utilities.js`): Strictly compares `major.minor.patch` tuples.
- **`verifyReleaseIntegrity(release)`**: Computes deterministic SHA-256 checksum over the canonical payload (`version|minSupportedVersion|changelog`) via `sha256Hex` before activating or installing an update.
- **Publish Validation (`publishAppRelease`)**: Requires Admin/Super Admin permission (`manage_updates`), enforces valid semver (`X.Y.Z`), validates `minSupportedVersion <= version`, prevents non-forward version regressions unless rolling back, records SHA-256 digest, and logs an immutable audit event.

## 4. Mandatory vs Optional Update Behavior
- **Optional Update**: Displays `"Update Available"` modal (`renderUpdateModal`) with changelog, SHA-256 checksum verification, `"Update Now"`, and `"Skip / Later"` options. Skipped versions are stored in local preferences so users are not nagged until a newer version arrives.
- **Mandatory / Force Update**: Triggered when `forceUpdate === true` OR when `isVersionSupported(currentVersion, minSupportedVersion)` returns `false`. `"Later / Skip"` is hidden and user must apply `"Update Now"` to continue safely.

## 5. Rollback Workflow (`rollbackAppRelease`)
If a newly published version introduces an unexpected issue, Admin selects any prior verified release in **Admin -> Updates & Releases -> Rollback**. Rollback reactivates the target stable release without losing user orders, carts, or account state, logs `ROLLBACK_APP_RELEASE` in `auditLogs`, and propagates immediately across connected tabs via `BroadcastChannel`.
