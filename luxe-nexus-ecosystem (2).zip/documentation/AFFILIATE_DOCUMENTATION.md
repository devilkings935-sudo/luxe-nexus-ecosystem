# LUXE NEXUS — Advanced Affiliate Marketing System Documentation

## 1. End-to-End Affiliate Lifecycle
1. **Registration (`applyForAffiliate`)**: Any authenticated User App customer submits Name, Phone, Email, Promotional Bio, and accepts Affiliate Terms. Account enters `pending` state.
2. **Admin Approval Gate (`updateAffiliateStatus`)**: Only Admin / Affiliate Manager / Super Admin can approve, reject, or suspend an affiliate. Pending or rejected affiliates cannot create links or earn commissions.
3. **Referral Link & QR Generation (`createAffiliateLink`)**:
   - Approved affiliates generate Store, Product, or Category referral links (`?ref=CODE...`).
   - Built-in deterministic SVG QR code (`renderQrSvg`) is generated for instant download/sharing alongside social & copy controls.
4. **Server-Reference 168-Hour (7-Day) Expiry & Tamper Guard**:
   - Creation sets `serverCreatedMs` and `expiresAtMs = serverCreatedMs + 168h`.
   - `getTrustedServerTimestamp()` maintains a monotonic watermark (`CLOCK_WATERMARK_KEY`) so client/device clock rollbacks cannot extend expired links.
   - Expired links trigger `"Affiliate Link Expired"` notifications and reject new attribution.
5. **Click & Unique Click Attribution (`trackReferralClick`)**:
   - Validates affiliate status, active flag, and non-expiry.
   - Tracks both total clicks and visitor-deduplicated unique clicks.
   - Stores active attribution cookie/storage entry (`active_affiliate_attribution`) for seamless conversion during browsing.
6. **Self-Referral & Duplicate Conversion Guards (`recordAffiliateConversion`)**:
   - Blocks attribution if buyer matches affiliate `userId`, normalized `email`, or normalized `phone`, logging `SELF_REFERRAL_BLOCKED` in `affiliateAuditLogs`.
   - Prevents duplicate commission creation for the same `orderId`.
   - Enforces product/category scope if the link targets a specific product or category.
7. **Commission Rate Hierarchy (`calculateCommissionAmount`)**:
   - Priority: **Product Override Rate** -> **Category Rate** -> **Global Default Rate** (supports percentage or fixed per-unit commission).
8. **Commission State Machine (`syncCommissionOnOrderStatusChange`)**:
   - Order Placed -> Commission `pending`
   - Order Delivered -> Commission automatically moves to `approved` (withdrawable)
   - Order Cancelled / Refunded -> Commission automatically moves to `reversed`
   - Admin / Finance Manager can override status with reason and audit trail.
9. **Atomic Withdrawal & Balance Reservation (`requestAffiliateWithdrawal` / `adminProcessWithdrawal`)**:
   - Available Balance = `(Approved + Paid Commissions) - (Paid + Pending/Processing Withdrawals)`.
   - Over-balance requests and concurrent double-withdrawal attempts exceeding remaining available balance are rejected immediately.
   - Supports `bKash`, `Nagad`, and `Bank` transfers. Paying a withdrawal requires a Transaction ID and settles corresponding `approved` commissions to `paid`.
10. **Leaderboard (`getAffiliateLeaderboard`)**:
    - Aggregates real verified conversion orders, sales volume, clicks, conversion rate, and commission across weekly, monthly, or all-time windows.
